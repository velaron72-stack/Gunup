# Сборка APK

Файлы GitHub/Workflow не используются. Сборка выполняется Gradle (в том числе агентом Grok Build) на машине с Android SDK/NDK.

## Требования

| Компонент | Версия |
|---|---|
| JDK | 17 (подходит 21) |
| Android SDK | platform `android-34`, build-tools 34.x, platform-tools |
| NDK | r26 (`26.1.10909125`); поддерживаются r25–r27 (`-Plambda.ndkVersion=<версия>`) |
| CMake | 3.22.1 из Android SDK (`cmake;3.22.1`) или другая (`-Plambda.cmakeVersion=<версия>`) |
| Gradle | 8.7 (скачивается `gradlew`, если нет `gradle/wrapper/gradle-wrapper.jar`) |
| Сеть | при первой сборке: плагины AGP/Kotlin с Google Maven и Maven Central |

SDK задаётся переменной `ANDROID_HOME` или файлом `local.properties` (`sdk.dir=/путь/к/sdk`). Лицензии SDK должны быть приняты
(`sdkmanager --licenses`), иначе AGP не докачает недостающие компоненты.

## Команды

```
./gradlew assembleDebug      # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease    # app/build/outputs/apk/release/app-release.apk (подписан отладочным ключом)
```

Параметры (`-P<имя>=<значение>` или `gradle.properties`):

| Параметр | По умолчанию | Назначение |
|---|---|---|
| `lambda.abis` | `arm64-v8a,armeabi-v7a` | Целевые ABI; для эмулятора на ПК добавьте `x86_64` |
| `lambda.ndkVersion` | не задан (версия AGP по умолчанию) | Версия NDK |
| `lambda.cmakeVersion` | `3.22.1` | Версия CMake из SDK |

## Устройство сборки

* `app/build.gradle.kts` — модуль приложения (compileSdk 34, minSdk 24, Kotlin 1.9.24, AGP 8.5.2); зависимостей AndroidX нет.
* `app/src/main/cpp/CMakeLists.txt` собирает две цели: статическую `gl4es` и разделяемую `lambdaviewer` (ядро HLAM + мост JNI).
* C++20, исключения и RTTI включены; gl4es собирается в режиме `NOEGL`, `NO_LOADER`, `NO_INIT_CONSTRUCTOR`, `DEFAULT_ES=2`.
* Идентификаторы моста генерируются: `python3 tools/gen_bridge_ids.py` (результат уже в репозитории).

## Установка зависимостей на ARM (Termux)

AGP использует `aapt2` для x86_64. На ARM-хосте укажите собственный: `-Pandroid.aapt2FromMavenOverride=/путь/к/aapt2`.

## Что проверено при подготовке проекта

| Проверка | Результат |
|---|---|
| Ядро HLAM + мост (41 файл .cpp) компилируются `g++ -std=c++20` на хосте | пройдено |
| gl4es (69 файлов .c) собирается с флагами из CMake; полная линковка ядра, моста и gl4es в разделяемую библиотеку с `--no-undefined` | пройдено |
| Согласованность JNI-функций C++ и `external fun` Kotlin (имена, число аргументов), все `Ids.*` существуют | пройдено (`tools`/скрипт проверки) |
| Компиляция NDK/clang, Kotlin, Gradle, запуск на устройстве | **не выполнялась**: в среде подготовки нет Android SDK/NDK, Kotlin-компилятора и сети |

## Места, где при первой сборке возможны правки

1. Kotlin (около 4 тыс. строк) не компилировался: возможны мелкие ошибки типов/импортов. Исправляются локально, архитектуры не касаются.
2. NDK clang строже gcc: gl4es собирается с `-Wno-implicit-function-declaration -Wno-int-conversion -Wno-incompatible-pointer-types`.
3. Если среда не принимает `ndk;26.1.10909125` — задайте `-Plambda.ndkVersion` установленной версии.
4. Если `externalNativeBuild` жалуется на CMake — задайте `-Plambda.cmakeVersion` (версия из `$ANDROID_HOME/cmake`).
5. Первый запуск на устройстве: если рендер пуст, смотрите logcat (теги `LambdaViewer`, `LIBGL`): инициализация gl4es выполняется в `ViewerSession::OnSurfaceCreated`.
