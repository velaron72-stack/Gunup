# Карта модулей: Half-Life Asset Manager → Lambda Asset Viewer

Исходный проект: Half-Life Asset Manager (HLAM, C++20, Qt 5/6, OpenGL 2.1, 257 файлов .cpp/.hpp в `src/hlam`).
Принцип порта: вычислительное ядро остаётся на C++ и собирается через NDK; Kotlin отвечает только за интерфейс, систему Android
и мост JNI. Классификация: **без изменений** / **адаптация** / **замена** (с причиной).

## 1. Путь данных

```
SAF (Uri) ──Kotlin: Saf.readBytes──► byte[] ──JNI nativeLoadModel──► ViewerSession::LoadModel
   соседние файлы (NNT.mdl, NN01.mdl) ◄── колбэк SiblingProvider.readSibling ◄── MemoryFileSystem (fmemopen → FILE*)
ViewerSession::LoadModel ─► studiomdl::LoadStudioModel ─► ConvertToEditable ─► EditableStudioModel
   ─► (GL-поток) StudioModelAsset: сцены Scene/Texture + сущности (entity/*) + операторы камеры (ui/camera_operators/*)
   ─► TextureLoader / StudioModelRenderer ─► QOpenGLFunctions_1_1 (шим) ─► gl4es (desktop GL) ─► GLES 2 ─► GLSurfaceView
Kotlin UI ──nativeCommand(CMD_*)/nativeQuery(Q_*)/nativeState/nativeTouch──► ViewerSession ─► те же сущности и данные модели
Экспорт текстуры:  EditableStudioModel → ImageCodec::EncodeBmp8 / ToArgb → (PNG кодирует Kotlin) → SAF
Импорт текстуры:   SAF → BMP: ImageCodec::DecodeBmp; PNG/JPG/TGA: Kotlin/ImageCodec → Quantize → замена StudioTextureData
                   → CalculateScaledSTCoordinatesData/ApplyScaledSTCoordinatesData → UpdateTexture на GL-потоке
Сохранение:        ConvertFromEditable → байты заголовка (и T.mdl при отдельных текстурах) → SAF
```

## 2. Перенесённые каталоги `src/hlam` → `app/src/main/cpp/hlam`

| Каталог оригинала | Файлов перенесено | Статус | Примечание |
|---|---|---|---|
| `entity/` | 29 | без изменений | Все сущности сцены: StudioModelEntity, HLMVStudioModelEntity, GroundEntity, BackgroundEntity, TextureEntity, AxesEntity, BoundingBoxEntity, ClippingBoxEntity, CrosshairEntity, GuidelinesEntity, PlayerHitboxEntity, EntityList, BaseEntity/BaseAnimating |
| `formats/` | 21 | без изменений | MDL: чтение/запись (StudioModelIO), EditableStudioModel, конвертеры, StudioModelRenderer, BoneTransformer, DumpModelInfo, activity, liblist |
| `graphics/` | 17 | без изменений | Scene, SceneContext, Camera, Light, Palette, TextureLoader, GraphicsUtils, Image, OpenGL.hpp |
| `utility/` | 15 | без изменений | mathlib, WorldTime, IOUtils, Platform, ... |
| `filesystem/` | 5 | без изменений | Интерфейс IFileSystem используется загрузчиком; реализация диска заменена (см. ниже) |
| `soundsystem/` | 3 | без изменений | ISoundSystem, DummySoundSystem, SoundConstants |
| `application/AssetIO.hpp` | 1 | без изменений | Типы исключений ассетов |
| `ui/StateSnapshot.hpp` | 1 | без изменений | Сохранение/восстановление вида камеры |
| `ui/camera_operators/` | 7 | адаптация | Убраны QObject/QWidget-панели настроек и сигналы Qt; добавлен `PinchZoom` (жест Pinch-to-Zoom вместо колеса мыши). Математика ArcBall/FreeLook/FirstPerson/Texture не менялась |
| `plugins/halflife/studiomodel/StudioModelColors.hpp` | 1 | без изменений | Ключи цветов |
| `plugins/halflife/studiomodel/StudioModelAsset.{hpp,cpp}` | 2 | **замена** | Оригинал — QObject с вкладками/undo/QOpenGLWidget. Сохранены: CreateMainScene/CreateTextureScene, GetCenteredValues, вращение света мышью, снимки состояния сущности, флаги отображения; в файл включён и StudioModelAssetProvider (рендерер, камеры, текстура пола) |
| `plugins/halflife/studiomodel/settings/StudioModelSettings.hpp` | 1 | **замена** | Qt-типы (QSet, QString, QSettings) → STL; настройки хранит Kotlin (SharedPreferences) |
| `settings/ApplicationSettings.hpp`, `settings/ColorSettings.hpp` | 2 | **замена** | QSettings/QColor/QObject → STL; интерфейс GetColor/Add/Set и значения по умолчанию сохранены |

## 3. Не перенесено (и чем заменено)

| Модуль оригинала | Причина | Замена |
|---|---|---|
| `application/` (Application, AssetManager, диалоги) | Qt MDI, вкладки, меню | `bridge/ViewerSession` (один открытый ассет — режим «Limit to one open asset» оригинала), Kotlin `MainActivity` |
| `ui/` (MainWindow, SceneWidget, виджеты, диалоги), `qt/` | Qt Widgets | Kotlin: `MainActivity`, `ViewerSurfaceView`, `PlaybackBar`, `FilePanel`, `PropertiesPanel`, `PropertyTabs`, `Ui`, `Icons` |
| `plugins/halflife/studiomodel/ui/` (панели Sequences, BodyParts, Textures, Bones, ..., Timeline, UndoCommands, TextureUtilities) | Qt Widgets + QImage | Kotlin-вкладки (`PropertyTabs.kt`); логика данных — `ViewerQueries.cpp`, `ViewerSession.cpp`, `ImageCodec.cpp` |
| `filesystem/FileSystem` (поиск по каталогам диска) | SAF не даёт путей к документам | `bridge/MemoryFileSystem` (файлы по имени из каталога SAF через `fmemopen`) |
| OpenAL/libnyquist звуковая система | Нет в Android NDK | `AndroidSoundSystem` (C++) → `SoundPlayer` (Kotlin, SoundPool) |
| Диалоги внешних программ (Crowbar, редактор QC), WinAPI-интеграция | Программы Windows | Не применимо |
| Плагин-система, о приложении Qt, стили | Qt | Не применимо |

## 4. Библиотеки

| Зависимость оригинала | В порте | Причина |
|---|---|---|
| GLM | `compat/glm/lite.hpp` (glm-lite): vec2/3/4, ivec2, mat4, quat, translate/scale/rotate, perspective/ortho/lookAt, inverse, slerp, eulerAngles, value_ptr | GLM нет в среде сборки; vec3 лежит в бинарных структурах MDL (sizeof == 12) |
| Qt: QOpenGLFunctions_1_1 | `compat/QOpenGLFunctions_1_1` (сгенерирован из `gl4es/include/GL/gl.h`) | Все вызовы GL 1.x уходят в gl4es |
| Qt: QString/QMap/QVector/QPoint/QMouseEvent/QWheelEvent/QFlags | `compat/QtLite.hpp` | Нужны только перенесённым операторам камеры и сцене; события приходят из JNI |
| fmt, spdlog | `compat/fmt/format.h`, `compat/spdlog/logger.h` | Поддержаны только используемые спецификаторы; сообщения идут в logcat и вкладку Messages |
| libnyquist, OpenAL | не используются | см. выше |
| gl4es | `gl4es/` (исходный архив без изменений), статическая библиотека, режим NOEGL + NO_LOADER | Контекст создаёт GLSurfaceView; функции GLES выдаёт `eglGetProcAddress`/`dlsym` (`ViewerJni.cpp`) |

## 5. Новый код

| Файл | Назначение |
|---|---|
| `bridge/ViewerSession.{hpp,cpp}` | Жизненный цикл GL, загрузка/сохранение, команды, состояние, касания |
| `bridge/ViewerQueries.cpp` | JSON-данные панелей, операции с текстурами |
| `bridge/ImageCodec.{hpp,cpp}` | BMP (8 бит с палитрой, 1/4/24/32 бит), TGA, медианное сечение, масштабирование, правило кратности 4 |
| `bridge/MemoryFileSystem.{hpp,cpp}` | IFileSystem поверх памяти (SAF) |
| `bridge/MessageLog.{hpp,cpp}`, `JsonWriter.hpp`, `BridgeIds.hpp` (генерируется `tools/gen_bridge_ids.py`) | Журнал, JSON, общие идентификаторы команд |
| `bridge/ViewerJni.cpp` | JNI-функции `NativeBridge`, настройка gl4es |
| `java/app/lambdaviewer/*.kt` | Интерфейс Android (16 файлов) |
