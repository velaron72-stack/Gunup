# Таблица соответствия функций

Колонки: функция оригинала → элемент интерфейса Android → вызов JNI / команда → код C++. Источник перечня — руководство
пользователя HLAM (`docs/manual`) и исходники. Статус: **+** реализовано, **≈** частично, **–** не реализовано, **н/п** не применимо на Android.
Идентификаторы `CMD_*`, `Q_*`, `FLAG_*`, `S_*`, `T_*` — в `bridge/BridgeIds.hpp` / `Ids.kt` (генерируются `tools/gen_bridge_ids.py`).

## Меню File / Edit / View

| Функция оригинала | Элемент Android | JNI / команда | C++ | Статус |
|---|---|---|---|---|
| Load (Ctrl+O) | Верхняя панель «Open»; левая панель «Open file»; открытие `*.mdl` из других приложений (VIEW) | `nativeLoadModel` + колбэк `readSibling` | `ViewerSession::LoadModel` → `studiomdl::LoadStudioModel`, `ConvertToEditable`, `MemoryFileSystem` | + |
| Recent Files | Левая панель, раздел «Recent files» | — (Kotlin `Prefs`) | — | + |
| Save (Ctrl+S) | «Save» (подсвечивается при несохранённых правках) | `nativeSerialize` | `ViewerSession::Serialize` → `ConvertFromEditable` | + (предупреждение для моделей Xash3D, как в оригинале) |
| Save As | Долгое нажатие «Save»; вкладка Model | `nativeSerialize` | то же | + |
| Close / Close All | Model → «Close model» | `nativeCloseModel` | `ViewerSession::CloseModel` | + (одна модель одновременно: режим «Limit to one open asset») |
| Exit | Системные кнопки | — | — | н/п |
| Undo / Redo (Ctrl+Z/Y) | — | — | — | – (правки применяются сразу; `QUndoStack` и команды отмены не перенесены) |
| Fullscreen (F11) | Всегда полноэкранный (immersive) режим | — | — | + |
| File Browser | Левая выдвижная панель (свайп от левого края, «Files») | — | — | + |
| Messages | — (сообщения пишутся в logcat, тег `LambdaViewer`) | — | `MessageLog` | – (убрано из интерфейса для минимализма) |

## Меню Audio / Video

| Функция | Элемент Android | JNI | C++ | Статус |
|---|---|---|---|---|
| Play Sounds | Settings → «Play sounds» | `CMD_SET_FLAG` `FLAG_SOUNDS` | `AndroidSoundSystem`, `HLMVStudioModelEntity::HandleAnimEvent`; Kotlin `SoundPlayer` | + (звуки ищутся в `sound/` сохранённых каталогов игр) |
| Framerate Affects Pitch | Settings → Advanced | `FLAG_SOUND_PITCH` | `ApplicationSettings::FramerateAffectsPitch` | + |
| Power Of 2 Textures | Settings → Textures | `FLAG_POW2` | `TextureLoader::SetResizeToPowerOf2`, `EditableStudioModel::UpdateTextures` | + |
| Min / Mag / Mipmap Filter | Settings → Textures (три списка) | `CMD_SET_TEX_FILTER` | `TextureLoader::SetTextureFilters`, `UpdateFilters` | + |
| Wait For Vertical Sync | — | — | — | н/п (частота кадров задаётся GLSurfaceView) |
| Anti-Aliasing (MSAA) | — | — | — | – (нужна EGL-конфигурация с мультисэмплингом) |
| Transparent Screenshots | — | — | — | – |
| Take Screenshot (F10) | Меню отображения (кнопка «глаз») → «Screenshot» | — (Kotlin `PixelCopy`) | — | + |

## Меню Asset / Tools / Help

| Функция | Элемент Android | JNI | C++ | Статус |
|---|---|---|---|---|
| Dock Widgets, Reset Dock Widgets, Show Controls Bar / Timeline / Edit Controls | Выдвижные панели, постоянная панель воспроизведения | — | — | н/п (раскладка переработана под сенсорный экран) |
| Previous / Next Camera | View → Camera (выбор камеры) | `CMD_CAM_SELECT` | `CameraOperators::SetCurrent` | + |
| Center View (X+/X−/Y+/Y−/Z+/Z−) | View → Camera → шесть кнопок | `CMD_CAM_CENTER` | `StudioModelAsset::OnCenterView` | + |
| Save View / Restore View | View → Camera | `CMD_SAVE_VIEW`, `CMD_RESTORE_VIEW` | `CameraOperators::SaveViews/RestoreViews` | + |
| Flip Normals | Model → Model data → «Flip normals» | `CMD_FLIP_NORMALS` | `StudioModelAsset::FlipNormals` | + (без отмены) |
| Show QC Data | — | — | — | – (убрано по запросу) |
| Dump Model Info | — | — | — | – (убрано по запросу) |
| Refresh | — | — | — | н/п (каталоги читаются при каждой навигации) |
| Launch Crowbar, Edit QC File (внешние программы) | — | — | — | н/п (программы Windows) |
| Options | Вкладка Options | `CMD_SET_*` | `ApplicationSettings`, `ColorSettings` | ≈ (см. ниже) |
| Open Manual, About, About Qt | Options → About | — | — | ≈ / н/п |

## Options

| Параметр | Элемент Android | Команда | Статус |
|---|---|---|---|
| Pause animations on timeline click | Всегда (ползунок кадров ставит паузу) | `CMD_SET_FRAME` b=1 | + |
| Limit to one open asset, tab close, max recent files, tick rate | — | — | н/п / фиксировано (15 последних файлов) |
| Invert mouse X/Y | Options | `FLAG_INVERT_X/Y` | + |
| Mouse sensitivity | Settings → «Touch sensitivity» | `CMD_SET_MOUSE_SENS` | + |
| Mouse wheel speed | — | — | н/п (колеса нет; масштаб — Pinch-to-Zoom) |
| Enable audio playback / mute in background | Options → Play sounds | `FLAG_SOUNDS` | ≈ |
| Style, External programs, Assets, Game configurations | Каталоги игр добавляются в левой панели (Half-Life / Xash3D / Counter-Strike / Custom) | — | н/п / заменено |
| Colors (ground, background, crosshair, sky light, wireframe, hitbox edge/face, single hitbox edge/face) | Options → Colors | `CMD_SET_COLOR`, `CMD_RESET_COLORS`, `Q_COLORS` | + |
| Studiomodel: autodetect view models → first person camera | Options | `CMD_SET_AUTODETECT_VIEWMODEL` | + |
| Studiomodel: ground length | Options | `CMD_SET_GROUND_LENGTH` | + |
| Studiomodel: sound event IDs | — | — | – (используются встроенные ID звуковых событий) |
| Studiomodel: activate Texture view when Textures panel opens | Кнопка «View» у текстуры | `CMD_SET_SCENE`, `CMD_TEX_SELECT` | н/п |

## Controls Bar и Timeline

| Функция | Элемент Android | Команда | C++ | Статус |
|---|---|---|---|---|
| FPS, Polygons drawn | Model → Model data → Statistics | `S_FPS`, `S_POLYS` | `ViewerSession::OnDrawFrame`, `Scene::GetDrawnPolygonsCount` | + |
| Вкладки Scene / Texture | Верхняя панель, кнопка «текстура» | `CMD_SET_SCENE` | `StudioModelAsset::SetCurrentSceneIndex` | + |
| Pose: Sequences / Skeleton | Меню отображения → «Skeleton pose»; Animation → «Skeleton pose» | `CMD_SET_SEQUENCE` (−1 = Skeleton) | `StudioModelEntity::SetSequence(-1)` | + |
| Выбор последовательности (выпадающий список) | Верхняя панель, список открывается одним касанием | `CMD_SET_SEQUENCE` | `StudioModelEntity::SetSequence` | + |
| Restart, назад/вперёд на 5 кадров, Stop | — | — | — | – (убрано для минимализма; кадр выбирается ползунком) |
| Назад / вперёд на 1 кадр | Кнопки панели воспроизведения | `CMD_STEP_FRAME` | логика `Timeline::ModifyFrame` | + |
| Play / Pause | Одна кнопка (значок меняется) | `CMD_PLAY_PAUSE` (переключение) | `StudioModelAsset::PlaySequence` | + |
| Loop | Кнопка «цикл» (всегда/никогда); Animation → «Looping» (3 режима) | `CMD_SET_LOOP_MODE` | `StudioModelEntity::SetLoopingMode` | + |
| Ползунок кадра, «кадр / всего» | Панель воспроизведения | `CMD_SET_FRAME`, `S_FRAME`, `S_NUM_FRAMES` | `StudioModelEntity::SetFrame` | + |
| Framerate (скорость) | Кнопка скорости, список 0.1x … 4x, по умолчанию 1x | `CMD_SET_SPEED` | `BaseAnimating::SetFrameRate` | + |
| FPS последовательности | Animation → Sequence details → «Sequence FPS» | `CMD_SET_SEQ_FPS` | `StudioSequence::FPS` | + |

Скорость воспроизведения: нативный слой повторяет `AssetManager::OnTimerTick` оригинала (`SetRealTime`, затем `TimeChanged`), поэтому
анимация идёт с естественной скоростью `FPS последовательности × Speed`.

## Док-панели → вкладки правой панели

Вкладки: Model, Animation, Textures, View, Parts, Settings. Редко нужное спрятано в сворачиваемые секции (по умолчанию свёрнуты).

| Панель оригинала | Вкладка Android | Что реализовано | Статус |
|---|---|---|---|
| Model Data | Model → Model data | Eye position, Bounding box, Clipping box, флаги модели, Flip normals, статистика | + |
| Body Parts | Model | Выбор подмодели для каждой части, Skin | ≈ (правка имён и состава — нет) |
| Transformation | Model → Position and transform | Position, Move, Rotate, Scale (с выбором масштабируемых частей) | + |
| Sequences | Animation | Список, Looping, Skeleton pose; Sequence details: Blend mode, Blend 0/1, Looping flag, FPS, Activity, Activity weight, события (просмотр) | ≈ (создание/удаление последовательностей и правка событий — нет) |
| Textures | Textures | Список с миниатюрами, просмотр в полном разрешении (зум жестами), экспорт PNG/BMP, импорт PNG/BMP/TGA/JPG; Texture view (zoom, UV, mesh); Remap colors | + (по ТЗ — три функции; правка флагов текстур не включена) |
| Model Display | View | Render mode, Opacity; Overlays; Rendering (culling, wireframe overlay, тени, Fix shadow Z-fighting, Mirror X/Y/Z) | + |
| Cameras | View → Camera | Выбор камеры (Arc Ball / Free Look / First Person), FOV, Center view, Save/Restore view, соотношение сторон направляющих | ≈ (параметры отдельных камер не вынесены) |
| Scene (Ground, Background) | View → Ground and background | Показ пола, зеркало, текстура и мозаика пола, размер плитки, фон, загрузка текстур PNG/BMP/TGA/JPG | + |
| Lighting / Sky Light | View → Light | Pitch, Yaw, Ambient, Shade, цвет, правка света касанием | + |
| Bones, Bone Controllers, Attachments, Hitboxes | Parts (переключатель из четырёх разделов) | Списки, выделение одного элемента (Draw single), ползунки контроллеров, Mouth | ≈ (правка свойств — нет) |
| File Browser | Левая панель | Корни по категориям игр, дерево, фильтр «модели и изображения», восстановление последнего каталога, недавние файлы | + |
| Options | Settings | Touch sensitivity, Invert X/Y, Play sounds; Textures (степень двойки, фильтры); Colors; Advanced (Framerate affects pitch, автодетект view-моделей, ground length) | ≈ |
| Верхнее меню отображения | Кнопка «глаз» на верхней панели | Wireframe, Hitboxes, Bones, Attachments, Normals, Eye position, Bounding box, Axes, Ground, Skeleton pose | + |

## Мышь, клавиатура, жесты

| Оригинал | Android | Команда |
|---|---|---|
| ЛКМ + перетаскивание — вращение | Один палец | `T_ROTATE_*` → `QMouseEvent` левая кнопка |
| ПКМ + перетаскивание, колесо — масштаб | Pinch-to-Zoom двумя пальцами | `T_ZOOM` → `PinchZoom` / масштаб текстуры |
| Shift (или Extra Button 1) + ЛКМ — перенос точки орбиты | Перемещение двумя пальцами | `T_PAN_*` → `QMouseEvent` Shift + левая кнопка |
| Ctrl + ЛКМ — вектор света | View → Light → «Edit light by touch», затем перетаскивание | `FLAG_LIGHT_EDIT` → `StudioModelAsset::HandleMouseInput` |
| Ctrl + Shift + ЛКМ — Z-компонента света | В режиме правки света: два пальца, движение по горизонтали | `T_PAN_*` с Shift → `StudioModelAsset::HandleMouseInput` |
| F10 / F11 | «Screenshot» в меню отображения / постоянный полноэкранный режим | — |
| — | Двойное касание — сброс камеры; тап по окну просмотра закрывает панели | `CMD_CAM_RESET` |

Примечание: в режиме правки света один палец меняет X/Y вектора света, два пальца (по горизонтали) — Z; те же значения доступны ползунками Pitch/Yaw.

## Не реализовано (для следующего прохода)

1. Удалено по запросу: Dump Model Info, QC data, панель Messages, Restart/±5 кадров/Stop, отдельные кнопки Sound/Light/UV на верхней панели.
2. Undo/Redo и правка данных, которых нет в таблице со статусом «+» (кости, хитбоксы, attachments, контроллеры, части тела, события и создание последовательностей).
3. Anti-aliasing (MSAA), прозрачные скриншоты.
4. Параметры отдельных камер (чувствительность, расстояние) и список ID звуковых событий.
