# Lambda Asset Viewer

Android-порт Half-Life Asset Manager (просмотр и правка GoldSrc MDL). Ядро (загрузка MDL, анимация, рендерер, текстуры, камеры)
перенесено из исходников HLAM на C++ и собирается через NDK; графика — gl4es (desktop OpenGL поверх GLES); интерфейс — Kotlin
без AndroidX; мост — JNI.

* Горизонтальная ориентация, окно просмотра на весь экран, панель воспроизведения под ним.
* Левая выдвижная панель — файлы (каталоги Half-Life / Xash3D / Counter-Strike / пользовательские через Storage Access Framework).
* Правая выдвижная панель — свойства модели (6 вкладок: Model, Animation, Textures, View, Parts, Settings; редкие настройки свёрнуты).
* Текстуры: просмотр, экспорт PNG/BMP, импорт PNG/BMP (также TGA/JPG) с заменой в модели.

Документация: `docs/MODULE_MAP.md` (карта модулей), `docs/FEATURE_MAP.md` (таблица функций и статусы), `docs/BUILD.md` (сборка).

Лицензии: `licenses/` (HLAM — MIT-подобная без права сублицензирования; gl4es — MIT). Приложение распространяется как производное
от HLAM без продажи и сублицензирования.

Структура:

```
app/src/main/java/app/lambdaviewer   Kotlin: интерфейс, SAF, звук
app/src/main/cpp/hlam                перенесённое ядро HLAM
app/src/main/cpp/compat              шимы GLM / Qt / fmt / spdlog / QOpenGLFunctions_1_1
app/src/main/cpp/bridge              сессия просмотра, JNI, кодеки изображений
app/src/main/cpp/gl4es               gl4es (исходники из переданного архива)
docs, licenses, tools, branding
```
