// Версии плагинов фиксируются здесь (AGP 8.5.x требует Gradle 8.7+ и JDK 17).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
