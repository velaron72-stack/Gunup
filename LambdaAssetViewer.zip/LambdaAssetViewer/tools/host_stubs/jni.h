// Заглушка jni.h ТОЛЬКО для проверки синтаксиса JNI-слоя на хосте (g++ -fsyntax-only). В сборку Android не входит:
// там используется jni.h из NDK. Сигнатуры повторяют спецификацию JNI.
#pragma once
#include <cstdint>
#include <cstdarg>
#define JNIEXPORT __attribute__((visibility("default")))
#define JNICALL
#define JNI_VERSION_1_6 0x00010006
#define JNI_OK 0
#define JNI_EDETACHED (-2)
typedef int32_t jint; typedef int64_t jlong; typedef float jfloat; typedef uint8_t jboolean; typedef int8_t jbyte; typedef jint jsize;
#define JNI_TRUE 1
#define JNI_FALSE 0
class _jobject {}; typedef _jobject* jobject; typedef jobject jclass; typedef jobject jstring; typedef jobject jarray;
typedef jobject jbyteArray; typedef jobject jintArray; typedef jobject jfloatArray; typedef jobject jobjectArray;
struct _jmethodID; typedef _jmethodID* jmethodID;
struct JNIEnv_;
typedef JNIEnv_ JNIEnv;
struct JavaVM_;
typedef JavaVM_ JavaVM;
struct JNIEnv_ {
	jclass FindClass(const char*) { return nullptr; }
	jclass GetObjectClass(jobject) { return nullptr; }
	jmethodID GetMethodID(jclass, const char*, const char*) { return nullptr; }
	jobject CallObjectMethod(jobject, jmethodID, ...) { return nullptr; }
	void CallVoidMethod(jobject, jmethodID, ...) {}
	jobject NewGlobalRef(jobject) { return nullptr; }
	void DeleteGlobalRef(jobject) {}
	void DeleteLocalRef(jobject) {}
	const char* GetStringUTFChars(jstring, jboolean*) { return nullptr; }
	void ReleaseStringUTFChars(jstring, const char*) {}
	jstring NewStringUTF(const char*) { return nullptr; }
	jsize GetArrayLength(jarray) { return 0; }
	void GetByteArrayRegion(jbyteArray, jsize, jsize, jbyte*) {}
	void GetIntArrayRegion(jintArray, jsize, jsize, jint*) {}
	void SetFloatArrayRegion(jfloatArray, jsize, jsize, const jfloat*) {}
	void SetIntArrayRegion(jintArray, jsize, jsize, const jint*) {}
	void SetByteArrayRegion(jbyteArray, jsize, jsize, const jbyte*) {}
	jbyteArray NewByteArray(jsize) { return nullptr; }
	jintArray NewIntArray(jsize) { return nullptr; }
	jobjectArray NewObjectArray(jsize, jclass, jobject) { return nullptr; }
	void SetObjectArrayElement(jobjectArray, jsize, jobject) {}
	jboolean ExceptionCheck() { return 0; }
	void ExceptionClear() {}
	jint GetJavaVM(JavaVM**) { return 0; }
};
struct JavaVM_ {
	jint GetEnv(void**, jint) { return 0; }
	jint AttachCurrentThread(JNIEnv**, void*) { return 0; }
	jint DetachCurrentThread() { return 0; }
};
