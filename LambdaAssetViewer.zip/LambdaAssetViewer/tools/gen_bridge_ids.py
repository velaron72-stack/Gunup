#!/usr/bin/env python3
"""Генератор общих идентификаторов моста C++ <-> Kotlin.

Единственный источник правды для номеров команд, флагов, запросов и индексов вектора состояния.
Запуск (из корня проекта): python3 tools/gen_bridge_ids.py
Создаёт:
  app/src/main/cpp/bridge/BridgeIds.hpp
  app/src/main/java/app/lambdaviewer/Ids.kt
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

GROUPS = [
    ("CMD", "Команды nativeCommand(cmd, a, b, f, s)", [
        "PLAY_PAUSE", "STOP", "RESTART", "STEP_FRAME", "SET_FRAME", "SET_SPEED",
        "SET_SEQUENCE", "SET_LOOP_MODE", "SET_BLEND_MODE", "SET_BLEND",
        "SET_SEQ_FPS", "SET_SEQ_LOOPING", "SET_SEQ_ACTIVITY", "SET_SEQ_ACTWEIGHT",
        "SET_BODYGROUP", "SET_SKIN", "SET_CONTROLLER", "SET_TOP_COLOR", "SET_BOTTOM_COLOR",
        "SET_RENDER_MODE", "SET_OPACITY", "SET_FLAG", "SET_DRAW_SINGLE", "SET_GROUND_LENGTH",
        "SET_ASPECT", "SET_MODEL_ORIGIN", "CENTER_MODEL", "ALIGN_ON_GROUND", "SET_GROUND_ORIGIN",
        "SET_LIGHT_ANGLES", "SET_LIGHT_COLOR", "SET_LIGHT_AMBIENT", "SET_LIGHT_SHADE",
        "CAM_SELECT", "CAM_RESET", "CAM_CENTER", "CAM_FOV", "CAM_NEXT", "CAM_PREV",
        "SET_SCENE", "TEX_SELECT", "TEX_MESH", "TEX_SCALE", "TEX_RESET_VIEW",
        "SET_COLOR", "RESET_COLORS", "SET_MOUSE_SENS", "SET_WHEEL_SPEED", "SET_TEX_FILTER",
        "SET_EYE", "SET_BBOX", "SET_CBOX", "SET_MODEL_FLAGS", "FLIP_NORMALS",
        "XFORM_MOVE", "XFORM_ROTATE", "XFORM_SCALE", "CLEAR_IMAGE", "SET_GROUND_TEXTURE_LENGTH",
        "SAVE_VIEW", "RESTORE_VIEW", "CLEAR_LOG", "SET_AUTODETECT_VIEWMODEL",
    ]),
    ("FLAG", "Флаги для CMD_SET_FLAG (b = 0/1)", [
        "HITBOXES", "BONES", "ATTACHMENTS", "EYE", "BBOX", "CBOX", "BACKFACE", "WIREFRAME_OVERLAY",
        "SHADOWS", "SHADOW_FIX", "AXES", "NORMALS", "PLAYER_HITBOX", "MIRROR_X", "MIRROR_Y", "MIRROR_Z",
        "CROSSHAIR", "GUIDELINES", "OFFSCREEN", "GROUND", "GROUND_MIRROR", "GROUND_TEXTURE",
        "GROUND_TILING", "BACKGROUND", "SOUNDS", "SOUND_PITCH", "LIGHT_EDIT", "UV_SHOW", "UV_OVERLAY",
        "UV_AA", "POW2", "INVERT_X", "INVERT_Y",
    ]),
    ("Q", "Строковые запросы nativeQuery(q, a, b)", [
        "INFO", "SEQUENCES", "BODYPARTS", "TEXTURES", "BONES", "CONTROLLERS", "ATTACHMENTS",
        "HITBOXES", "MESSAGES", "FLAGS", "COLORS", "ACTIVITIES", "TEXTURE_MESHES", "CAMERAS",
    ]),
    ("S", "Индексы вектора состояния nativeState()", [
        "HAS_MODEL", "SEQUENCE", "FRAME", "NUM_FRAMES", "SPEED", "PLAYING", "POLYS", "SCENE", "CAMERA",
        "SEQ_FPS", "LOOP_MODE", "BLEND0", "BLEND1", "BLEND_MODE", "SKIN", "BODY", "MODEL_REV", "EDIT_REV",
        "TEX_SCALE", "TEXTURE", "LIGHT_X", "LIGHT_Y", "FOV", "TOP_COLOR", "BOTTOM_COLOR", "RENDER_MODE",
        "OPACITY", "TEX_COUNT", "LIGHT_AMBIENT", "LIGHT_SHADE", "FPS", "COUNT",
    ]),
    ("T", "Типы касаний nativeTouch(kind, x, y)", [
        "ROTATE_DOWN", "ROTATE_MOVE", "ROTATE_UP", "PAN_DOWN", "PAN_MOVE", "PAN_UP", "ZOOM",
    ]),
    ("COLOR", "Идентификаторы цветов (CMD_SET_COLOR a = id, b = ARGB)", [
        "GROUND", "BACKGROUND", "CROSSHAIR", "SKYLIGHT", "WIREFRAME", "HITBOX_EDGE", "HITBOX_FACE",
        "SINGLE_HITBOX_EDGE", "SINGLE_HITBOX_FACE",
    ]),
    ("IMG", "Виды внешних изображений сцены", [
        "GROUND", "BACKGROUND",
    ]),
]


def values(group):
    # CMD и FLAG с 1 (0 зарезервирован), остальные с 0.
    start = 1 if group in ("CMD",) else 0
    return start


def gen_cpp():
    out = ["// ФАЙЛ СГЕНЕРИРОВАН tools/gen_bridge_ids.py — не редактировать вручную.", "#pragma once", "", "namespace bridge::ids", "{"]
    for group, title, names in GROUPS:
        out.append("// %s" % title)
        v = values(group)
        for n in names:
            out.append("inline constexpr int %s_%s = %d;" % (group, n, v))
            v += 1
        out.append("")
    out.append("} // namespace bridge::ids")
    return "\n".join(out) + "\n"


def gen_kt():
    out = ["// ФАЙЛ СГЕНЕРИРОВАН tools/gen_bridge_ids.py — не редактировать вручную.", "package app.lambdaviewer", "", "object Ids {"]
    for group, title, names in GROUPS:
        out.append("    // %s" % title)
        v = values(group)
        for n in names:
            out.append("    const val %s_%s: Int = %d" % (group, n, v))
            v += 1
        out.append("")
    out.append("}")
    return "\n".join(out) + "\n"


def main():
    cpp = os.path.join(ROOT, "app/src/main/cpp/bridge/BridgeIds.hpp")
    kt = os.path.join(ROOT, "app/src/main/java/app/lambdaviewer/Ids.kt")
    os.makedirs(os.path.dirname(cpp), exist_ok=True)
    os.makedirs(os.path.dirname(kt), exist_ok=True)
    open(cpp, "w", encoding="utf-8").write(gen_cpp())
    open(kt, "w", encoding="utf-8").write(gen_kt())
    print("generated", cpp, kt)


if __name__ == "__main__":
    main()
