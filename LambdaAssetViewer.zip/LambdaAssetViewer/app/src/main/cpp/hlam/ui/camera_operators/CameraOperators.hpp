// Android-адаптация ui/camera_operators/CameraOperators.hpp: менеджер набора операторов камеры.
// QObject/QVector/сигналы заменены std::vector и std::function; логика переключения и сохранения видов не менялась.
#pragma once

#include <algorithm>
#include <cassert>
#include <functional>
#include <vector>

#include "ui/StateSnapshot.hpp"
#include "ui/camera_operators/CameraOperator.hpp"

class CameraOperators final
{
public:
	~CameraOperators() = default;

	const std::vector<SceneCameraOperator*>& GetAll() const { return _cameraOperators; }

	int Count() const { return static_cast<int>(_cameraOperators.size()); }

	SceneCameraOperator* Get(int index) const
	{
		if (index < 0 || index >= Count())
		{
			return nullptr;
		}

		return _cameraOperators[static_cast<std::size_t>(index)];
	}

	bool Contains(SceneCameraOperator* cameraOperator) const
	{
		return std::find(_cameraOperators.begin(), _cameraOperators.end(), cameraOperator) != _cameraOperators.end();
	}

	int IndexOf(SceneCameraOperator* cameraOperator) const
	{
		auto it = std::find(_cameraOperators.begin(), _cameraOperators.end(), cameraOperator);
		return it == _cameraOperators.end() ? -1 : static_cast<int>(it - _cameraOperators.begin());
	}

	void Add(SceneCameraOperator* cameraOperator)
	{
		assert(cameraOperator);

		if (!cameraOperator)
		{
			return;
		}

		_cameraOperators.push_back(cameraOperator);
	}

	SceneCameraOperator* GetCurrent() const { return _current; }

	void SetCurrent(SceneCameraOperator* cameraOperator)
	{
		if (cameraOperator && !Contains(cameraOperator))
		{
			assert(!"Tried to set a camera operator not owned by the camera operators manager");
			return;
		}

		if (_current != cameraOperator)
		{
			auto previous = _current;
			_current = cameraOperator;

			if (CameraChanged)
			{
				CameraChanged(previous, _current);
			}
		}
	}

	std::vector<StateSnapshot> SaveViews()
	{
		std::vector<StateSnapshot> snapshots(_cameraOperators.size());

		for (std::size_t index = 0; index < _cameraOperators.size(); ++index)
		{
			_cameraOperators[index]->SaveView(&snapshots[index]);
		}

		return snapshots;
	}

	void RestoreViews(const std::vector<StateSnapshot>& snapshots)
	{
		if (snapshots.size() != _cameraOperators.size())
		{
			assert(!"Camera snapshots do not match current set of operators!");
			return;
		}

		for (std::size_t index = 0; index < _cameraOperators.size(); ++index)
		{
			_cameraOperators[index]->RestoreView(&snapshots[index]);
		}
	}

	void PreviousCamera() { ChangeCamera(false); }
	void NextCamera() { ChangeCamera(true); }

	std::function<void(SceneCameraOperator* previous, SceneCameraOperator* current)> CameraChanged;

private:
	void ChangeCamera(bool next)
	{
		int index;

		if (_cameraOperators.empty())
		{
			index = -1;
		}
		else if (!_current)
		{
			index = next ? 0 : Count() - 1;
		}
		else
		{
			index = IndexOf(_current);
			index += next ? 1 : -1;

			if (index < 0)
			{
				index = Count() - 1;
			}
			else if (index >= Count())
			{
				index = 0;
			}
		}

		SetCurrent(index != -1 ? _cameraOperators[static_cast<std::size_t>(index)] : nullptr);
	}

	std::vector<SceneCameraOperator*> _cameraOperators;
	SceneCameraOperator* _current = nullptr;
};
