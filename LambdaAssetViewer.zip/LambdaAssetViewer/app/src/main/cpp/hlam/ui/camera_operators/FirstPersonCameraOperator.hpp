#pragma once

#include "ui/camera_operators/CameraOperator.hpp"

/**
*	@brief Camera operator that allows the user to view an object in first person view
*/
class FirstPersonCameraOperator final : public SceneCameraOperator
{
public:
	static constexpr float DefaultFirstPersonFieldOfView = 74.f;

	FirstPersonCameraOperator(ApplicationSettings* applicationSettings)
		: SceneCameraOperator(applicationSettings)
	{
		_camera.SetOrigin(glm::vec3{0});
		_camera.SetFieldOfView(DefaultFirstPersonFieldOfView);
	}

	QString GetName() const override
	{
		return "First Person";
	}

	void MouseEvent(QMouseEvent& event) override
	{
		//No movement of any kind
		event.accept();
	}

	void CenterView(const glm::vec3&, const glm::vec3&, float, float) override {}
};
