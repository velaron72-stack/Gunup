// Android-адаптация settings/ApplicationSettings.hpp из Half-Life Asset Manager.
// Сохранены все поля, влияющие на сцену и камеры (чувствительность, инверсия мыши, фильтры текстур, степень двойки,
// соотношение сторон, звук). Удалены QObject/QSettings/сигналы: настройки применяются мостом при изменении из Kotlin.
#pragma once

#include <memory>

#include <glm/vec2.hpp>

#include "graphics/TextureLoader.hpp"
#include "settings/ColorSettings.hpp"

class ApplicationSettings final
{
public:
	static constexpr bool DefaultTransparentScreenshots{false};
	static constexpr int DefaultTickRate{60};
	static constexpr int DefaultMouseSensitivity{5};
	static constexpr int MinimumMouseSensitivity{1};
	static constexpr int MaximumMouseSensitivity{20};
	static constexpr int DefaultMouseWheelSpeed{5};
	static constexpr int MinimumMouseWheelSpeed{1};
	static constexpr int MaximumMouseWheelSpeed{2048};
	static constexpr bool DefaultPlaySounds{true};
	static constexpr bool DefaultFramerateAffectsPitch{false};
	static constexpr bool DefaultPowerOf2Textures{false};
	static constexpr int DefaultMSAALevel{0};
	static constexpr graphics::TextureFilter DefaultMinFilter{graphics::TextureFilter::Linear};
	static constexpr graphics::TextureFilter DefaultMagFilter{graphics::TextureFilter::Linear};
	static constexpr graphics::MipmapFilter DefaultMipmapFilter{graphics::MipmapFilter::None};
	static constexpr int MinimumAspectRatio{1};
	static constexpr int MaximumAspectRatio{100};
	static constexpr glm::vec2 DefaultAspectRatio{16.f, 9.f};

	ApplicationSettings() : _colorSettings(std::make_unique<ColorSettings>()) {}

	ColorSettings* GetColorSettings() const { return _colorSettings.get(); }

	int GetTickRate() const { return _tickRate; }
	void SetTickRate(int value) { _tickRate = value; }

	bool ShouldInvertMouseX() const { return _invertMouseX; }
	void SetInvertMouseX(bool value) { _invertMouseX = value; }

	bool ShouldInvertMouseY() const { return _invertMouseY; }
	void SetInvertMouseY(bool value) { _invertMouseY = value; }

	int GetMouseSensitivity() const { return _mouseSensitivity; }
	void SetMouseSensitivity(int value) { _mouseSensitivity = value; }

	float GetNormalizedMouseSensitivity() const
	{
		return static_cast<float>(_mouseSensitivity) / DefaultMouseSensitivity;
	}

	int GetMouseWheelSpeed() const { return _mouseWheelSpeed; }
	void SetMouseWheelSpeed(int value) { _mouseWheelSpeed = value; }

	bool PlaySounds = DefaultPlaySounds;
	bool FramerateAffectsPitch = DefaultFramerateAffectsPitch;

	bool ShouldResizeTexturesToPowerOf2() const { return _powerOf2Textures; }
	void SetResizeTexturesToPowerOf2(bool value) { _powerOf2Textures = value; }

	graphics::TextureFilter GetMinFilter() const { return _minFilter; }
	graphics::TextureFilter GetMagFilter() const { return _magFilter; }
	graphics::MipmapFilter GetMipmapFilter() const { return _mipmapFilter; }

	void SetTextureFilters(
		graphics::TextureFilter minFilter, graphics::TextureFilter magFilter, graphics::MipmapFilter mipmapFilter)
	{
		_minFilter = minFilter;
		_magFilter = magFilter;
		_mipmapFilter = mipmapFilter;
	}

	int GetMSAALevel() const { return _msaaLevel; }
	void SetMSAALevel(int msaaLevel) { _msaaLevel = msaaLevel; }

	const glm::vec2 GetAspectRatio() const { return _aspectRatio; }
	void SetAspectRatio(const glm::vec2& value) { _aspectRatio = value; }

	bool TransparentScreenshots{DefaultTransparentScreenshots};

private:
	const std::unique_ptr<ColorSettings> _colorSettings;
	int _tickRate{DefaultTickRate};
	bool _invertMouseX{false};
	bool _invertMouseY{false};
	int _mouseSensitivity{DefaultMouseSensitivity};
	int _mouseWheelSpeed{DefaultMouseWheelSpeed};
	bool _powerOf2Textures{DefaultPowerOf2Textures};
	graphics::TextureFilter _minFilter{DefaultMinFilter};
	graphics::TextureFilter _magFilter{DefaultMagFilter};
	graphics::MipmapFilter _mipmapFilter{DefaultMipmapFilter};
	int _msaaLevel{DefaultMSAALevel};
	glm::vec2 _aspectRatio{DefaultAspectRatio};
};
