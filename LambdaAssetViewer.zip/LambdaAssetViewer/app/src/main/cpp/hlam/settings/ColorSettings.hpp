// Android-адаптация settings/ColorSettings.hpp из Half-Life Asset Manager.
// Интерфейс GetColor/Add/Set/GetDefaultColor сохранён, но хранилище QSettings/QColor/QObject заменено на std::map:
// значения по умолчанию регистрируются нативным мостом (bridge/ViewerSession.cpp), а изменения цветов приходят из Kotlin через JNI.
#pragma once

#include <map>
#include <string>
#include <vector>

#include <QString>
#include <glm/vec3.hpp>
#include <glm/vec4.hpp>

inline glm::vec3 RGB888ToVector(int r, int g, int b)
{
	return {r / 255.f, g / 255.f, b / 255.f};
}

inline glm::vec4 RGBA8888ToVector(int r, int g, int b, int a)
{
	return {r / 255.f, g / 255.f, b / 255.f, a / 255.f};
}

class ColorSettings final
{
private:
	struct ColorData
	{
		glm::vec4 DefaultColor;
		glm::vec4 Color;
		bool HasAlphaChannel;
	};

	static constexpr glm::vec4 DefaultColor{0, 0, 0, 1};

public:
	std::vector<QString> GetKeys() const
	{
		return _colors.keys();
	}

	glm::vec4 GetDefaultColor(const QString& key) const
	{
		if (_colors.contains(key))
		{
			return _colors.value(key).DefaultColor;
		}

		return DefaultColor;
	}

	glm::vec4 GetColor(const QString& key, const glm::vec4& defaultValue = DefaultColor) const
	{
		if (_colors.contains(key))
		{
			return _colors.value(key).Color;
		}

		return defaultValue;
	}

	bool HasAlphaChannel(const QString& key) const
	{
		if (_colors.contains(key))
		{
			return _colors.value(key).HasAlphaChannel;
		}

		return false;
	}

	void Add(const QString& key, const glm::vec4& defaultColor)
	{
		_colors.insert(key, ColorData{defaultColor, defaultColor, true});
	}

	void Add(const QString& key, const glm::vec3& defaultColor)
	{
		const glm::vec4 rgba{defaultColor, 1};
		_colors.insert(key, ColorData{rgba, rgba, false});
	}

	void Set(const QString& key, const glm::vec4& color)
	{
		if (_colors.contains(key))
		{
			ColorData data = _colors.value(key);
			data.Color = color;
			_colors.insert(key, data);
		}
	}

	void ResetToDefaults()
	{
		for (const auto& key : _colors.keys())
		{
			ColorData data = _colors.value(key);
			data.Color = data.DefaultColor;
			_colors.insert(key, data);
		}
	}

private:
	QMap<QString, ColorData> _colors;
};
