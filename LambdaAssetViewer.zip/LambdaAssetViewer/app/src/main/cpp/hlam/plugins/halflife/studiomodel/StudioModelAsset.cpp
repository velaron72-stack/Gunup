// Android-адаптация plugins/halflife/studiomodel/StudioModelAsset.cpp из Half-Life Asset Manager.
// Перенесены без изменения логики: CreateMainScene/CreateTextureScene, GetCenteredValues, HandleMouseInput (вращение света),
// Tick, SaveEntityToSnapshot/LoadEntityFromSnapshot, центрирование камер. UI-специфичные части (диалоги, вкладки, undo) опущены.
#include <algorithm>
#include <tuple>
#include <vector>

#include <QOpenGLFunctions_1_1>

#include "entity/AxesEntity.hpp"
#include "entity/BackgroundEntity.hpp"
#include "entity/BaseEntity.hpp"
#include "entity/BoundingBoxEntity.hpp"
#include "entity/ClippingBoxEntity.hpp"
#include "entity/CrosshairEntity.hpp"
#include "entity/EntityList.hpp"
#include "entity/GroundEntity.hpp"
#include "entity/GuidelinesEntity.hpp"
#include "entity/HLMVStudioModelEntity.hpp"
#include "entity/PlayerHitboxEntity.hpp"
#include "entity/TextureEntity.hpp"
#include "formats/studiomodel/EditableStudioModel.hpp"
#include "formats/studiomodel/StudioModelRenderer.hpp"
#include "graphics/Scene.hpp"
#include "graphics/SceneContext.hpp"
#include "graphics/TextureLoader.hpp"
#include "plugins/halflife/studiomodel/StudioModelAsset.hpp"
#include "plugins/halflife/studiomodel/StudioModelColors.hpp"
#include "plugins/halflife/studiomodel/settings/StudioModelSettings.hpp"
#include "settings/ApplicationSettings.hpp"
#include "settings/ColorSettings.hpp"
#include "spdlog/logger.h"
#include "utility/WorldTime.hpp"

namespace studiomodel
{
StudioModelAssetProvider::StudioModelAssetProvider(QOpenGLFunctions_1_1* openglFunctions,
	ApplicationSettings* applicationSettings, StudioModelSettings* studioModelSettings)
	: _openglFunctions(openglFunctions)
	, _studioModelSettings(studioModelSettings)
	, _studioModelRenderer(std::make_unique<studiomdl::StudioModelRenderer>(
		  std::make_shared<spdlog::logger>("studiomodelrenderer"), openglFunctions, applicationSettings->GetColorSettings()))
	, _arcBallCamera(std::make_unique<ArcBallCameraOperator>(applicationSettings))
	, _freeLookCamera(std::make_unique<FreeLookCameraOperator>(applicationSettings))
	, _firstPersonCamera(std::make_unique<FirstPersonCameraOperator>(applicationSettings))
{
	_cameraOperators.Add(_arcBallCamera.get());
	_cameraOperators.Add(_freeLookCamera.get());
	_cameraOperators.Add(_firstPersonCamera.get());

	for (auto cameraOperator : _cameraOperators.GetAll())
	{
		auto camera = cameraOperator->GetCamera();
		camera->SetFieldOfView(_studioModelSettings->GetCameraFOV(cameraOperator->GetName().toStdString(), camera->GetFieldOfView()));
	}
}

StudioModelAssetProvider::~StudioModelAssetProvider() = default;

void StudioModelAssetProvider::CreateDeviceObjects()
{
	if (_defaultGroundTexture != 0)
	{
		return;
	}

	_openglFunctions->glGenTextures(1, &_defaultGroundTexture);
	_openglFunctions->glBindTexture(GL_TEXTURE_2D, _defaultGroundTexture);

	const int side = 64;
	const int pixelCount = side * side;

	struct RGB24
	{
		unsigned char r, g, b;
	};

	RGB24 pixels[pixelCount];

	// Тёмно-серая текстура с чёрными линиями по центру (как в оригинале, основана на dev_measuregeneric01b).
	const RGB24 groundColor{90, 90, 90};
	const RGB24 lineColor{0, 0, 0};

	std::fill(std::begin(pixels), std::end(pixels), groundColor);

	for (int edge = 0; edge < 2; ++edge)
	{
		const int middle = (side / 2) - edge;

		for (int i = 0; i < side; ++i)
		{
			pixels[(side * middle) + i] = lineColor;
		}

		for (int i = 0; i < side; ++i)
		{
			pixels[middle + (i * side)] = lineColor;
		}
	}

	_openglFunctions->glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	_openglFunctions->glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, side, side, 0, GL_RGB, GL_UNSIGNED_BYTE, pixels);
	_openglFunctions->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	_openglFunctions->glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
}

void StudioModelAssetProvider::DestroyDeviceObjects()
{
	if (_defaultGroundTexture != 0)
	{
		_openglFunctions->glDeleteTextures(1, &_defaultGroundTexture);
		_defaultGroundTexture = 0;
	}
}

static std::tuple<glm::vec3, glm::vec3, float, float> GetCenteredValues(
	const HLMVStudioModelEntity& entity, Axis axis, bool positive)
{
	glm::vec3 min, max;
	entity.ExtractBbox(min, max);

	const glm::vec3 size = max - min;

	const glm::vec3 targetOrigin{0, 0, min.z + (size.z / 2)};
	glm::vec3 cameraOrigin{targetOrigin};

	const float distance{std::clamp(std::max({size.x, size.y, size.z}), -1000.f, 1000.f)};

	cameraOrigin[static_cast<int>(axis)] += distance * (positive ? 1 : -1);

	float pitch = 0;
	float yaw = 0;

	switch (axis)
	{
	case Axis::X:
		yaw = positive ? 180 : 0;
		break;

	case Axis::Y:
		yaw = positive ? 90 : 270;
		break;

	case Axis::Z:
		pitch = positive ? -90 : 90;
		yaw = 180;
		break;
	}

	return {targetOrigin, cameraOrigin, pitch, yaw};
}

StudioModelAsset::StudioModelAsset(std::string&& fileName, StudioModelAssetProvider* provider,
	graphics::TextureLoader* textureLoader, QOpenGLFunctions_1_1* openglFunctions, WorldTime* worldTime,
	ISoundSystem* soundSystem, ApplicationSettings* applicationSettings, StudioModelSettings* studioModelSettings,
	std::unique_ptr<studiomdl::EditableStudioModel>&& editableStudioModel)
	: _fileName(std::move(fileName))
	, _provider(provider)
	, _textureLoader(textureLoader)
	, _editableStudioModel(std::move(editableStudioModel))
	, _entityContext(std::make_unique<EntityContext>(this, worldTime, provider->GetStudioModelRenderer(), soundSystem,
		  applicationSettings, studioModelSettings))
{
	(void)openglFunctions;

	CreateMainScene();
	CreateTextureScene();

	_currentScene = _scene.get();

	_provider->GetCameraOperators()->CameraChanged = [this](SceneCameraOperator*, SceneCameraOperator* current)
	{
		_scene->SetCurrentCamera(current);
	};
}

StudioModelAsset::~StudioModelAsset()
{
	_provider->GetCameraOperators()->CameraChanged = nullptr;
}

studiomdl::StudioModelRenderer* StudioModelAsset::GetStudioModelRenderer() const
{
	return _provider->GetStudioModelRenderer();
}

bool StudioModelAsset::CameraIsFirstPerson() const
{
	return _provider->CameraIsFirstPerson();
}

void StudioModelAsset::CreateMainScene()
{
	_scene = std::make_unique<graphics::Scene>("Scene", _entityContext.get());
	_scenes.push_back(_scene.get());

	_backgroundEntity = _scene->GetEntityList()->Create<BackgroundEntity>();
	_axesEntity = _scene->GetEntityList()->Create<AxesEntity>();
	_modelEntity = _scene->GetEntityList()->Create<HLMVStudioModelEntity>(GetEditableStudioModel());
	_groundEntity = _scene->GetEntityList()->Create<GroundEntity>();
	_playerHitboxEntity = _scene->GetEntityList()->Create<PlayerHitboxEntity>();
	_boundingBoxEntity = _scene->GetEntityList()->Create<BoundingBoxEntity>();
	_clippingBoxEntity = _scene->GetEntityList()->Create<ClippingBoxEntity>();
	_crosshairEntity = _scene->GetEntityList()->Create<CrosshairEntity>();
	_guidelinesEntity = _scene->GetEntityList()->Create<GuidelinesEntity>();
}

void StudioModelAsset::CreateTextureScene()
{
	_textureScene = std::make_unique<graphics::Scene>("Texture", _entityContext.get());
	_scenes.push_back(_textureScene.get());

	_textureEntity = _textureScene->GetEntityList()->Create<TextureEntity>();

	_textureCameraOperator = std::make_unique<TextureCameraOperator>(_textureEntity);
	_textureScene->SetCurrentCamera(_textureCameraOperator.get());
}

void StudioModelAsset::CreateDeviceObjects(graphics::SceneContext& sc)
{
	_provider->CreateDeviceObjects();

	for (auto scene : _scenes)
	{
		scene->CreateDeviceObjects(sc);
	}
}

void StudioModelAsset::DestroyDeviceObjects(graphics::SceneContext& sc)
{
	for (auto it = _scenes.rbegin(), end = _scenes.rend(); it != end; ++it)
	{
		(*it)->DestroyDeviceObjects(sc);
	}
}

void StudioModelAsset::SetCurrentSceneIndex(int index)
{
	if (index < 0 || index >= static_cast<int>(_scenes.size()))
	{
		index = 0;
	}

	_currentScene = _scenes[static_cast<std::size_t>(index)];
}

void StudioModelAsset::Tick()
{
	for (auto scene : _scenes)
	{
		scene->Tick();
	}
}

void StudioModelAsset::UpdateWindowSize(unsigned int width, unsigned int height)
{
	for (auto scene : _scenes)
	{
		scene->UpdateWindowSize(width, height);
	}
}

void StudioModelAsset::InitializeCameras()
{
	_isInitialized = true;

	const auto [targetOrigin, cameraOrigin, pitch, yaw] = GetCenteredValues(*_modelEntity, Axis::X, true);

	auto cameraOperators = _provider->GetCameraOperators();

	for (int i = 0; i < cameraOperators->Count(); ++i)
	{
		const auto cameraOperator = cameraOperators->Get(i);
		cameraOperator->CenterView(targetOrigin, cameraOrigin, pitch, yaw);
	}

	auto studioModelSettings = _entityContext->StudioSettings;

	// Автоопределение view-моделей по префиксу имени файла «v_», как в оригинале.
	std::string baseName = _fileName;
	if (const auto slash = baseName.find_last_of("/\\"); slash != std::string::npos)
	{
		baseName = baseName.substr(slash + 1);
	}

	const bool isViewModel = baseName.size() >= 2 && (baseName[0] == 'v' || baseName[0] == 'V') && baseName[1] == '_';

	if (studioModelSettings->ShouldAutodetectViewmodels() && isViewModel)
	{
		cameraOperators->SetCurrent(_provider->GetFirstPersonCameraOperator());
	}
	else
	{
		cameraOperators->SetCurrent(_provider->GetArcBallCameraOperator());
	}

	_scene->SetCurrentCamera(cameraOperators->GetCurrent());
}

void StudioModelAsset::OnCenterView(Axis axis, bool positive)
{
	if (auto cameraOperator = _provider->GetCameraOperators()->GetCurrent(); cameraOperator)
	{
		const auto [targetOrigin, cameraOrigin, pitch, yaw] = GetCenteredValues(*_modelEntity, axis, positive);
		cameraOperator->CenterView(targetOrigin, cameraOrigin, pitch, yaw);
	}
}

bool StudioModelAsset::HandleMouseInput(QMouseEvent* event, bool lightEditing)
{
	if (GetCurrentScene() != GetScene())
	{
		return false;
	}

	const bool controlHeld = (event->modifiers() & Qt::KeyboardModifier::ControlModifier) || lightEditing;

	if (controlHeld && (event->buttons() & Qt::MouseButton::LeftButton))
	{
		if (event->button() == Qt::MouseButton::LeftButton)
		{
			_lightVectorCoordinates.x = static_cast<float>(event->x());
			_lightVectorCoordinates.y = static_cast<float>(event->y());
		}
		else
		{
			glm::vec3 direction = GetScene()->SkyLight.Direction;

			const float DELTA = 0.05f;

			if (event->modifiers() & Qt::KeyboardModifier::ShiftModifier)
			{
				if (_lightVectorCoordinates.x <= event->x())
				{
					direction.z += DELTA;
				}
				else
				{
					direction.z -= DELTA;
				}

				_lightVectorCoordinates.x = static_cast<float>(event->x());

				direction.z = std::clamp(direction.z, -1.0f, 1.0f);
			}
			else
			{
				if (_lightVectorCoordinates.x <= event->x())
				{
					direction.x += DELTA;
				}
				else
				{
					direction.x -= DELTA;
				}

				if (_lightVectorCoordinates.y <= event->y())
				{
					direction.y += DELTA;
				}
				else
				{
					direction.y -= DELTA;
				}

				_lightVectorCoordinates.x = static_cast<float>(event->x());
				_lightVectorCoordinates.y = static_cast<float>(event->y());

				direction.x = std::clamp(direction.x, -1.0f, 1.0f);
				direction.y = std::clamp(direction.y, -1.0f, 1.0f);
			}

			GetScene()->SkyLight.Direction = direction;
		}

		return true;
	}

	return false;
}

void StudioModelAsset::MouseEvent(QMouseEvent& event, bool lightEditing)
{
	if (HandleMouseInput(&event, lightEditing))
	{
		return;
	}

	if (_currentScene)
	{
		if (auto cameraOperator = _currentScene->GetCurrentCamera(); cameraOperator)
		{
			cameraOperator->MouseEvent(event);
		}
	}
}

void StudioModelAsset::WheelEvent(QWheelEvent& event)
{
	if (_currentScene)
	{
		if (auto cameraOperator = _currentScene->GetCurrentCamera(); cameraOperator)
		{
			cameraOperator->WheelEvent(event);
		}
	}
}

void StudioModelAsset::FlipNormals()
{
	for (auto& bodypart : _editableStudioModel->Bodyparts)
	{
		for (auto& model : bodypart->Models)
		{
			for (auto& normal : model.Normals)
			{
				normal.Vertex = -normal.Vertex;
			}
		}
	}
}

void StudioModelAsset::SaveEntityToSnapshot(StateSnapshot* snapshot)
{
	auto model = _modelEntity->GetEditableModel();

	const int sequenceIndex = _modelEntity->GetSequence();

	if (sequenceIndex >= 0 && sequenceIndex < static_cast<int>(model->Sequences.size()))
	{
		snapshot->SetValue("entity.sequence", sequenceIndex);
		snapshot->SetValue("entity.frame", _modelEntity->GetFrame());
	}

	snapshot->SetValue("entity.skin", _modelEntity->GetSkin());
	snapshot->SetValue("entity.body", _modelEntity->GetBodygroup());

	for (int i = 0; i < STUDIO_MAX_CONTROLLERS; ++i)
	{
		snapshot->SetValue(QString{"entity.bonecontroller" + std::to_string(i)}, _modelEntity->GetControllerValue(i));
	}

	snapshot->SetValue("entity.mouth", static_cast<int>(_modelEntity->GetMouth()));

	for (int i = 0; i < STUDIO_MAX_BLENDERS; ++i)
	{
		snapshot->SetValue(QString{"entity.blender" + std::to_string(i)}, _modelEntity->GetBlendingValue(i));
	}
}

void StudioModelAsset::LoadEntityFromSnapshot(StateSnapshot* snapshot)
{
	auto model = _modelEntity->GetEditableModel();

	const int sequenceIndex = snapshot->Value("entity.sequence", -1).toInt();

	if (sequenceIndex >= 0 && sequenceIndex < static_cast<int>(model->Sequences.size()))
	{
		_modelEntity->SetSequence(sequenceIndex);
		_modelEntity->SetFrame(snapshot->Value("entity.frame").toFloat());
	}
	else
	{
		_modelEntity->SetSequence(0);
	}

	_modelEntity->SetSkin(snapshot->Value("entity.skin").toInt());
	_modelEntity->SetCompoundBodyValue(snapshot->Value("entity.body").toInt());

	for (int i = 0; i < STUDIO_MAX_CONTROLLERS; ++i)
	{
		_modelEntity->SetController(i, snapshot->Value(QString{"entity.bonecontroller" + std::to_string(i)}).toFloat());
	}

	_modelEntity->SetMouth(static_cast<std::uint8_t>(snapshot->Value("entity.mouth").toInt()));

	for (int i = 0; i < STUDIO_MAX_BLENDERS; ++i)
	{
		_modelEntity->SetBlending(i, snapshot->Value(QString{"entity.blender" + std::to_string(i)}).toFloat());
	}
}
}
