// Android-адаптация plugins/halflife/studiomodel/StudioModelAsset.hpp (+ StudioModelAssetProvider) из Half-Life Asset Manager.
// В оригинале Asset — QObject, связанный с вкладками, док-панелями, undo-стеком и QOpenGLWidget. Здесь сохранены:
//   * набор сущностей и сцен (Scene + Texture), создаваемых так же, как StudioModelAsset::CreateMainScene/CreateTextureScene;
//   * флаги отображения (CurrentRenderMode, ShowHitboxes, ShowBones ...), читаемые перенесёнными сущностями и StudioModelRenderer;
//   * логика центрирования камеры (GetCenteredValues), поворота источника света мышью/касанием, переключения операторов камеры.
// Всё, что относилось к Qt-виджетам и сигналам, переехало в Kotlin; вызовы приходят через bridge/ViewerSession.
#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include <glm/vec2.hpp>

#include "graphics/GraphicsConstants.hpp"
#include "graphics/OpenGL.hpp"
#include "ui/StateSnapshot.hpp"
#include "ui/camera_operators/ArcBallCameraOperator.hpp"
#include "ui/camera_operators/CameraOperators.hpp"
#include "ui/camera_operators/FirstPersonCameraOperator.hpp"
#include "ui/camera_operators/FreeLookCameraOperator.hpp"
#include "ui/camera_operators/TextureCameraOperator.hpp"
#include "utility/mathlib.hpp"

class ApplicationSettings;
class AxesEntity;
class BackgroundEntity;
class BoundingBoxEntity;
class ClippingBoxEntity;
class CrosshairEntity;
class EntityContext;
class GroundEntity;
class GuidelinesEntity;
class HLMVStudioModelEntity;
class IFileSystem;
class ISoundSystem;
class PlayerHitboxEntity;
class StudioModelSettings;
class TextureEntity;
class WorldTime;
class QOpenGLFunctions_1_1;

namespace graphics
{
class Scene;
class SceneContext;
class TextureLoader;
}

namespace studiomdl
{
class EditableStudioModel;
class StudioModelRenderer;
}

namespace studiomodel
{
/**
*	@brief Общие для всех ассетов ресурсы: рендерер MDL, операторы камеры, текстура пола по умолчанию.
*	Соответствует StudioModelAssetProvider оригинала.
*/
class StudioModelAssetProvider final
{
public:
	StudioModelAssetProvider(QOpenGLFunctions_1_1* openglFunctions, ApplicationSettings* applicationSettings,
		StudioModelSettings* studioModelSettings);
	~StudioModelAssetProvider();

	StudioModelAssetProvider(const StudioModelAssetProvider&) = delete;
	StudioModelAssetProvider& operator=(const StudioModelAssetProvider&) = delete;

	void CreateDeviceObjects();
	void DestroyDeviceObjects();

	GLuint GetDefaultGroundTexture() const { return _defaultGroundTexture; }

	studiomdl::StudioModelRenderer* GetStudioModelRenderer() const { return _studioModelRenderer.get(); }
	StudioModelSettings* GetStudioModelSettings() const { return _studioModelSettings; }

	CameraOperators* GetCameraOperators() { return &_cameraOperators; }
	ArcBallCameraOperator* GetArcBallCameraOperator() const { return _arcBallCamera.get(); }
	FreeLookCameraOperator* GetFreeLookCameraOperator() const { return _freeLookCamera.get(); }
	FirstPersonCameraOperator* GetFirstPersonCameraOperator() const { return _firstPersonCamera.get(); }

	bool CameraIsFirstPerson() const { return _cameraOperators.GetCurrent() == _firstPersonCamera.get(); }

private:
	QOpenGLFunctions_1_1* const _openglFunctions;
	StudioModelSettings* const _studioModelSettings;
	std::unique_ptr<studiomdl::StudioModelRenderer> _studioModelRenderer;

	std::unique_ptr<ArcBallCameraOperator> _arcBallCamera;
	std::unique_ptr<FreeLookCameraOperator> _freeLookCamera;
	std::unique_ptr<FirstPersonCameraOperator> _firstPersonCamera;
	CameraOperators _cameraOperators;

	GLuint _defaultGroundTexture{0};
};

/**
*	@brief Один открытый MDL: модель, файловая система, две сцены (3D-вид и просмотр текстуры).
*/
class StudioModelAsset final
{
public:
	StudioModelAsset(std::string&& fileName, StudioModelAssetProvider* provider, graphics::TextureLoader* textureLoader,
		QOpenGLFunctions_1_1* openglFunctions, WorldTime* worldTime, ISoundSystem* soundSystem,
		ApplicationSettings* applicationSettings, StudioModelSettings* studioModelSettings,
		std::unique_ptr<studiomdl::EditableStudioModel>&& editableStudioModel);
	~StudioModelAsset();

	StudioModelAsset(const StudioModelAsset&) = delete;
	StudioModelAsset& operator=(const StudioModelAsset&) = delete;

	const std::string& GetFileName() const { return _fileName; }
	void SetFileName(std::string&& fileName) { _fileName = std::move(fileName); }

	StudioModelAssetProvider* GetProvider() const { return _provider; }
	studiomdl::StudioModelRenderer* GetStudioModelRenderer() const;
	studiomdl::EditableStudioModel* GetEditableStudioModel() const { return _editableStudioModel.get(); }

	HLMVStudioModelEntity* GetEntity() { return _modelEntity.get(); }
	GroundEntity* GetGroundEntity() { return _groundEntity.get(); }
	BackgroundEntity* GetBackgroundEntity() { return _backgroundEntity.get(); }
	AxesEntity* GetAxesEntity() { return _axesEntity.get(); }
	PlayerHitboxEntity* GetPlayerHitboxEntity() { return _playerHitboxEntity.get(); }
	BoundingBoxEntity* GetBoundingBoxEntity() { return _boundingBoxEntity.get(); }
	ClippingBoxEntity* GetClippingBoxEntity() { return _clippingBoxEntity.get(); }
	CrosshairEntity* GetCrosshairEntity() { return _crosshairEntity.get(); }
	GuidelinesEntity* GetGuidelinesEntity() { return _guidelinesEntity.get(); }
	TextureEntity* GetTextureEntity() { return _textureEntity.get(); }
	TextureCameraOperator* GetTextureCameraOperator() { return _textureCameraOperator.get(); }

	graphics::Scene* GetScene() { return _scene.get(); }
	graphics::Scene* GetTextureScene() { return _textureScene.get(); }
	graphics::Scene* GetCurrentScene() { return _currentScene; }
	void SetCurrentSceneIndex(int index);
	int GetCurrentSceneIndex() const { return _currentScene == _textureScene.get() ? 1 : 0; }

	bool CameraIsFirstPerson() const;

	void CreateDeviceObjects(graphics::SceneContext& sc);
	void DestroyDeviceObjects(graphics::SceneContext& sc);

	void Tick();
	void UpdateWindowSize(unsigned int width, unsigned int height);

	/// Первичная настройка камер после загрузки (OnActivated оригинала при первом показе).
	void InitializeCameras();

	/// Эквивалент OnCenterView(axis, positive) из оригинала (кнопки «Центрировать вид»).
	void OnCenterView(Axis axis, bool positive);

	/// Ctrl+ЛКМ в оригинале; на Android включается кнопкой «Свет» (lightEditing).
	bool HandleMouseInput(QMouseEvent* event, bool lightEditing);
	void MouseEvent(QMouseEvent& event, bool lightEditing);
	void WheelEvent(QWheelEvent& event);

	/// Эквивалент FlipNormalsCommand (без undo): переворачивает нормали всех вершин модели.
	void FlipNormals();

	void SaveEntityToSnapshot(StateSnapshot* snapshot);
	void LoadEntityFromSnapshot(StateSnapshot* snapshot);

public:
	RenderMode CurrentRenderMode = RenderMode::TEXTURE_SHADED;

	bool ShowHitboxes = false;
	bool ShowBones = false;
	bool ShowAttachments = false;
	bool ShowEyePosition = false;

	bool EnableBackfaceCulling = true;
	bool ShowWireframeOverlay = false;
	bool DrawShadows = false;
	bool FixShadowZFighting = false;
	bool ShowNormals = false;

	int DrawSingleBoneIndex = -1;
	int DrawSingleAttachmentIndex = -1;
	int DrawSingleHitboxIndex = -1;

	bool PlaySequence = true;

private:
	void CreateMainScene();
	void CreateTextureScene();

private:
	std::string _fileName;
	StudioModelAssetProvider* const _provider;
	graphics::TextureLoader* const _textureLoader;
	std::unique_ptr<studiomdl::EditableStudioModel> _editableStudioModel;
	std::unique_ptr<EntityContext> _entityContext;

	std::vector<graphics::Scene*> _scenes;
	std::unique_ptr<graphics::Scene> _scene;
	std::unique_ptr<graphics::Scene> _textureScene;
	graphics::Scene* _currentScene{};

	std::shared_ptr<HLMVStudioModelEntity> _modelEntity;
	std::shared_ptr<AxesEntity> _axesEntity;
	std::shared_ptr<BackgroundEntity> _backgroundEntity;
	std::shared_ptr<GroundEntity> _groundEntity;
	std::shared_ptr<PlayerHitboxEntity> _playerHitboxEntity;
	std::shared_ptr<BoundingBoxEntity> _boundingBoxEntity;
	std::shared_ptr<ClippingBoxEntity> _clippingBoxEntity;
	std::shared_ptr<CrosshairEntity> _crosshairEntity;
	std::shared_ptr<GuidelinesEntity> _guidelinesEntity;
	std::shared_ptr<TextureEntity> _textureEntity;
	std::unique_ptr<TextureCameraOperator> _textureCameraOperator;

	glm::vec2 _lightVectorCoordinates{0};
	bool _isInitialized = false;
};
}
