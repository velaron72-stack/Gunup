// Android-адаптация StudioModelSettings из Half-Life Asset Manager: Qt (QSet/QString/BaseSettings) заменён стандартной библиотекой.
// Поля и значения по умолчанию сохранены; сохранение настроек выполняет Kotlin (SharedPreferences).
#pragma once

#include <set>
#include <string>
#include <unordered_map>

enum class XashOpenMode
{
	Ask = 0,
	Always,
	Never
};

class StudioModelSettings final
{
public:
	static constexpr bool DefaultAutodetectViewmodels{true};
	static constexpr int MinimumGroundLength = 0;
	static constexpr int MaximumGroundLength = 2048;
	static constexpr int DefaultGroundLength = 100;

	bool ShouldAutodetectViewmodels() const { return _autodetectViewModels; }
	void SetAutodetectViewmodels(bool value) { _autodetectViewModels = value; }

	int GetGroundLength() const { return _groundLength; }
	void SetGroundLength(int value) { _groundLength = value; }

	XashOpenMode GetXashOpenMode() const { return _xashOpenMode; }
	void SetXashOpenMode(XashOpenMode mode) { _xashOpenMode = mode; }

	float GetCameraFOV(const std::string& name, float defaultValue) const
	{
		auto it = _cameraFov.find(name);
		return it != _cameraFov.end() ? it->second : defaultValue;
	}

	void SetCameraFOV(const std::string& name, float value) { _cameraFov[name] = value; }

	const std::set<int>& GetSoundEventIds() const { return _soundEventIds; }
	void SetSoundEventIds(std::set<int>&& soundEventIds) { _soundEventIds = std::move(soundEventIds); }

private:
	bool _autodetectViewModels{DefaultAutodetectViewmodels};
	int _groundLength = DefaultGroundLength;
	XashOpenMode _xashOpenMode = XashOpenMode::Ask;
	std::set<int> _soundEventIds;
	std::unordered_map<std::string, float> _cameraFov;
};
