// Шим <qopengl.h>: типы и константы OpenGL берутся из заголовков gl4es.
#pragma once

#include <GL/gl.h>
#include <GL/glext.h>
