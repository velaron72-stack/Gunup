// Шим spdlog: logger с тем же интерфейсом вызова, что использует StudioModelRenderer (SPDLOG_LOGGER_CALL).
// Сообщения уходят в logcat и во внутренний журнал (панель «Сообщения» в Android-интерфейсе).
#pragma once

#include <memory>
#include <string>
#include <string_view>

#include "fmt/format.h"

namespace spdlog
{
namespace level
{
enum level_enum
{
	trace = 0,
	debug,
	info,
	warn,
	err,
	critical,
	off
};
} // namespace level

namespace detail
{
// Определена в bridge/MessageLog.cpp.
void EmitLogMessage(level::level_enum level, const std::string& loggerName, const std::string& message);
} // namespace detail

class logger
{
public:
	explicit logger(std::string name) : _name(std::move(name)) {}

	template<typename... Args>
	void log(level::level_enum level, std::string_view pattern, const Args&... args)
	{
		detail::EmitLogMessage(level, _name, fmt::format(pattern, args...));
	}

	const std::string& name() const { return _name; }

private:
	std::string _name;
};
} // namespace spdlog

#define SPDLOG_LOGGER_CALL(logger, level, ...) (logger)->log(level, __VA_ARGS__)
