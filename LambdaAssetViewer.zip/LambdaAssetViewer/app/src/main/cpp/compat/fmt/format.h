// Шим fmt: минимальный fmt::format / fmt::format_to для спецификаторов, которые используют перенесённые исходники HLAM
// ("{}" и "{:0>2}", "{:x}", "{:.2f}"). Полноценный fmt в среде сборки недоступен.
#pragma once

#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <iterator>
#include <string>
#include <string_view>
#include <type_traits>
#include <vector>

namespace fmt
{
namespace detail
{
struct Spec
{
	char fill = ' ';
	char align = 0;
	bool zero = false;
	int width = 0;
	int precision = -1;
	char type = 0;
};

inline Spec ParseSpec(std::string_view text)
{
	Spec spec;
	std::size_t i = 0;
	auto isAlign = [](char c) { return c == '<' || c == '>' || c == '^'; };
	if (text.size() >= 2 && isAlign(text[1]))
	{
		spec.fill = text[0];
		spec.align = text[1];
		i = 2;
	}
	else if (!text.empty() && isAlign(text[0]))
	{
		spec.align = text[0];
		i = 1;
	}
	if (i < text.size() && text[i] == '0')
	{
		spec.zero = true;
		++i;
	}
	while (i < text.size() && text[i] >= '0' && text[i] <= '9')
	{
		spec.width = spec.width * 10 + (text[i] - '0');
		++i;
	}
	if (i < text.size() && text[i] == '.')
	{
		++i;
		spec.precision = 0;
		while (i < text.size() && text[i] >= '0' && text[i] <= '9')
		{
			spec.precision = spec.precision * 10 + (text[i] - '0');
			++i;
		}
	}
	if (i < text.size())
	{
		spec.type = text[i];
	}
	return spec;
}

inline std::string Pad(std::string value, const Spec& spec, bool numeric)
{
	if (static_cast<int>(value.size()) >= spec.width)
	{
		return value;
	}
	const std::size_t padding = static_cast<std::size_t>(spec.width) - value.size();
	char fill = spec.fill;
	char align = spec.align;
	if (spec.zero && numeric && align == 0)
	{
		fill = '0';
		align = '>';
	}
	if (align == 0)
	{
		align = numeric ? '>' : '<';
	}
	if (align == '<')
	{
		return value + std::string(padding, fill);
	}
	if (align == '>')
	{
		return std::string(padding, fill) + value;
	}
	const std::size_t left = padding / 2;
	return std::string(left, fill) + value + std::string(padding - left, fill);
}

template<typename T>
inline std::string FormatIntegral(T value, const Spec& spec)
{
	char buffer[40];
	if (spec.type == 'x' || spec.type == 'X')
	{
		std::snprintf(buffer, sizeof(buffer), spec.type == 'x' ? "%llx" : "%llX", static_cast<unsigned long long>(value));
	}
	else if constexpr (std::is_signed_v<T>)
	{
		std::snprintf(buffer, sizeof(buffer), "%lld", static_cast<long long>(value));
	}
	else
	{
		std::snprintf(buffer, sizeof(buffer), "%llu", static_cast<unsigned long long>(value));
	}
	return Pad(buffer, spec, true);
}

inline std::string FormatFloating(double value, const Spec& spec)
{
	char buffer[64];
	if (spec.precision >= 0)
	{
		std::snprintf(buffer, sizeof(buffer), "%.*f", spec.precision, value);
	}
	else
	{
		std::snprintf(buffer, sizeof(buffer), "%g", value);
	}
	return Pad(buffer, spec, true);
}

template<typename T>
inline std::string FormatValue(const T& value, const Spec& spec)
{
	using D = std::decay_t<T>;
	if constexpr (std::is_same_v<D, bool>)
	{
		return Pad(value ? "true" : "false", spec, false);
	}
	else if constexpr (std::is_same_v<D, char>)
	{
		return Pad(std::string(1, value), spec, false);
	}
	else if constexpr (std::is_enum_v<D>)
	{
		return FormatIntegral(static_cast<std::underlying_type_t<D>>(value), spec);
	}
	else if constexpr (std::is_integral_v<D>)
	{
		return FormatIntegral(value, spec);
	}
	else if constexpr (std::is_floating_point_v<D>)
	{
		return FormatFloating(static_cast<double>(value), spec);
	}
	else if constexpr (std::is_same_v<D, std::filesystem::path>)
	{
		return Pad(value.string(), spec, false);
	}
	else if constexpr (std::is_convertible_v<D, std::string_view>)
	{
		return Pad(std::string(std::string_view(value)), spec, false);
	}
	else
	{
		return "<?>";
	}
}

inline void FormatAt(std::string&, std::size_t, std::string_view) {}

template<typename T, typename... Rest>
inline void FormatAt(std::string& out, std::size_t index, std::string_view spec, const T& first, const Rest&... rest)
{
	if (index == 0)
	{
		out += FormatValue(first, ParseSpec(spec));
		return;
	}
	FormatAt(out, index - 1, spec, rest...);
}
} // namespace detail

template<typename... Args>
inline std::string format(std::string_view pattern, const Args&... args)
{
	std::string out;
	std::size_t nextArg = 0;
	for (std::size_t i = 0; i < pattern.size(); ++i)
	{
		const char c = pattern[i];
		if (c == '{')
		{
			if (i + 1 < pattern.size() && pattern[i + 1] == '{')
			{
				out += '{';
				++i;
				continue;
			}
			const std::size_t close = pattern.find('}', i);
			if (close == std::string_view::npos)
			{
				out += c;
				continue;
			}
			std::string_view inner = pattern.substr(i + 1, close - i - 1);
			std::string_view spec;
			const std::size_t colon = inner.find(':');
			if (colon != std::string_view::npos)
			{
				spec = inner.substr(colon + 1);
			}
			detail::FormatAt(out, nextArg++, spec, args...);
			i = close;
		}
		else if (c == '}' && i + 1 < pattern.size() && pattern[i + 1] == '}')
		{
			out += '}';
			++i;
		}
		else
		{
			out += c;
		}
	}
	return out;
}

template<typename OutputIt, typename... Args>
inline OutputIt format_to(OutputIt it, std::string_view pattern, const Args&... args)
{
	const std::string text = format(pattern, args...);
	for (char c : text)
	{
		*it++ = c;
	}
	return it;
}
} // namespace fmt
