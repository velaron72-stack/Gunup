// glm-lite: минимальная замена GLM (header-only), покрывающая только подмножество API,
// которое используют перенесённые из Half-Life Asset Manager исходники.
// Семантика (порядок аргументов quat, колонко-ориентированные матрицы, правосторонняя
// система с глубиной [-1;1], формулы lookAt/perspective/ortho/slerp/eulerAngles) повторяет GLM 0.9.9.
// Причина замены: GLM отсутствует в окружении сборки (vcpkg недоступен), а в исходниках HLAM
// вектора glm::vec3 используются прямо в бинарных структурах формата MDL (sizeof(vec3) == 12).
#pragma once

#include <cmath>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <type_traits>

namespace glm
{
template<typename T>
constexpr T epsilon() { return std::numeric_limits<T>::epsilon(); }

template<typename T>
constexpr T pi() { return static_cast<T>(3.14159265358979323846264338327950288); }

inline float radians(float degrees) { return degrees * (pi<float>() / 180.0f); }
inline double radians(double degrees) { return degrees * (pi<double>() / 180.0); }
inline float degrees(float radiansValue) { return radiansValue * (180.0f / pi<float>()); }

struct vec2;
struct vec3;
struct vec4;

struct vec2
{
	union { float x; float r; float s; };
	union { float y; float g; float t; };

	vec2() = default;
	template<typename U, typename = std::enable_if_t<std::is_arithmetic_v<U>>>
	constexpr vec2(U scalar) : x(static_cast<float>(scalar)), y(static_cast<float>(scalar)) {}
	template<typename A, typename B, typename = std::enable_if_t<std::is_arithmetic_v<A> && std::is_arithmetic_v<B>>>
	constexpr vec2(A x_, B y_) : x(static_cast<float>(x_)), y(static_cast<float>(y_)) {}
	constexpr vec2(const vec3& v);
	constexpr vec2(const vec4& v);

	static constexpr int length() { return 2; }

	float& operator[](int i) { return (&x)[i]; }
	const float& operator[](int i) const { return (&x)[i]; }
	vec2& operator+=(const vec2& o) { x += o.x; y += o.y; return *this; }
	vec2& operator-=(const vec2& o) { x -= o.x; y -= o.y; return *this; }
	vec2& operator*=(float s) { x *= s; y *= s; return *this; }
	vec2& operator/=(float s) { x /= s; y /= s; return *this; }
};

inline constexpr vec2 operator+(const vec2& a, const vec2& b) { return vec2(a.x + b.x, a.y + b.y); }
inline constexpr vec2 operator-(const vec2& a, const vec2& b) { return vec2(a.x - b.x, a.y - b.y); }
inline constexpr vec2 operator*(const vec2& a, const vec2& b) { return vec2(a.x * b.x, a.y * b.y); }
inline constexpr vec2 operator*(const vec2& a, float s) { return vec2(a.x * s, a.y * s); }
inline constexpr vec2 operator*(float s, const vec2& a) { return vec2(a.x * s, a.y * s); }
inline constexpr vec2 operator/(const vec2& a, float s) { return vec2(a.x / s, a.y / s); }
inline constexpr vec2 operator-(const vec2& a) { return vec2(-a.x, -a.y); }
inline constexpr bool operator==(const vec2& a, const vec2& b) { return a.x == b.x && a.y == b.y; }
inline constexpr bool operator!=(const vec2& a, const vec2& b) { return !(a == b); }

struct ivec2
{
	int x, y;

	ivec2() = default;
	template<typename U, typename = std::enable_if_t<std::is_arithmetic_v<U>>>
	constexpr ivec2(U scalar) : x(static_cast<int>(scalar)), y(static_cast<int>(scalar)) {}
	template<typename A, typename B, typename = std::enable_if_t<std::is_arithmetic_v<A> && std::is_arithmetic_v<B>>>
	constexpr ivec2(A x_, B y_) : x(static_cast<int>(x_)), y(static_cast<int>(y_)) {}
};

inline constexpr ivec2 operator+(const ivec2& a, const ivec2& b) { return ivec2(a.x + b.x, a.y + b.y); }
inline constexpr ivec2 operator-(const ivec2& a, const ivec2& b) { return ivec2(a.x - b.x, a.y - b.y); }
inline constexpr bool operator==(const ivec2& a, const ivec2& b) { return a.x == b.x && a.y == b.y; }
inline constexpr bool operator!=(const ivec2& a, const ivec2& b) { return !(a == b); }

struct vec3
{
	union { float x; float r; float s; };
	union { float y; float g; float t; };
	union { float z; float b; float p; };

	vec3() = default;
	template<typename U, typename = std::enable_if_t<std::is_arithmetic_v<U>>>
	constexpr vec3(U scalar) : x(static_cast<float>(scalar)), y(static_cast<float>(scalar)), z(static_cast<float>(scalar)) {}
	template<typename A, typename B, typename C, typename = std::enable_if_t<std::is_arithmetic_v<A> && std::is_arithmetic_v<B> && std::is_arithmetic_v<C>>>
	constexpr vec3(A x_, B y_, C z_) : x(static_cast<float>(x_)), y(static_cast<float>(y_)), z(static_cast<float>(z_)) {}
	constexpr vec3(const vec2& v, float z_) : x(v.x), y(v.y), z(z_) {}
	constexpr vec3(const vec4& v);

	static constexpr int length() { return 3; }

	float& operator[](int i) { return (&x)[i]; }
	const float& operator[](int i) const { return (&x)[i]; }
	vec3& operator+=(const vec3& o) { x += o.x; y += o.y; z += o.z; return *this; }
	vec3& operator-=(const vec3& o) { x -= o.x; y -= o.y; z -= o.z; return *this; }
	vec3& operator*=(const vec3& o) { x *= o.x; y *= o.y; z *= o.z; return *this; }
	vec3& operator*=(float s) { x *= s; y *= s; z *= s; return *this; }
	vec3& operator/=(float s) { x /= s; y /= s; z /= s; return *this; }
};

inline constexpr vec3 operator+(const vec3& a, const vec3& b) { return vec3(a.x + b.x, a.y + b.y, a.z + b.z); }
inline constexpr vec3 operator+(const vec3& a, float s) { return vec3(a.x + s, a.y + s, a.z + s); }
inline constexpr vec3 operator-(const vec3& a, const vec3& b) { return vec3(a.x - b.x, a.y - b.y, a.z - b.z); }
inline constexpr vec3 operator-(const vec3& a, float s) { return vec3(a.x - s, a.y - s, a.z - s); }
inline constexpr vec3 operator*(const vec3& a, const vec3& b) { return vec3(a.x * b.x, a.y * b.y, a.z * b.z); }
inline constexpr vec3 operator*(const vec3& a, float s) { return vec3(a.x * s, a.y * s, a.z * s); }
inline constexpr vec3 operator*(float s, const vec3& a) { return vec3(a.x * s, a.y * s, a.z * s); }
inline constexpr vec3 operator/(const vec3& a, const vec3& b) { return vec3(a.x / b.x, a.y / b.y, a.z / b.z); }
inline constexpr vec3 operator/(const vec3& a, float s) { return vec3(a.x / s, a.y / s, a.z / s); }
inline constexpr vec3 operator/(float s, const vec3& a) { return vec3(s / a.x, s / a.y, s / a.z); }
inline constexpr vec3 operator-(const vec3& a) { return vec3(-a.x, -a.y, -a.z); }
inline constexpr bool operator==(const vec3& a, const vec3& b) { return a.x == b.x && a.y == b.y && a.z == b.z; }
inline constexpr bool operator!=(const vec3& a, const vec3& b) { return !(a == b); }

struct vec4
{
	union { float x; float r; float s; };
	union { float y; float g; float t; };
	union { float z; float b; float p; };
	union { float w; float a; float q; };

	vec4() = default;
	template<typename U, typename = std::enable_if_t<std::is_arithmetic_v<U>>>
	constexpr vec4(U scalar) : x(static_cast<float>(scalar)), y(static_cast<float>(scalar)), z(static_cast<float>(scalar)), w(static_cast<float>(scalar)) {}
	template<typename A, typename B, typename C, typename D, typename = std::enable_if_t<std::is_arithmetic_v<A> && std::is_arithmetic_v<B> && std::is_arithmetic_v<C> && std::is_arithmetic_v<D>>>
	constexpr vec4(A x_, B y_, C z_, D w_) : x(static_cast<float>(x_)), y(static_cast<float>(y_)), z(static_cast<float>(z_)), w(static_cast<float>(w_)) {}
	constexpr vec4(const vec3& v, float w_) : x(v.x), y(v.y), z(v.z), w(w_) {}

	static constexpr int length() { return 4; }

	float& operator[](int i) { return (&x)[i]; }
	const float& operator[](int i) const { return (&x)[i]; }
	vec4& operator+=(const vec4& o) { x += o.x; y += o.y; z += o.z; w += o.w; return *this; }
	vec4& operator-=(const vec4& o) { x -= o.x; y -= o.y; z -= o.z; w -= o.w; return *this; }
	vec4& operator*=(float s) { x *= s; y *= s; z *= s; w *= s; return *this; }
	vec4& operator/=(float s) { x /= s; y /= s; z /= s; w /= s; return *this; }
};

// Конструкторы усечения vec4 -> vec3 -> vec2 неявные, как в GLM по умолчанию (без GLM_FORCE_EXPLICIT_CTOR).
inline constexpr vec2::vec2(const vec3& v) : x(v.x), y(v.y) {}
inline constexpr vec2::vec2(const vec4& v) : x(v.x), y(v.y) {}
inline constexpr vec3::vec3(const vec4& v) : x(v.x), y(v.y), z(v.z) {}

inline constexpr vec4 operator+(const vec4& a, const vec4& b) { return vec4(a.x + b.x, a.y + b.y, a.z + b.z, a.w + b.w); }
inline constexpr vec4 operator-(const vec4& a, const vec4& b) { return vec4(a.x - b.x, a.y - b.y, a.z - b.z, a.w - b.w); }
inline constexpr vec4 operator*(const vec4& a, const vec4& b) { return vec4(a.x * b.x, a.y * b.y, a.z * b.z, a.w * b.w); }
inline constexpr vec4 operator*(const vec4& a, float s) { return vec4(a.x * s, a.y * s, a.z * s, a.w * s); }
inline constexpr vec4 operator*(float s, const vec4& a) { return vec4(a.x * s, a.y * s, a.z * s, a.w * s); }
inline constexpr vec4 operator/(const vec4& a, float s) { return vec4(a.x / s, a.y / s, a.z / s, a.w / s); }
inline constexpr vec4 operator-(const vec4& a) { return vec4(-a.x, -a.y, -a.z, -a.w); }
inline constexpr bool operator==(const vec4& a, const vec4& b) { return a.x == b.x && a.y == b.y && a.z == b.z && a.w == b.w; }
inline constexpr bool operator!=(const vec4& a, const vec4& b) { return !(a == b); }

// Усечение vec4 -> vec3 как в GLM: glm::vec3(someVec4). Реализовано шаблонным конструктором-конвертером.
inline float dot(const vec2& a, const vec2& b) { return a.x * b.x + a.y * b.y; }
inline float dot(const vec3& a, const vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
inline float dot(const vec4& a, const vec4& b) { return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w; }
inline float length(const vec2& v) { return std::sqrt(dot(v, v)); }
inline float length(const vec3& v) { return std::sqrt(dot(v, v)); }
inline float length(const vec4& v) { return std::sqrt(dot(v, v)); }
inline vec2 normalize(const vec2& v) { return v * (1.0f / std::sqrt(dot(v, v))); }
inline vec3 normalize(const vec3& v) { return v * (1.0f / std::sqrt(dot(v, v))); }
inline vec4 normalize(const vec4& v) { return v * (1.0f / std::sqrt(dot(v, v))); }
inline vec3 cross(const vec3& x, const vec3& y)
{
	return vec3(
		x.y * y.z - y.y * x.z,
		x.z * y.x - y.z * x.x,
		x.x * y.y - y.x * x.y);
}
inline float distance(const vec3& a, const vec3& b) { return length(b - a); }

struct mat4
{
	vec4 col[4];

	mat4() = default;
	template<typename U, typename = std::enable_if_t<std::is_arithmetic_v<U>>>
	constexpr mat4(U d)
		: col{vec4(static_cast<float>(d), 0.f, 0.f, 0.f), vec4(0.f, static_cast<float>(d), 0.f, 0.f), vec4(0.f, 0.f, static_cast<float>(d), 0.f), vec4(0.f, 0.f, 0.f, static_cast<float>(d))}
	{
	}
	constexpr mat4(const vec4& c0, const vec4& c1, const vec4& c2, const vec4& c3) : col{c0, c1, c2, c3} {}

	vec4& operator[](int i) { return col[i]; }
	const vec4& operator[](int i) const { return col[i]; }
};

using mat4x4 = mat4;

inline vec4 operator*(const mat4& m, const vec4& v)
{
	return m.col[0] * v.x + m.col[1] * v.y + m.col[2] * v.z + m.col[3] * v.w;
}

inline mat4 operator*(const mat4& a, const mat4& b)
{
	return mat4(a * b.col[0], a * b.col[1], a * b.col[2], a * b.col[3]);
}

inline mat4& operator*=(mat4& a, const mat4& b)
{
	a = a * b;
	return a;
}

inline mat4 operator*(const mat4& m, float s)
{
	return mat4(m.col[0] * s, m.col[1] * s, m.col[2] * s, m.col[3] * s);
}

template<typename T>
inline T identity();

template<>
inline mat4 identity<mat4>() { return mat4(1.0f); }

// Кватернион: порядок аргументов конструктора (w, x, y, z) как в GLM.
struct quat
{
	float x, y, z, w;

	quat() = default;
	template<typename A, typename B, typename C, typename D, typename = std::enable_if_t<std::is_arithmetic_v<A> && std::is_arithmetic_v<B> && std::is_arithmetic_v<C> && std::is_arithmetic_v<D>>>
	constexpr quat(A w_, B x_, C y_, D z_) : x(static_cast<float>(x_)), y(static_cast<float>(y_)), z(static_cast<float>(z_)), w(static_cast<float>(w_)) {}

	// Конструктор из углов Эйлера (pitch = x, yaw = y, roll = z), в радианах.
	explicit quat(const vec3& eulerAngle)
	{
		const vec3 c(std::cos(eulerAngle.x * 0.5f), std::cos(eulerAngle.y * 0.5f), std::cos(eulerAngle.z * 0.5f));
		const vec3 s(std::sin(eulerAngle.x * 0.5f), std::sin(eulerAngle.y * 0.5f), std::sin(eulerAngle.z * 0.5f));

		w = c.x * c.y * c.z + s.x * s.y * s.z;
		x = s.x * c.y * c.z - c.x * s.y * s.z;
		y = c.x * s.y * c.z + s.x * c.y * s.z;
		z = c.x * c.y * s.z - s.x * s.y * c.z;
	}
};

inline quat operator-(const quat& q) { return quat(-q.w, -q.x, -q.y, -q.z); }
inline quat operator+(const quat& a, const quat& b) { return quat(a.w + b.w, a.x + b.x, a.y + b.y, a.z + b.z); }
inline quat operator*(float s, const quat& q) { return quat(q.w * s, q.x * s, q.y * s, q.z * s); }
inline quat operator*(const quat& q, float s) { return quat(q.w * s, q.x * s, q.y * s, q.z * s); }
inline quat operator/(const quat& q, float s) { return quat(q.w / s, q.x / s, q.y / s, q.z / s); }
inline float dot(const quat& a, const quat& b) { return a.x * b.x + a.y * b.y + a.z * b.z + a.w * b.w; }

inline quat operator*(const quat& p, const quat& q)
{
	return quat(
		p.w * q.w - p.x * q.x - p.y * q.y - p.z * q.z,
		p.w * q.x + p.x * q.w + p.y * q.z - p.z * q.y,
		p.w * q.y + p.y * q.w + p.z * q.x - p.x * q.z,
		p.w * q.z + p.z * q.w + p.x * q.y - p.y * q.x);
}

inline quat& operator*=(quat& p, const quat& q)
{
	p = p * q;
	return p;
}

inline float length(const quat& q) { return std::sqrt(dot(q, q)); }
inline quat normalize(const quat& q)
{
	const float len = length(q);
	if (len <= 0.0f)
	{
		return quat(1.0f, 0.0f, 0.0f, 0.0f);
	}
	return q * (1.0f / len);
}
inline quat conjugate(const quat& q) { return quat(q.w, -q.x, -q.y, -q.z); }
inline quat inverse(const quat& q) { return conjugate(q) / dot(q, q); }

inline vec3 operator*(const quat& q, const vec3& v)
{
	const vec3 quatVector(q.x, q.y, q.z);
	const vec3 uv(cross(quatVector, v));
	const vec3 uuv(cross(quatVector, uv));
	return v + ((uv * q.w) + uuv) * 2.0f;
}

inline quat slerp(const quat& x, const quat& y, float a)
{
	quat z = y;
	float cosTheta = dot(x, y);

	if (cosTheta < 0.0f)
	{
		z = -y;
		cosTheta = -cosTheta;
	}

	if (cosTheta > 1.0f - epsilon<float>())
	{
		return quat(
			x.w + (z.w - x.w) * a,
			x.x + (z.x - x.x) * a,
			x.y + (z.y - x.y) * a,
			x.z + (z.z - x.z) * a);
	}

	const float angle = std::acos(cosTheta);
	return (std::sin((1.0f - a) * angle) * x + std::sin(a * angle) * z) / std::sin(angle);
}

inline mat4 mat4_cast(const quat& q)
{
	mat4 Result(1.0f);
	const float qxx = q.x * q.x;
	const float qyy = q.y * q.y;
	const float qzz = q.z * q.z;
	const float qxz = q.x * q.z;
	const float qxy = q.x * q.y;
	const float qyz = q.y * q.z;
	const float qwx = q.w * q.x;
	const float qwy = q.w * q.y;
	const float qwz = q.w * q.z;

	Result[0][0] = 1.0f - 2.0f * (qyy + qzz);
	Result[0][1] = 2.0f * (qxy + qwz);
	Result[0][2] = 2.0f * (qxz - qwy);

	Result[1][0] = 2.0f * (qxy - qwz);
	Result[1][1] = 1.0f - 2.0f * (qxx + qzz);
	Result[1][2] = 2.0f * (qyz + qwx);

	Result[2][0] = 2.0f * (qxz + qwy);
	Result[2][1] = 2.0f * (qyz - qwx);
	Result[2][2] = 1.0f - 2.0f * (qxx + qyy);
	return Result;
}

inline mat4 toMat4(const quat& q) { return mat4_cast(q); }

inline float pitch(const quat& q)
{
	const float y = 2.0f * (q.y * q.z + q.w * q.x);
	const float x = q.w * q.w - q.x * q.x - q.y * q.y + q.z * q.z;

	if (std::fabs(x) < epsilon<float>() && std::fabs(y) < epsilon<float>())
	{
		return 2.0f * std::atan2(q.x, q.w);
	}

	return std::atan2(y, x);
}

inline float yaw(const quat& q)
{
	float v = -2.0f * (q.x * q.z - q.w * q.y);
	if (v < -1.0f) v = -1.0f;
	if (v > 1.0f) v = 1.0f;
	return std::asin(v);
}

inline float roll(const quat& q)
{
	const float y = 2.0f * (q.x * q.y + q.w * q.z);
	const float x = q.w * q.w + q.x * q.x - q.y * q.y - q.z * q.z;

	if (std::fabs(x) < epsilon<float>() && std::fabs(y) < epsilon<float>())
	{
		return 0.0f;
	}

	return std::atan2(y, x);
}

inline vec3 eulerAngles(const quat& x) { return vec3(pitch(x), yaw(x), roll(x)); }

inline mat4 translate(const mat4& m, const vec3& v)
{
	mat4 Result(m);
	Result[3] = m[0] * v.x + m[1] * v.y + m[2] * v.z + m[3];
	return Result;
}

inline mat4 translate(const vec3& v) { return translate(mat4(1.0f), v); }

inline mat4 scale(const mat4& m, const vec3& v)
{
	mat4 Result;
	Result[0] = m[0] * v.x;
	Result[1] = m[1] * v.y;
	Result[2] = m[2] * v.z;
	Result[3] = m[3];
	return Result;
}

inline mat4 scale(const vec3& v) { return scale(mat4(1.0f), v); }

inline mat4 rotate(const mat4& m, float angle, const vec3& v)
{
	const float c = std::cos(angle);
	const float s = std::sin(angle);

	const vec3 axis(normalize(v));
	const vec3 temp(axis * (1.0f - c));

	mat4 Rotate;
	Rotate[0][0] = c + temp.x * axis.x;
	Rotate[0][1] = temp.x * axis.y + s * axis.z;
	Rotate[0][2] = temp.x * axis.z - s * axis.y;

	Rotate[1][0] = temp.y * axis.x - s * axis.z;
	Rotate[1][1] = c + temp.y * axis.y;
	Rotate[1][2] = temp.y * axis.z + s * axis.x;

	Rotate[2][0] = temp.z * axis.x + s * axis.y;
	Rotate[2][1] = temp.z * axis.y - s * axis.x;
	Rotate[2][2] = c + temp.z * axis.z;

	mat4 Result;
	Result[0] = m[0] * Rotate[0][0] + m[1] * Rotate[0][1] + m[2] * Rotate[0][2];
	Result[1] = m[0] * Rotate[1][0] + m[1] * Rotate[1][1] + m[2] * Rotate[1][2];
	Result[2] = m[0] * Rotate[2][0] + m[1] * Rotate[2][1] + m[2] * Rotate[2][2];
	Result[3] = m[3];
	return Result;
}

inline mat4 rotate(float angle, const vec3& v) { return rotate(mat4(1.0f), angle, v); }

inline mat4 perspective(float fovy, float aspect, float zNear, float zFar)
{
	const float tanHalfFovy = std::tan(fovy / 2.0f);

	mat4 Result(0.0f);
	Result[0][0] = 1.0f / (aspect * tanHalfFovy);
	Result[1][1] = 1.0f / tanHalfFovy;
	Result[2][2] = -(zFar + zNear) / (zFar - zNear);
	Result[2][3] = -1.0f;
	Result[3][2] = -(2.0f * zFar * zNear) / (zFar - zNear);
	return Result;
}

inline mat4 ortho(float left, float right, float bottom, float top, float zNear, float zFar)
{
	mat4 Result(1.0f);
	Result[0][0] = 2.0f / (right - left);
	Result[1][1] = 2.0f / (top - bottom);
	Result[2][2] = -2.0f / (zFar - zNear);
	Result[3][0] = -(right + left) / (right - left);
	Result[3][1] = -(top + bottom) / (top - bottom);
	Result[3][2] = -(zFar + zNear) / (zFar - zNear);
	return Result;
}

inline mat4 lookAt(const vec3& eye, const vec3& center, const vec3& up)
{
	const vec3 f(normalize(center - eye));
	const vec3 s(normalize(cross(f, up)));
	const vec3 u(cross(s, f));

	mat4 Result(1.0f);
	Result[0][0] = s.x;
	Result[1][0] = s.y;
	Result[2][0] = s.z;
	Result[0][1] = u.x;
	Result[1][1] = u.y;
	Result[2][1] = u.z;
	Result[0][2] = -f.x;
	Result[1][2] = -f.y;
	Result[2][2] = -f.z;
	Result[3][0] = -dot(s, eye);
	Result[3][1] = -dot(u, eye);
	Result[3][2] = dot(f, eye);
	return Result;
}

inline mat4 inverse(const mat4& m)
{
	const float Coef00 = m[2][2] * m[3][3] - m[3][2] * m[2][3];
	const float Coef02 = m[1][2] * m[3][3] - m[3][2] * m[1][3];
	const float Coef03 = m[1][2] * m[2][3] - m[2][2] * m[1][3];

	const float Coef04 = m[2][1] * m[3][3] - m[3][1] * m[2][3];
	const float Coef06 = m[1][1] * m[3][3] - m[3][1] * m[1][3];
	const float Coef07 = m[1][1] * m[2][3] - m[2][1] * m[1][3];

	const float Coef08 = m[2][1] * m[3][2] - m[3][1] * m[2][2];
	const float Coef10 = m[1][1] * m[3][2] - m[3][1] * m[1][2];
	const float Coef11 = m[1][1] * m[2][2] - m[2][1] * m[1][2];

	const float Coef12 = m[2][0] * m[3][3] - m[3][0] * m[2][3];
	const float Coef14 = m[1][0] * m[3][3] - m[3][0] * m[1][3];
	const float Coef15 = m[1][0] * m[2][3] - m[2][0] * m[1][3];

	const float Coef16 = m[2][0] * m[3][2] - m[3][0] * m[2][2];
	const float Coef18 = m[1][0] * m[3][2] - m[3][0] * m[1][2];
	const float Coef19 = m[1][0] * m[2][2] - m[2][0] * m[1][2];

	const float Coef20 = m[2][0] * m[3][1] - m[3][0] * m[2][1];
	const float Coef22 = m[1][0] * m[3][1] - m[3][0] * m[1][1];
	const float Coef23 = m[1][0] * m[2][1] - m[2][0] * m[1][1];

	const vec4 Fac0(Coef00, Coef00, Coef02, Coef03);
	const vec4 Fac1(Coef04, Coef04, Coef06, Coef07);
	const vec4 Fac2(Coef08, Coef08, Coef10, Coef11);
	const vec4 Fac3(Coef12, Coef12, Coef14, Coef15);
	const vec4 Fac4(Coef16, Coef16, Coef18, Coef19);
	const vec4 Fac5(Coef20, Coef20, Coef22, Coef23);

	const vec4 Vec0(m[1][0], m[0][0], m[0][0], m[0][0]);
	const vec4 Vec1(m[1][1], m[0][1], m[0][1], m[0][1]);
	const vec4 Vec2(m[1][2], m[0][2], m[0][2], m[0][2]);
	const vec4 Vec3(m[1][3], m[0][3], m[0][3], m[0][3]);

	const vec4 Inv0(Vec1 * Fac0 - Vec2 * Fac1 + Vec3 * Fac2);
	const vec4 Inv1(Vec0 * Fac0 - Vec2 * Fac3 + Vec3 * Fac4);
	const vec4 Inv2(Vec0 * Fac1 - Vec1 * Fac3 + Vec3 * Fac5);
	const vec4 Inv3(Vec0 * Fac2 - Vec1 * Fac4 + Vec2 * Fac5);

	const vec4 SignA(+1, -1, +1, -1);
	const vec4 SignB(-1, +1, -1, +1);
	const mat4 Inverse(Inv0 * SignA, Inv1 * SignB, Inv2 * SignA, Inv3 * SignB);

	const vec4 Row0(Inverse[0][0], Inverse[1][0], Inverse[2][0], Inverse[3][0]);
	const vec4 Dot0(m[0] * Row0);
	const float Dot1 = (Dot0.x + Dot0.y) + (Dot0.z + Dot0.w);

	const float OneOverDeterminant = 1.0f / Dot1;
	return Inverse * OneOverDeterminant;
}

inline const float* value_ptr(const vec2& v) { return &v.x; }
inline float* value_ptr(vec2& v) { return &v.x; }
inline const float* value_ptr(const vec3& v) { return &v.x; }
inline float* value_ptr(vec3& v) { return &v.x; }
inline const float* value_ptr(const vec4& v) { return &v.x; }
inline float* value_ptr(vec4& v) { return &v.x; }
inline const float* value_ptr(const mat4& m) { return &(m.col[0].x); }
inline float* value_ptr(mat4& m) { return &(m.col[0].x); }
} // namespace glm
