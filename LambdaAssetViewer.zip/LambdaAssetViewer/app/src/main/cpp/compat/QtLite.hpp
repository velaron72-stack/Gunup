// QtLite: микро-шим подмножества Qt, нужного перенесённым из HLAM операторам камеры, снимкам состояния и сцене.
// Qt на Android не используется: интерфейс реализован на Kotlin, а события касаний преобразуются в QMouseEvent/QWheelEvent
// на стороне JNI-моста (см. bridge/ViewerBridge.cpp), поэтому код операторов камеры остаётся без изменений.
#pragma once

#include <algorithm>
#include <cstddef>
#include <map>
#include <string>
#include <utility>
#include <vector>

#define Q_OBJECT
#define signals public
#define slots
#define emit
#define Q_SLOTS
#define Q_SIGNALS public
#define Q_DECLARE_METATYPE(x)
#define Q_UNUSED(x) (void)(x)
#define Q_DECLARE_OPERATORS_FOR_FLAGS(Flags)

class QObject
{
public:
	QObject() = default;
	explicit QObject(QObject*) {}
	virtual ~QObject() = default;
	void setParent(QObject*) {}
};

class QWidget : public QObject
{
public:
	QWidget() = default;
};

class QString
{
public:
	QString() = default;
	QString(const char* s) : _s(s ? s : "") {}
	QString(const std::string& s) : _s(s) {}
	const std::string& toStdString() const { return _s; }
	const char* c_str() const { return _s.c_str(); }
	bool isEmpty() const { return _s.empty(); }
	bool operator==(const QString& o) const { return _s == o._s; }
	bool operator!=(const QString& o) const { return _s != o._s; }
	bool operator<(const QString& o) const { return _s < o._s; }

private:
	std::string _s;
};

#define QStringLiteral(s) QString(s)

using QStringList = std::vector<QString>;

class QVariant
{
public:
	QVariant() = default;
	QVariant(float v) : _v(v) {}
	QVariant(double v) : _v(v) {}
	QVariant(int v) : _v(v) {}
	QVariant(bool v) : _v(v ? 1.0 : 0.0) {}

	float toFloat() const { return static_cast<float>(_v); }
	double toDouble() const { return _v; }
	int toInt() const { return static_cast<int>(_v); }
	bool toBool() const { return _v != 0.0; }

private:
	double _v = 0.0;
};

template<typename K, typename V>
class QMap
{
public:
	std::vector<K> keys() const
	{
		std::vector<K> result;
		for (const auto& entry : _map)
		{
			result.push_back(entry.first);
		}
		return result;
	}
	bool contains(const K& key) const { return _map.find(key) != _map.end(); }
	V value(const K& key, const V& defaultValue = V{}) const
	{
		auto it = _map.find(key);
		return it != _map.end() ? it->second : defaultValue;
	}
	void insert(const K& key, const V& value) { _map[key] = value; }
	void remove(const K& key) { _map.erase(key); }
	void clear() { _map.clear(); }

private:
	std::map<K, V> _map;
};

template<typename T>
class QVector
{
public:
	QVector() = default;
	explicit QVector(int size) : _items(static_cast<std::size_t>(size)) {}

	int size() const { return static_cast<int>(_items.size()); }
	void append(const T& item) { _items.push_back(item); }
	bool contains(const T& item) const { return std::find(_items.begin(), _items.end(), item) != _items.end(); }
	int indexOf(const T& item) const
	{
		auto it = std::find(_items.begin(), _items.end(), item);
		return it == _items.end() ? -1 : static_cast<int>(it - _items.begin());
	}
	T& operator[](int index) { return _items[static_cast<std::size_t>(index)]; }
	const T& operator[](int index) const { return _items[static_cast<std::size_t>(index)]; }
	typename std::vector<T>::iterator begin() { return _items.begin(); }
	typename std::vector<T>::iterator end() { return _items.end(); }
	typename std::vector<T>::const_iterator begin() const { return _items.begin(); }
	typename std::vector<T>::const_iterator end() const { return _items.end(); }

private:
	std::vector<T> _items;
};

class QPoint
{
public:
	QPoint() = default;
	QPoint(int x, int y) : _x(x), _y(y) {}
	int x() const { return _x; }
	int y() const { return _y; }
	bool isNull() const { return _x == 0 && _y == 0; }
	QPoint operator/(int divisor) const { return QPoint(_x / divisor, _y / divisor); }

private:
	int _x = 0;
	int _y = 0;
};

template<typename Enum>
class QFlags
{
public:
	constexpr QFlags() = default;
	constexpr QFlags(Enum flag) : _value(static_cast<int>(flag)) {}
	constexpr explicit QFlags(int value) : _value(value) {}

	constexpr operator int() const { return _value; }

	QFlags& operator|=(QFlags other) { _value |= other._value; return *this; }
	QFlags& operator&=(int mask) { _value &= mask; return *this; }
	constexpr QFlags operator|(QFlags other) const { return QFlags(_value | other._value); }
	constexpr QFlags operator&(QFlags other) const { return QFlags(_value & other._value); }
	constexpr QFlags operator&(Enum flag) const { return QFlags(_value & static_cast<int>(flag)); }
	constexpr QFlags operator&(int mask) const { return QFlags(_value & mask); }
	constexpr bool testFlag(Enum flag) const { return (_value & static_cast<int>(flag)) == static_cast<int>(flag) && static_cast<int>(flag) != 0; }

	QFlags& setFlag(Enum flag, bool on = true)
	{
		if (on)
		{
			_value |= static_cast<int>(flag);
		}
		else
		{
			_value &= ~static_cast<int>(flag);
		}
		return *this;
	}

private:
	int _value = 0;
};

namespace Qt
{
enum MouseButton
{
	NoButton = 0x0,
	LeftButton = 0x1,
	RightButton = 0x2,
	MiddleButton = 0x4,
	BackButton = 0x8,
	ExtraButton1 = BackButton
};

enum KeyboardModifier
{
	NoModifier = 0x0,
	ShiftModifier = 0x02000000,
	ControlModifier = 0x04000000,
	AltModifier = 0x08000000
};

using MouseButtons = QFlags<MouseButton>;
using KeyboardModifiers = QFlags<KeyboardModifier>;
} // namespace Qt

inline Qt::MouseButtons operator|(Qt::MouseButton a, Qt::MouseButton b) { return Qt::MouseButtons(a) | Qt::MouseButtons(b); }
inline Qt::KeyboardModifiers operator|(Qt::KeyboardModifier a, Qt::KeyboardModifier b) { return Qt::KeyboardModifiers(a) | Qt::KeyboardModifiers(b); }

class QEvent
{
public:
	enum Type
	{
		None = 0,
		MouseButtonPress = 2,
		MouseButtonRelease = 3,
		MouseMove = 5,
		Wheel = 31
	};

	explicit QEvent(Type type) : _type(type) {}
	virtual ~QEvent() = default;

	Type type() const { return _type; }
	void accept() { _accepted = true; }
	void ignore() { _accepted = false; }
	bool isAccepted() const { return _accepted; }

private:
	Type _type;
	bool _accepted = true;
};

class QMouseEvent : public QEvent
{
public:
	QMouseEvent(Type type, const QPoint& position, Qt::MouseButton button, Qt::MouseButtons buttons, Qt::KeyboardModifiers modifiers)
		: QEvent(type)
		, _position(position)
		, _button(button)
		, _buttons(buttons)
		, _modifiers(modifiers)
	{
	}

	int x() const { return _position.x(); }
	int y() const { return _position.y(); }
	QPoint pos() const { return _position; }
	Qt::MouseButton button() const { return _button; }
	Qt::MouseButtons buttons() const { return _buttons; }
	Qt::KeyboardModifiers modifiers() const { return _modifiers; }

private:
	QPoint _position;
	Qt::MouseButton _button;
	Qt::MouseButtons _buttons;
	Qt::KeyboardModifiers _modifiers;
};

class QWheelEvent : public QEvent
{
public:
	explicit QWheelEvent(const QPoint& angleDelta) : QEvent(Wheel), _angleDelta(angleDelta) {}

	QPoint angleDelta() const { return _angleDelta; }

private:
	QPoint _angleDelta;
};
