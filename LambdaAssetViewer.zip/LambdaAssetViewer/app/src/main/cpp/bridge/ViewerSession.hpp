// ViewerSession — нативное ядро Android-порта Half-Life Asset Manager.
// Связь с HLAM: объединяет роли Application/AssetManager/SceneWidget оригинала для одного открытого MDL:
//   * владеет GL-обвязкой (QOpenGLFunctions_1_1 → gl4es), TextureLoader, StudioModelAssetProvider и StudioModelAsset;
//   * выполняет тики (WorldTime + Scene::Tick) и отрисовку текущей сцены (Scene::Draw) на GL-потоке GLSurfaceView;
//   * превращает команды Kotlin-интерфейса в те же изменения сущностей, что делали док-панели Qt (см. docs/FEATURE_MAP.md);
//   * отдаёт данные панелей (последовательности, части тела, текстуры, кости ...) в виде JSON.
// Потокобезопасность: все публичные методы берут общий мьютекс; GL-вызовы выполняются только на GL-потоке.
#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "bridge/MemoryFileSystem.hpp"
#include "ui/StateSnapshot.hpp"
#include "utility/WorldTime.hpp"

class ApplicationSettings;
class QOpenGLFunctions_1_1;
class StudioModelSettings;

namespace graphics
{
class SceneContext;
class TextureLoader;
}

namespace studiomdl
{
class EditableStudioModel;
}

namespace studiomodel
{
class StudioModelAsset;
class StudioModelAssetProvider;
}

namespace bridge
{
class AndroidSoundSystem;

class ViewerSession final
{
public:
	static ViewerSession& Instance();

	~ViewerSession();
	ViewerSession(const ViewerSession&) = delete;
	ViewerSession& operator=(const ViewerSession&) = delete;

	// ---- GL-поток ----
	void OnSurfaceCreated();
	void OnSurfaceChanged(int width, int height);
	void OnDrawFrame();

	// ---- любой поток ----
	/// Загружает MDL из памяти. Возвращает JSON {"ok":bool,"error":"...","warnings":[...]} .
	std::string LoadModel(const std::string& displayName, std::vector<std::uint8_t>&& mainFile, MemoryFileSystem::Loader siblingLoader);
	void CloseModel();
	bool HasModel();

	int Command(int cmd, int a, int b, float f, const std::string& s);
	std::string Query(int query, int a, int b);
	void FillState(float* out, int count);
	void Touch(int kind, float x, float y, float extra);

	// Текстуры (просмотр/экспорт/импорт).
	bool TextureInfo(int index, int* out3);
	std::vector<std::uint32_t> TextureArgb(int index);
	std::vector<std::uint8_t> TextureBmp(int index);
	std::string ImportBmp(int index, const std::uint8_t* data, std::size_t size);
	std::string ImportArgb(int index, int width, int height, const std::uint32_t* argb);
	bool SetSceneImage(int kind, const std::string& name, int width, int height, const std::uint32_t* argb);

	/// Сериализует текущую модель (ConvertFromEditable). textureFile пуст, если отдельного T.mdl нет.
	bool Serialize(const std::string& fileName, std::vector<std::uint8_t>& mainFile, std::vector<std::uint8_t>& textureFile);

	void SetSoundCallback(std::function<void(const std::string&, float, int)> callback);

private:
	ViewerSession();

	void RegisterDefaultColors();
	void EnsureGlObjects();
	void ApplyPendingModel();
	void RunGlTasks();
	void QueueGl(std::function<void()> task);
	void ResetBlenders();
	bool SetFlag(int flag, bool value);
	void ApplyColor(int colorId, std::uint32_t argb);

	std::string QuerySequences();
	std::string QueryBodyparts();
	std::string QueryTextures();
	std::string QueryBones();
	std::string QueryControllers();
	std::string QueryAttachments();
	std::string QueryHitboxes();
	std::string QueryInfo();
	std::string QueryColors();
	std::string QueryActivities();
	std::string QueryCameras();

private:
	mutable std::recursive_mutex _mutex;

	std::unique_ptr<ApplicationSettings> _appSettings;
	std::unique_ptr<StudioModelSettings> _studioSettings;
	WorldTime _worldTime;
	std::unique_ptr<AndroidSoundSystem> _soundSystem;

	std::unique_ptr<QOpenGLFunctions_1_1> _gl;
	std::unique_ptr<graphics::TextureLoader> _textureLoader;
	std::unique_ptr<graphics::SceneContext> _sceneContext;
	std::unique_ptr<studiomodel::StudioModelAssetProvider> _provider;
	std::unique_ptr<studiomodel::StudioModelAsset> _asset;

	std::unique_ptr<studiomdl::EditableStudioModel> _pendingModel;
	std::string _pendingName;
	bool _closeRequested = false;

	std::vector<std::function<void()>> _glTasks;
	std::vector<StateSnapshot> _savedViews;

	std::string _fileName;
	int _width = 1;
	int _height = 1;
	bool _glInitialized = false;
	bool _lightEditing = false;
	bool _initialLayoutDone = false;
	int _modelRevision = 0;
	int _editRevision = 0;
	int _blendMode = 0;
	double _clockOrigin = -1.0;
	double _fpsTime = 0.0;
	int _fpsFrames = 0;
	float _fps = 0.f;
};
}
