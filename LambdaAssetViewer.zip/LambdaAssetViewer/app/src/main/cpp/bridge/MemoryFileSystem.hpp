// Файловая система в памяти для Storage Access Framework.
// Связь с HLAM: реализует IFileSystem (filesystem/IFileSystem.hpp), которым StudioModelIO ищет файлы T.mdl (внешние текстуры)
// и NN.mdl (группы последовательностей). Android не даёт обычных путей к документам SAF, поэтому соседние файлы
// запрашиваются у Kotlin по имени (колбэк), а найденные байты превращаются в FILE* через fmemopen — код загрузчика не меняется.
#pragma once

#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include "filesystem/IFileSystem.hpp"

namespace bridge
{
class MemoryFileSystem final : public IFileSystem
{
public:
	/// Возвращает true и заполняет out, если файл с таким именем найден рядом с открытой моделью.
	using Loader = std::function<bool(const std::string& baseName, std::vector<std::uint8_t>& out)>;

	explicit MemoryFileSystem(Loader loader);
	~MemoryFileSystem() override = default;

	void AddFile(const std::string& name, std::vector<std::uint8_t>&& data);

	bool HasSearchPath(std::string_view path) const override { return false; }
	void AddSearchPath(std::string&& path) override {}
	void RemoveSearchPath(std::string_view path) override {}
	void RemoveAllSearchPaths() override {}
	std::string GetAbsolutePath(std::string_view fileName) override { return std::string{fileName}; }
	bool FileExists(const std::string& fileName) const override;
	FilePtr TryOpenAbsolute(const std::string& fileName, bool binary, bool exclusive = false) const override;
	FilePtr TryOpen(std::string_view fileName, bool binary, bool exclusive = false) const override;

private:
	std::shared_ptr<std::vector<std::uint8_t>> Find(const std::string& fileName) const;

	Loader _loader;
	mutable std::mutex _mutex;
	mutable std::map<std::string, std::shared_ptr<std::vector<std::uint8_t>>> _files;
};
}
