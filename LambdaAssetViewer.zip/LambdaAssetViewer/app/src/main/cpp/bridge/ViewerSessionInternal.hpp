// Общие включения реализации ViewerSession (ViewerSession.cpp и ViewerQueries.cpp).
#pragma once

#include <cstdio>
#include <filesystem>
#include <stdexcept>

#include "bridge/JsonWriter.hpp"
#include "utility/IOUtils.hpp"
