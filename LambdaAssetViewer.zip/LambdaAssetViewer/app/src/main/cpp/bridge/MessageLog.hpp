// Журнал сообщений нативного слоя.
// Связь с HLAM: аналог панели «Messages» (QtLogSink) — сюда приходят сообщения StudioModelRenderer, загрузчика MDL и моста.
// Сообщения дублируются в logcat и доступны Kotlin-интерфейсу через Q_MESSAGES.
#pragma once

#include <string>

namespace bridge
{
void LogMessage(int level, const std::string& source, const std::string& message);
void LogInfo(const std::string& message);
void LogError(const std::string& message);
std::string GetLogText();
void ClearLog();
}
