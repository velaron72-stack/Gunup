// См. MessageLog.hpp. Реализация spdlog::detail::EmitLogMessage для шима spdlog.
#include "bridge/MessageLog.hpp"

#include <deque>
#include <mutex>

#include "spdlog/logger.h"

#ifdef __ANDROID__
#include <android/log.h>
#else
#include <cstdio>
#endif

namespace
{
std::mutex g_mutex;
std::deque<std::string> g_lines;
constexpr std::size_t MaxLines = 500;
const char* const LevelNames[] = {"TRACE", "DEBUG", "INFO", "WARN", "ERROR", "CRITICAL", "OFF"};
}

namespace bridge
{
void LogMessage(int level, const std::string& source, const std::string& message)
{
	if (level < 0 || level > 6)
	{
		level = 2;
	}

	const std::string line = std::string{"["} + LevelNames[level] + "] " + source + ": " + message;

	{
		std::lock_guard<std::mutex> guard(g_mutex);
		g_lines.push_back(line);

		while (g_lines.size() > MaxLines)
		{
			g_lines.pop_front();
		}
	}

#ifdef __ANDROID__
	const int priority = level >= 4 ? ANDROID_LOG_ERROR : (level == 3 ? ANDROID_LOG_WARN : ANDROID_LOG_INFO);
	__android_log_print(priority, "LambdaViewer", "%s", line.c_str());
#else
	std::fprintf(stderr, "%s\n", line.c_str());
#endif
}

void LogInfo(const std::string& message)
{
	LogMessage(2, "viewer", message);
}

void LogError(const std::string& message)
{
	LogMessage(4, "viewer", message);
}

std::string GetLogText()
{
	std::lock_guard<std::mutex> guard(g_mutex);
	std::string text;

	for (const auto& line : g_lines)
	{
		text += line;
		text += '\n';
	}

	return text;
}

void ClearLog()
{
	std::lock_guard<std::mutex> guard(g_mutex);
	g_lines.clear();
}
}

namespace spdlog::detail
{
void EmitLogMessage(level::level_enum level, const std::string& loggerName, const std::string& message)
{
	bridge::LogMessage(static_cast<int>(level), loggerName, message);
}
}
