// См. ImageCodec.hpp.
#include "bridge/ImageCodec.hpp"

#include <algorithm>
#include <cstring>
#include <numeric>
#include <unordered_map>

namespace bridge::imagecodec
{
namespace
{
void WriteU16(std::vector<std::uint8_t>& out, std::uint16_t value)
{
	out.push_back(static_cast<std::uint8_t>(value & 0xFF));
	out.push_back(static_cast<std::uint8_t>((value >> 8) & 0xFF));
}

void WriteU32(std::vector<std::uint8_t>& out, std::uint32_t value)
{
	for (int i = 0; i < 4; ++i)
	{
		out.push_back(static_cast<std::uint8_t>((value >> (8 * i)) & 0xFF));
	}
}

std::uint32_t ReadU32(const std::uint8_t* p)
{
	return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8) | (static_cast<std::uint32_t>(p[2]) << 16)
		| (static_cast<std::uint32_t>(p[3]) << 24);
}

std::uint16_t ReadU16(const std::uint8_t* p)
{
	return static_cast<std::uint16_t>(p[0] | (p[1] << 8));
}

constexpr std::uint32_t PackRgb(int r, int g, int b)
{
	return 0xFF000000u | (static_cast<std::uint32_t>(r) << 16) | (static_cast<std::uint32_t>(g) << 8) | static_cast<std::uint32_t>(b);
}
}

std::vector<std::uint8_t> EncodeBmp8(const studiomdl::StudioTextureData& texture)
{
	const int width = texture.Width;
	const int height = texture.Height;
	const int rowSize = (width + 3) & ~3;
	const std::uint32_t pixelBytes = static_cast<std::uint32_t>(rowSize) * static_cast<std::uint32_t>(height);
	const std::uint32_t offset = 14 + 40 + 256 * 4;

	std::vector<std::uint8_t> out;
	out.reserve(offset + pixelBytes);

	out.push_back('B');
	out.push_back('M');
	WriteU32(out, offset + pixelBytes);
	WriteU16(out, 0);
	WriteU16(out, 0);
	WriteU32(out, offset);

	WriteU32(out, 40);
	WriteU32(out, static_cast<std::uint32_t>(width));
	WriteU32(out, static_cast<std::uint32_t>(height));
	WriteU16(out, 1);
	WriteU16(out, 8);
	WriteU32(out, 0);
	WriteU32(out, pixelBytes);
	WriteU32(out, 2835);
	WriteU32(out, 2835);
	WriteU32(out, 256);
	WriteU32(out, 256);

	for (std::size_t i = 0; i < graphics::RGBPalette::EntriesCount; ++i)
	{
		const auto& color = texture.Palette[i];
		out.push_back(color.B);
		out.push_back(color.G);
		out.push_back(color.R);
		out.push_back(0);
	}

	for (int y = height - 1; y >= 0; --y)
	{
		for (int x = 0; x < width; ++x)
		{
			out.push_back(std::to_integer<std::uint8_t>(texture.Pixels[static_cast<std::size_t>(y) * width + x]));
		}

		for (int pad = width; pad < rowSize; ++pad)
		{
			out.push_back(0);
		}
	}

	return out;
}

bool DecodeBmp(const std::uint8_t* data, std::size_t size, DecodedBmp& out, std::string& error)
{
	if (size < 54 || data[0] != 'B' || data[1] != 'M')
	{
		error = "Not a BMP file";
		return false;
	}

	const std::uint32_t offset = ReadU32(data + 10);
	const std::uint32_t headerSize = ReadU32(data + 14);

	if (headerSize < 40)
	{
		error = "Unsupported BMP header";
		return false;
	}

	const int width = static_cast<int>(ReadU32(data + 18));
	int height = static_cast<int>(ReadU32(data + 22));
	const int bitCount = ReadU16(data + 28);
	const std::uint32_t compression = ReadU32(data + 30);
	std::uint32_t colorsUsed = ReadU32(data + 46);

	const bool topDown = height < 0;

	if (topDown)
	{
		height = -height;
	}

	if (width <= 0 || height <= 0 || width > 16384 || height > 16384)
	{
		error = "Invalid BMP dimensions";
		return false;
	}

	if (compression != 0 && !(compression == 3 && bitCount == 32))
	{
		error = "Compressed BMP is not supported";
		return false;
	}

	if (bitCount != 1 && bitCount != 4 && bitCount != 8 && bitCount != 24 && bitCount != 32)
	{
		error = "Unsupported BMP bit depth";
		return false;
	}

	const std::size_t rowSize = ((static_cast<std::size_t>(width) * bitCount + 31) / 32) * 4;

	if (offset + rowSize * static_cast<std::size_t>(height) > size)
	{
		error = "Truncated BMP file";
		return false;
	}

	out = DecodedBmp{};
	out.width = width;
	out.height = height;
	out.argb.resize(static_cast<std::size_t>(width) * height);

	if (bitCount <= 8)
	{
		if (colorsUsed == 0 || colorsUsed > (1u << bitCount))
		{
			colorsUsed = 1u << bitCount;
		}

		const std::size_t paletteOffset = 14 + headerSize;

		if (paletteOffset + static_cast<std::size_t>(colorsUsed) * 4 > size)
		{
			error = "Truncated BMP palette";
			return false;
		}

		out.palette.assign(256, PackRgb(0, 0, 0));

		for (std::uint32_t i = 0; i < colorsUsed; ++i)
		{
			const std::uint8_t* entry = data + paletteOffset + i * 4;
			out.palette[i] = PackRgb(entry[2], entry[1], entry[0]);
		}

		out.indexed = true;
		out.indices.resize(static_cast<std::size_t>(width) * height);
	}

	for (int row = 0; row < height; ++row)
	{
		const int y = topDown ? row : height - 1 - row;
		const std::uint8_t* src = data + offset + rowSize * static_cast<std::size_t>(row);

		for (int x = 0; x < width; ++x)
		{
			const std::size_t dest = static_cast<std::size_t>(y) * width + x;

			if (bitCount == 8)
			{
				out.indices[dest] = src[x];
			}
			else if (bitCount == 4)
			{
				out.indices[dest] = (x & 1) ? (src[x / 2] & 0x0F) : (src[x / 2] >> 4);
			}
			else if (bitCount == 1)
			{
				out.indices[dest] = (src[x / 8] >> (7 - (x & 7))) & 1;
			}
			else if (bitCount == 24)
			{
				const std::uint8_t* px = src + x * 3;
				out.argb[dest] = PackRgb(px[2], px[1], px[0]);
			}
			else
			{
				const std::uint8_t* px = src + x * 4;
				out.argb[dest] = (static_cast<std::uint32_t>(px[3]) << 24) | (static_cast<std::uint32_t>(px[2]) << 16)
					| (static_cast<std::uint32_t>(px[1]) << 8) | px[0];

				// В большинстве BMP с 32 битами альфа-канал не используется (нули); считаем такие пиксели непрозрачными.
				if (px[3] == 0)
				{
					out.argb[dest] |= 0xFF000000u;
				}
			}
		}
	}

	if (out.indexed)
	{
		for (std::size_t i = 0; i < out.indices.size(); ++i)
		{
			out.argb[i] = out.palette[out.indices[i]];
		}
	}

	return true;
}

bool DecodeTga(const std::uint8_t* data, std::size_t size, DecodedBmp& out, std::string& error)
{
	if (size < 18)
	{
		error = "Not a TGA file";
		return false;
	}

	const int idLength = data[0];
	const int colorMapType = data[1];
	const int imageType = data[2];
	const int colorMapFirst = ReadU16(data + 3);
	const int colorMapLength = ReadU16(data + 5);
	const int colorMapDepth = data[7];
	const int width = ReadU16(data + 12);
	const int height = ReadU16(data + 14);
	const int bitsPerPixel = data[16];
	const int descriptor = data[17];

	const bool rle = imageType >= 9;
	const int baseType = rle ? imageType - 8 : imageType;

	if ((baseType != 1 && baseType != 2 && baseType != 3) || width <= 0 || height <= 0)
	{
		error = "Unsupported TGA image type";
		return false;
	}

	if (baseType == 1 && (colorMapType != 1 || bitsPerPixel != 8))
	{
		error = "Unsupported TGA palette format";
		return false;
	}

	if (baseType == 2 && bitsPerPixel != 15 && bitsPerPixel != 16 && bitsPerPixel != 24 && bitsPerPixel != 32)
	{
		error = "Unsupported TGA bit depth";
		return false;
	}

	if (baseType == 3 && bitsPerPixel != 8)
	{
		error = "Unsupported TGA bit depth";
		return false;
	}

	std::size_t position = 18 + static_cast<std::size_t>(idLength);
	std::vector<std::uint32_t> colorMap;

	if (colorMapType == 1)
	{
		const int entryBytes = (colorMapDepth + 7) / 8;

		if (position + static_cast<std::size_t>(colorMapLength) * entryBytes > size)
		{
			error = "Truncated TGA palette";
			return false;
		}

		colorMap.assign(static_cast<std::size_t>(colorMapFirst + colorMapLength), 0xFF000000u);

		for (int i = 0; i < colorMapLength; ++i)
		{
			const std::uint8_t* e = data + position + static_cast<std::size_t>(i) * entryBytes;
			std::uint32_t color = 0xFF000000u;

			if (entryBytes >= 3)
			{
				color = PackRgb(e[2], e[1], e[0]);

				if (entryBytes == 4 && colorMapDepth == 32)
				{
					color = (static_cast<std::uint32_t>(e[3]) << 24) | (color & 0x00FFFFFFu);
				}
			}

			colorMap[static_cast<std::size_t>(colorMapFirst + i)] = color;
		}

		position += static_cast<std::size_t>(colorMapLength) * entryBytes;
	}

	const int pixelBytes = (bitsPerPixel + 7) / 8;
	const std::size_t pixelCount = static_cast<std::size_t>(width) * height;
	std::vector<std::uint8_t> raw(pixelCount * pixelBytes);

	if (!rle)
	{
		if (position + raw.size() > size)
		{
			error = "Truncated TGA pixel data";
			return false;
		}

		std::memcpy(raw.data(), data + position, raw.size());
	}
	else
	{
		std::size_t written = 0;

		while (written < pixelCount)
		{
			if (position >= size)
			{
				error = "Truncated TGA pixel data";
				return false;
			}

			const std::uint8_t header = data[position++];
			const std::size_t count = static_cast<std::size_t>(header & 0x7F) + 1;

			if (written + count > pixelCount)
			{
				error = "Corrupt TGA run";
				return false;
			}

			if (header & 0x80)
			{
				if (position + pixelBytes > size)
				{
					error = "Truncated TGA pixel data";
					return false;
				}

				for (std::size_t i = 0; i < count; ++i)
				{
					std::memcpy(raw.data() + (written + i) * pixelBytes, data + position, pixelBytes);
				}

				position += pixelBytes;
			}
			else
			{
				if (position + count * pixelBytes > size)
				{
					error = "Truncated TGA pixel data";
					return false;
				}

				std::memcpy(raw.data() + written * pixelBytes, data + position, count * pixelBytes);
				position += count * pixelBytes;
			}

			written += count;
		}
	}

	out = DecodedBmp{};
	out.width = width;
	out.height = height;
	out.argb.resize(pixelCount);

	const bool topToBottom = (descriptor & 0x20) != 0;
	const bool rightToLeft = (descriptor & 0x10) != 0;
	const int alphaBits = descriptor & 0x0F;

	for (int row = 0; row < height; ++row)
	{
		const int y = topToBottom ? row : height - 1 - row;

		for (int col = 0; col < width; ++col)
		{
			const int x = rightToLeft ? width - 1 - col : col;
			const std::uint8_t* px = raw.data() + (static_cast<std::size_t>(row) * width + col) * pixelBytes;
			std::uint32_t color;

			if (baseType == 1)
			{
				color = px[0] < colorMap.size() ? colorMap[px[0]] : 0xFF000000u;
			}
			else if (baseType == 3)
			{
				color = PackRgb(px[0], px[0], px[0]);
			}
			else if (bitsPerPixel == 24)
			{
				color = PackRgb(px[2], px[1], px[0]);
			}
			else if (bitsPerPixel == 32)
			{
				color = PackRgb(px[2], px[1], px[0]);
				color = (alphaBits > 0 ? static_cast<std::uint32_t>(px[3]) << 24 : 0xFF000000u) | (color & 0x00FFFFFFu);
			}
			else
			{
				const unsigned value = static_cast<unsigned>(px[0] | (px[1] << 8));
				const int r = ((value >> 10) & 0x1F) * 255 / 31;
				const int g = ((value >> 5) & 0x1F) * 255 / 31;
				const int b = (value & 0x1F) * 255 / 31;
				color = PackRgb(r, g, b);
			}

			out.argb[static_cast<std::size_t>(y) * width + x] = color;
		}
	}

	return true;
}

std::vector<std::uint32_t> ToArgb(const studiomdl::StudioTextureData& texture, bool masked)
{
	std::vector<std::uint32_t> result(static_cast<std::size_t>(texture.Width) * texture.Height);

	for (std::size_t i = 0; i < result.size(); ++i)
	{
		const int index = std::to_integer<int>(texture.Pixels[i]);
		const auto& color = texture.Palette[static_cast<std::size_t>(index)];
		std::uint32_t value = PackRgb(color.R, color.G, color.B);

		if (masked && index == 255)
		{
			value &= 0x00FFFFFFu;
		}

		result[i] = value;
	}

	return result;
}

namespace
{
struct ColorEntry
{
	std::uint32_t Key; // 0x00RRGGBB
	std::uint32_t Count;
};

struct Box
{
	std::vector<std::uint32_t> Entries; // индексы в таблице уникальных цветов
	int MinC[3]{255, 255, 255};
	int MaxC[3]{0, 0, 0};
	std::uint64_t Population = 0;
};

int Channel(std::uint32_t key, int channel)
{
	return static_cast<int>((key >> (16 - 8 * channel)) & 0xFF);
}

void UpdateBounds(Box& box, const std::vector<ColorEntry>& colors)
{
	for (int c = 0; c < 3; ++c)
	{
		box.MinC[c] = 255;
		box.MaxC[c] = 0;
	}

	box.Population = 0;

	for (auto index : box.Entries)
	{
		const auto& entry = colors[index];
		box.Population += entry.Count;

		for (int c = 0; c < 3; ++c)
		{
			const int v = Channel(entry.Key, c);
			box.MinC[c] = std::min(box.MinC[c], v);
			box.MaxC[c] = std::max(box.MaxC[c], v);
		}
	}
}

int LargestChannel(const Box& box)
{
	int best = 0;
	int bestRange = -1;

	for (int c = 0; c < 3; ++c)
	{
		const int range = box.MaxC[c] - box.MinC[c];

		if (range > bestRange)
		{
			bestRange = range;
			best = c;
		}
	}

	return best;
}
}

studiomdl::StudioTextureData Quantize(int width, int height, const std::uint32_t* argb, bool masked)
{
	const std::size_t pixelCount = static_cast<std::size_t>(width) * height;
	const int maxColors = masked ? 255 : 256;

	std::vector<ColorEntry> colors;
	std::unordered_map<std::uint32_t, std::uint32_t> lookup;
	lookup.reserve(1024);

	for (std::size_t i = 0; i < pixelCount; ++i)
	{
		const std::uint32_t pixel = argb[i];

		if (masked && (pixel >> 24) < 128)
		{
			continue;
		}

		const std::uint32_t key = pixel & 0x00FFFFFFu;
		auto it = lookup.find(key);

		if (it == lookup.end())
		{
			lookup.emplace(key, static_cast<std::uint32_t>(colors.size()));
			colors.push_back({key, 1});
		}
		else
		{
			++colors[it->second].Count;
		}
	}

	std::vector<std::uint32_t> paletteKeys;

	if (static_cast<int>(colors.size()) <= maxColors)
	{
		for (const auto& entry : colors)
		{
			paletteKeys.push_back(entry.Key);
		}
	}
	else
	{
		std::vector<Box> boxes(1);
		boxes[0].Entries.resize(colors.size());
		std::iota(boxes[0].Entries.begin(), boxes[0].Entries.end(), 0u);
		UpdateBounds(boxes[0], colors);

		while (static_cast<int>(boxes.size()) < maxColors)
		{
			int target = -1;
			std::uint64_t bestScore = 0;

			for (std::size_t b = 0; b < boxes.size(); ++b)
			{
				if (boxes[b].Entries.size() < 2)
				{
					continue;
				}

				const int channel = LargestChannel(boxes[b]);
				const std::uint64_t range = static_cast<std::uint64_t>(boxes[b].MaxC[channel] - boxes[b].MinC[channel]) + 1;
				const std::uint64_t score = range * boxes[b].Population;

				if (score > bestScore)
				{
					bestScore = score;
					target = static_cast<int>(b);
				}
			}

			if (target < 0)
			{
				break;
			}

			Box source = std::move(boxes[static_cast<std::size_t>(target)]);
			const int channel = LargestChannel(source);

			std::sort(source.Entries.begin(), source.Entries.end(), [&](std::uint32_t a, std::uint32_t b)
				{ return Channel(colors[a].Key, channel) < Channel(colors[b].Key, channel); });

			std::uint64_t accumulated = 0;
			std::size_t splitAt = 1;

			for (std::size_t i = 0; i < source.Entries.size() - 1; ++i)
			{
				accumulated += colors[source.Entries[i]].Count;
				splitAt = i + 1;

				if (accumulated * 2 >= source.Population)
				{
					break;
				}
			}

			Box first;
			Box second;
			first.Entries.assign(source.Entries.begin(), source.Entries.begin() + static_cast<std::ptrdiff_t>(splitAt));
			second.Entries.assign(source.Entries.begin() + static_cast<std::ptrdiff_t>(splitAt), source.Entries.end());
			UpdateBounds(first, colors);
			UpdateBounds(second, colors);

			boxes[static_cast<std::size_t>(target)] = std::move(first);
			boxes.push_back(std::move(second));
		}

		for (const auto& box : boxes)
		{
			std::uint64_t sum[3] = {0, 0, 0};

			for (auto index : box.Entries)
			{
				for (int c = 0; c < 3; ++c)
				{
					sum[c] += static_cast<std::uint64_t>(Channel(colors[index].Key, c)) * colors[index].Count;
				}
			}

			const std::uint64_t population = std::max<std::uint64_t>(box.Population, 1);
			paletteKeys.push_back(PackRgb(static_cast<int>(sum[0] / population), static_cast<int>(sum[1] / population),
				static_cast<int>(sum[2] / population)) & 0x00FFFFFFu);
		}
	}

	studiomdl::StudioTextureData result;
	result.Width = width;
	result.Height = height;
	result.Pixels.resize(pixelCount);

	for (std::size_t i = 0; i < graphics::RGBPalette::EntriesCount; ++i)
	{
		result.Palette[i] = {0, 0, 0};
	}

	for (std::size_t i = 0; i < paletteKeys.size(); ++i)
	{
		const std::uint32_t key = paletteKeys[i];
		result.Palette[i] = {static_cast<std::uint8_t>(Channel(key, 0)), static_cast<std::uint8_t>(Channel(key, 1)),
			static_cast<std::uint8_t>(Channel(key, 2))};
	}

	if (masked)
	{
		result.Palette[255] = {0, 0, 255};
	}

	std::unordered_map<std::uint32_t, std::uint8_t> cache;
	cache.reserve(colors.size() + 1);

	for (std::size_t i = 0; i < pixelCount; ++i)
	{
		const std::uint32_t pixel = argb[i];

		if (masked && (pixel >> 24) < 128)
		{
			result.Pixels[i] = std::byte{255};
			continue;
		}

		const std::uint32_t key = pixel & 0x00FFFFFFu;

		if (auto it = cache.find(key); it != cache.end())
		{
			result.Pixels[i] = std::byte{it->second};
			continue;
		}

		int best = 0;
		std::int64_t bestDistance = INT64_MAX;
		const int r = Channel(key, 0);
		const int g = Channel(key, 1);
		const int b = Channel(key, 2);

		for (std::size_t p = 0; p < paletteKeys.size(); ++p)
		{
			const int dr = r - Channel(paletteKeys[p], 0);
			const int dg = g - Channel(paletteKeys[p], 1);
			const int db = b - Channel(paletteKeys[p], 2);
			const std::int64_t distance = static_cast<std::int64_t>(dr) * dr * 3 + static_cast<std::int64_t>(dg) * dg * 4
				+ static_cast<std::int64_t>(db) * db * 2;

			if (distance < bestDistance)
			{
				bestDistance = distance;
				best = static_cast<int>(p);

				if (distance == 0)
				{
					break;
				}
			}
		}

		cache.emplace(key, static_cast<std::uint8_t>(best));
		result.Pixels[i] = std::byte{static_cast<unsigned char>(best)};
	}

	return result;
}

std::vector<std::uint32_t> ScaleNearest(
	const std::uint32_t* src, int srcWidth, int srcHeight, int dstWidth, int dstHeight)
{
	std::vector<std::uint32_t> result(static_cast<std::size_t>(dstWidth) * dstHeight);

	for (int y = 0; y < dstHeight; ++y)
	{
		const int sy = std::min(srcHeight - 1, static_cast<int>(static_cast<std::int64_t>(y) * srcHeight / dstHeight));

		for (int x = 0; x < dstWidth; ++x)
		{
			const int sx = std::min(srcWidth - 1, static_cast<int>(static_cast<std::int64_t>(x) * srcWidth / dstWidth));
			result[static_cast<std::size_t>(y) * dstWidth + x] = src[static_cast<std::size_t>(sy) * srcWidth + sx];
		}
	}

	return result;
}

std::vector<std::uint8_t> ScaleNearest8(
	const std::uint8_t* src, int srcWidth, int srcHeight, int dstWidth, int dstHeight)
{
	std::vector<std::uint8_t> result(static_cast<std::size_t>(dstWidth) * dstHeight);

	for (int y = 0; y < dstHeight; ++y)
	{
		const int sy = std::min(srcHeight - 1, static_cast<int>(static_cast<std::int64_t>(y) * srcHeight / dstHeight));

		for (int x = 0; x < dstWidth; ++x)
		{
			const int sx = std::min(srcWidth - 1, static_cast<int>(static_cast<std::int64_t>(x) * srcWidth / dstWidth));
			result[static_cast<std::size_t>(y) * dstWidth + x] = src[static_cast<std::size_t>(sy) * srcWidth + sx];
		}
	}

	return result;
}

bool AdjustToMultipleOf4(int& width, int& height)
{
	if (((static_cast<std::int64_t>(width) * height) % 4) == 0)
	{
		return false;
	}

	do
	{
		++width;
	}
	while (((static_cast<std::int64_t>(width) * height) % 4) != 0);

	return true;
}
}
