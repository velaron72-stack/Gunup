// См. ViewerSession.hpp. Основная часть: жизненный цикл GL, загрузка/сохранение модели, команды, состояние, касания.
// Запросы JSON и операции с текстурами вынесены в ViewerQueries.cpp.
#include "bridge/ViewerSession.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <sstream>

#include <QOpenGLFunctions_1_1>

#include "bridge/BridgeIds.hpp"
#include "bridge/MessageLog.hpp"
#include "bridge/ViewerSessionInternal.hpp"
#include "entity/AxesEntity.hpp"
#include "entity/BackgroundEntity.hpp"
#include "entity/BoundingBoxEntity.hpp"
#include "entity/ClippingBoxEntity.hpp"
#include "entity/CrosshairEntity.hpp"
#include "entity/GroundEntity.hpp"
#include "entity/GuidelinesEntity.hpp"
#include "entity/HLMVStudioModelEntity.hpp"
#include "entity/PlayerHitboxEntity.hpp"
#include "entity/TextureEntity.hpp"
#include "formats/studiomodel/EditableStudioModel.hpp"
#include "formats/studiomodel/StudioModelIO.hpp"
#include "formats/studiomodel/StudioModelUtils.hpp"
#include "gl4esinit.h"
#include "graphics/Scene.hpp"
#include "graphics/SceneContext.hpp"
#include "graphics/TextureLoader.hpp"
#include "plugins/halflife/studiomodel/StudioModelAsset.hpp"
#include "plugins/halflife/studiomodel/StudioModelColors.hpp"
#include "plugins/halflife/studiomodel/settings/StudioModelSettings.hpp"
#include "settings/ApplicationSettings.hpp"
#include "soundsystem/ISoundSystem.hpp"
#include "utility/mathlib.hpp"

namespace bridge
{
namespace ids = bridge::ids;

namespace
{
double NowSeconds()
{
	using Clock = std::chrono::steady_clock;
	static const Clock::time_point origin = Clock::now();
	return std::chrono::duration<double>(Clock::now() - origin).count();
}

glm::vec3 ParseVec3(const std::string& text)
{
	glm::vec3 value{0.f};
	std::istringstream stream(text);
	stream >> value.x >> value.y >> value.z;
	return value;
}

std::vector<float> ParseFloats(const std::string& text)
{
	std::vector<float> values;
	std::istringstream stream(text);
	float v;

	while (stream >> v)
	{
		values.push_back(v);
	}

	return values;
}

glm::vec4 ArgbToVector(std::uint32_t argb)
{
	return {((argb >> 16) & 0xFF) / 255.f, ((argb >> 8) & 0xFF) / 255.f, (argb & 0xFF) / 255.f, ((argb >> 24) & 0xFF) / 255.f};
}

std::uint32_t VectorToArgb(const glm::vec4& color)
{
	auto to8 = [](float v) { return static_cast<std::uint32_t>(std::clamp(v, 0.f, 1.f) * 255.f + 0.5f); };
	return (to8(color.a) << 24) | (to8(color.r) << 16) | (to8(color.g) << 8) | to8(color.b);
}
}

// Звуковая система Android: воспроизведение выполняет Kotlin (SoundPool), сюда передаётся только запрос.
class AndroidSoundSystem final : public ISoundSystem
{
public:
	bool IsSoundAvailable() const override { return static_cast<bool>(Callback); }
	bool Initialize() override { return true; }
	void Shutdown() override {}
	void SetMuted(bool muted) override { Muted = muted; }
	void RunFrame() override {}

	void PlaySound(std::string_view fileName, float volume, int pitch) override
	{
		if (!Muted && Callback)
		{
			Callback(std::string{fileName}, volume, pitch);
		}
	}

	void StopAllSounds() override {}

	std::function<void(const std::string&, float, int)> Callback;
	bool Muted = false;
};

ViewerSession& ViewerSession::Instance()
{
	static ViewerSession instance;
	return instance;
}

ViewerSession::ViewerSession()
	: _appSettings(std::make_unique<ApplicationSettings>())
	, _studioSettings(std::make_unique<StudioModelSettings>())
	, _soundSystem(std::make_unique<AndroidSoundSystem>())
	, _gl(std::make_unique<QOpenGLFunctions_1_1>())
{
	RegisterDefaultColors();
}

ViewerSession::~ViewerSession() = default;

void ViewerSession::RegisterDefaultColors()
{
	// Значения по умолчанию из HalfLifeAssetManagerPlugin.cpp оригинала.
	auto colors = _appSettings->GetColorSettings();
	colors->Add(studiomodel::GroundColor, RGBA8888ToVector(216, 216, 175, 178));
	colors->Add(studiomodel::BackgroundColor, RGB888ToVector(63, 127, 127));
	colors->Add(studiomodel::CrosshairColor, RGB888ToVector(255, 0, 0));
	colors->Add(studiomodel::SkyLightColor, RGB888ToVector(255, 255, 255));
	colors->Add(studiomodel::WireframeColor, RGB888ToVector(255, 0, 0));
	colors->Add(studiomodel::HitboxEdgeColor, RGBA8888ToVector(255, 0, 0, 128));
	colors->Add(studiomodel::HitboxFaceColor, RGBA8888ToVector(128, 0, 0, 0));
	colors->Add(studiomodel::SingleHitboxEdgeColor, RGBA8888ToVector(0, 255, 0, 128));
	colors->Add(studiomodel::SingleHitboxFaceColor, RGBA8888ToVector(0, 128, 0, 128));
}

void ViewerSession::SetSoundCallback(std::function<void(const std::string&, float, int)> callback)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);
	_soundSystem->Callback = std::move(callback);
}

// ---------------------------------------------------------------- GL-поток

void ViewerSession::OnSurfaceCreated()
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (_glInitialized)
	{
		// Контекст GLES пересоздан: освобождаем имена объектов прежнего контекста и перезапускаем gl4es.
		if (_asset && _sceneContext)
		{
			_asset->DestroyDeviceObjects(*_sceneContext);
		}

		if (_provider)
		{
			_provider->DestroyDeviceObjects();
		}

		close_gl4es();
		LogInfo("GL context recreated, gl4es restarted");
	}

	initialize_gl4es();
	_glInitialized = true;

	_textureLoader = std::make_unique<graphics::TextureLoader>(_gl.get());
	_textureLoader->SetResizeToPowerOf2(_appSettings->ShouldResizeTexturesToPowerOf2());
	_textureLoader->SetTextureFilters(
		_appSettings->GetMinFilter(), _appSettings->GetMagFilter(), _appSettings->GetMipmapFilter());
	_sceneContext = std::make_unique<graphics::SceneContext>(_gl.get(), _textureLoader.get());

	if (!_provider)
	{
		_provider = std::make_unique<studiomodel::StudioModelAssetProvider>(
			_gl.get(), _appSettings.get(), _studioSettings.get());
	}

	_provider->CreateDeviceObjects();

	if (_asset)
	{
		_asset->CreateDeviceObjects(*_sceneContext);
	}
}

void ViewerSession::OnSurfaceChanged(int width, int height)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);
	_width = std::max(width, 1);
	_height = std::max(height, 1);
}

void ViewerSession::RunGlTasks()
{
	auto tasks = std::move(_glTasks);
	_glTasks.clear();

	for (auto& task : tasks)
	{
		task();
	}
}

void ViewerSession::QueueGl(std::function<void()> task)
{
	_glTasks.push_back(std::move(task));
}

void ViewerSession::ApplyPendingModel()
{
	if (_closeRequested || _pendingModel)
	{
		if (_asset)
		{
			_asset->DestroyDeviceObjects(*_sceneContext);
			_asset.reset();
		}

		_closeRequested = false;
		++_modelRevision;
	}

	if (_pendingModel)
	{
		_asset = std::make_unique<studiomodel::StudioModelAsset>(std::string{_pendingName}, _provider.get(),
			_textureLoader.get(), _gl.get(), &_worldTime, _soundSystem.get(), _appSettings.get(), _studioSettings.get(),
			std::move(_pendingModel));

		_fileName = _pendingName;
		_asset->CreateDeviceObjects(*_sceneContext);
		_asset->InitializeCameras();
		_asset->UpdateWindowSize(static_cast<unsigned int>(_width), static_cast<unsigned int>(_height));
		_blendMode = 0;
		_savedViews.clear();
		_pendingName.clear();
		++_modelRevision;
	}
}

void ViewerSession::OnDrawFrame()
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_glInitialized)
	{
		return;
	}

	RunGlTasks();
	ApplyPendingModel();

	_sceneContext->WindowWidth = _width;
	_sceneContext->WindowHeight = _height;

	if (!_asset)
	{
		const auto color = _appSettings->GetColorSettings()->GetColor(studiomodel::BackgroundColor);
		_gl->glClearColor(color.r, color.g, color.b, 1.f);
		_gl->glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
		return;
	}

	const double now = NowSeconds();

	// Счётчик кадров в секунду (Controls Bar оригинала).
	{
		++_fpsFrames;

		if (now - _fpsTime >= 1.0)
		{
			_fps = static_cast<float>(_fpsFrames / (now - _fpsTime));
			_fpsFrames = 0;
			_fpsTime = now;
		}
	}

	// Тик мира, как AssetManager::OnTimerTick оригинала: сначала SetRealTime, затем TimeChanged.
	// Без SetRealTime предыдущее реальное время оставалось нулевым, длительность кадра всегда ограничивалась 0.1 с,
	// и анимация шла в несколько раз быстрее нормальной скорости.
	_worldTime.SetRealTime(now);
	_worldTime.TimeChanged(now);
	_soundSystem->RunFrame();
	_asset->Tick();

	_asset->UpdateWindowSize(static_cast<unsigned int>(_width), static_cast<unsigned int>(_height));
	_asset->GetCurrentScene()->Draw(*_sceneContext);
}

// ---------------------------------------------------------------- загрузка и сохранение

bool ViewerSession::HasModel()
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);
	return _asset != nullptr || _pendingModel != nullptr;
}

void ViewerSession::CloseModel()
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);
	_pendingModel.reset();
	_closeRequested = true;
}

std::string ViewerSession::LoadModel(
	const std::string& displayName, std::vector<std::uint8_t>&& mainFile, MemoryFileSystem::Loader siblingLoader)
{
	JsonWriter json;
	json.BeginObject();

	try
	{
		if (mainFile.empty())
		{
			throw std::runtime_error("File is empty");
		}

		MemoryFileSystem fileSystem{std::move(siblingLoader)};
		const std::string key = displayName;

		FilePtr file{fmemopen(mainFile.data(), mainFile.size(), "rb")};

		if (!file)
		{
			throw std::runtime_error("Could not open file data");
		}

		if (!studiomdl::IsStudioModel(file.get(), true))
		{
			throw std::runtime_error("The file is not a Half-Life studio model");
		}

		std::rewind(file.get());

		const std::filesystem::path path{key};
		auto studioModel = studiomdl::LoadStudioModel(path, file.get(), fileSystem);

		bool xash = studiomdl::IsXashModel(*studioModel);

		auto editable = std::make_unique<studiomdl::EditableStudioModel>(studiomdl::ConvertToEditable(*studioModel));
		editable->IsXashModel = xash;

		{
			std::lock_guard<std::recursive_mutex> guard(_mutex);
			_pendingModel = std::move(editable);
			_pendingName = displayName;
			_closeRequested = false;
		}

		json.Field("ok", true);
		json.Field("xash", xash);
	}
	catch (const std::exception& e)
	{
		LogError(std::string{"Failed to load model: "} + e.what());
		json.Field("ok", false);
		json.Field("error", std::string{e.what()});
	}

	json.EndObject();
	return json.Text();
}

bool ViewerSession::Serialize(
	const std::string& fileName, std::vector<std::uint8_t>& mainFile, std::vector<std::uint8_t>& textureFile)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset)
	{
		return false;
	}

	try
	{
		const std::filesystem::path path{fileName.empty() ? _fileName : fileName};
		auto studioModel = studiomdl::ConvertFromEditable(path, *_asset->GetEditableStudioModel());

		const auto* header = studioModel.GetStudioHeader();
		const auto* bytes = reinterpret_cast<const std::uint8_t*>(header);
		mainFile.assign(bytes, bytes + header->length);

		textureFile.clear();

		if (studioModel.HasSeparateTextureHeader())
		{
			const auto* textureHeader = studioModel.GetTextureHeader();
			const auto* textureBytes = reinterpret_cast<const std::uint8_t*>(textureHeader);
			textureFile.assign(textureBytes, textureBytes + textureHeader->length);
		}

		return true;
	}
	catch (const std::exception& e)
	{
		LogError(std::string{"Failed to save model: "} + e.what());
		return false;
	}
}

// ---------------------------------------------------------------- команды

bool ViewerSession::SetFlag(int flag, bool value)
{
	auto asset = _asset.get();

	switch (flag)
	{
	case ids::FLAG_HITBOXES: asset->ShowHitboxes = value; break;
	case ids::FLAG_BONES: asset->ShowBones = value; break;
	case ids::FLAG_ATTACHMENTS: asset->ShowAttachments = value; break;
	case ids::FLAG_EYE: asset->ShowEyePosition = value; break;
	case ids::FLAG_BBOX: asset->GetBoundingBoxEntity()->ShowBBox = value; break;
	case ids::FLAG_CBOX: asset->GetClippingBoxEntity()->ShowCBox = value; break;
	case ids::FLAG_BACKFACE: asset->EnableBackfaceCulling = value; break;
	case ids::FLAG_WIREFRAME_OVERLAY: asset->ShowWireframeOverlay = value; break;
	case ids::FLAG_SHADOWS: asset->DrawShadows = value; break;
	case ids::FLAG_SHADOW_FIX: asset->FixShadowZFighting = value; break;
	case ids::FLAG_AXES: asset->GetAxesEntity()->ShowAxes = value; break;
	case ids::FLAG_NORMALS: asset->ShowNormals = value; break;
	case ids::FLAG_PLAYER_HITBOX: asset->GetPlayerHitboxEntity()->ShowPlayerHitbox = value; break;
	case ids::FLAG_MIRROR_X: asset->GetEntity()->GetScale().x = value ? -1.f : 1.f; break;
	case ids::FLAG_MIRROR_Y: asset->GetEntity()->GetScale().y = value ? -1.f : 1.f; break;
	case ids::FLAG_MIRROR_Z: asset->GetEntity()->GetScale().z = value ? -1.f : 1.f; break;
	case ids::FLAG_CROSSHAIR: asset->GetCrosshairEntity()->ShowCrosshair = value; break;
	case ids::FLAG_GUIDELINES: asset->GetGuidelinesEntity()->ShowGuidelines = value; break;
	case ids::FLAG_OFFSCREEN: asset->GetGuidelinesEntity()->ShowOffscreenAreas = value; break;
	case ids::FLAG_GROUND:
		asset->GetGroundEntity()->ShowGround = value;

		if (!value)
		{
			asset->GetGroundEntity()->MirrorOnGround = false;
		}
		break;
	case ids::FLAG_GROUND_MIRROR:
		asset->GetGroundEntity()->MirrorOnGround = value;

		if (value)
		{
			asset->GetGroundEntity()->ShowGround = true;
		}
		break;
	case ids::FLAG_GROUND_TEXTURE:
		asset->GetGroundEntity()->EnableTexture = value;

		if (value)
		{
			asset->GetGroundEntity()->ShowGround = true;
		}
		break;
	case ids::FLAG_GROUND_TILING: asset->GetGroundEntity()->EnableGroundTextureTiling = value; break;
	case ids::FLAG_BACKGROUND: asset->GetBackgroundEntity()->ShowBackground = value; break;
	case ids::FLAG_UV_SHOW: asset->GetTextureEntity()->ShowUVMap = value; break;
	case ids::FLAG_UV_OVERLAY: asset->GetTextureEntity()->OverlayUVMap = value; break;
	case ids::FLAG_UV_AA: asset->GetTextureEntity()->AntiAliasLines = value; break;
	default: return false;
	}

	return true;
}

void ViewerSession::ApplyColor(int colorId, std::uint32_t argb)
{
	const QString* key = nullptr;

	switch (colorId)
	{
	case ids::COLOR_GROUND: key = &studiomodel::GroundColor; break;
	case ids::COLOR_BACKGROUND: key = &studiomodel::BackgroundColor; break;
	case ids::COLOR_CROSSHAIR: key = &studiomodel::CrosshairColor; break;
	case ids::COLOR_SKYLIGHT: key = &studiomodel::SkyLightColor; break;
	case ids::COLOR_WIREFRAME: key = &studiomodel::WireframeColor; break;
	case ids::COLOR_HITBOX_EDGE: key = &studiomodel::HitboxEdgeColor; break;
	case ids::COLOR_HITBOX_FACE: key = &studiomodel::HitboxFaceColor; break;
	case ids::COLOR_SINGLE_HITBOX_EDGE: key = &studiomodel::SingleHitboxEdgeColor; break;
	case ids::COLOR_SINGLE_HITBOX_FACE: key = &studiomodel::SingleHitboxFaceColor; break;
	default: return;
	}

	auto colors = _appSettings->GetColorSettings();
	auto value = ArgbToVector(argb);

	if (!colors->HasAlphaChannel(*key))
	{
		value.a = 1.f;
	}

	colors->Set(*key, value);
}

void ViewerSession::ResetBlenders()
{
	if (!_asset)
	{
		return;
	}

	// SequencesPanel::InitializeBlenders: значение каждого блендера ставится в середину диапазона.
	auto entity = _asset->GetEntity();
	auto model = entity->GetEditableModel();
	const int sequenceIndex = entity->GetSequence();

	entity->SetBlendMode(_blendMode == 1 ? StudioBlendMode::CounterStrike : StudioBlendMode::Standard);

	if (sequenceIndex < 0 || sequenceIndex >= static_cast<int>(model->Sequences.size()))
	{
		return;
	}

	const auto& sequence = *model->Sequences[static_cast<std::size_t>(sequenceIndex)];

	for (int blender = 0; blender < SequenceBlendCount; ++blender)
	{
		float start;
		float end;

		if (_blendMode == 1)
		{
			start = studiomdl::CounterStrikeBlendRanges[static_cast<std::size_t>(blender)].Start;
			end = studiomdl::CounterStrikeBlendRanges[static_cast<std::size_t>(blender)].End;
		}
		else
		{
			const auto& data = sequence.BlendData[static_cast<std::size_t>(blender)];
			start = std::min(data.Start, data.End);
			end = std::max(data.Start, data.End);
		}

		entity->SetBlending(blender, start + (end - start) * 0.5f);
	}
}

int ViewerSession::Command(int cmd, int a, int b, float f, const std::string& s)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (cmd == ids::CMD_CLEAR_LOG)
	{
		ClearLog();
		return 1;
	}

	switch (cmd)
	{
	case ids::CMD_SET_MOUSE_SENS: _appSettings->SetMouseSensitivity(std::clamp(a, 1, 20)); return 1;
	case ids::CMD_SET_WHEEL_SPEED: _appSettings->SetMouseWheelSpeed(std::clamp(a, 1, 2048)); return 1;
	case ids::CMD_SET_COLOR: ApplyColor(a, static_cast<std::uint32_t>(b)); return 1;
	case ids::CMD_RESET_COLORS: _appSettings->GetColorSettings()->ResetToDefaults(); return 1;
	case ids::CMD_SET_AUTODETECT_VIEWMODEL: _studioSettings->SetAutodetectViewmodels(a != 0); return 1;
	case ids::CMD_SET_GROUND_LENGTH: _studioSettings->SetGroundLength(std::clamp(a, 0, 2048)); return 1;
	case ids::CMD_SET_ASPECT:
		_appSettings->SetAspectRatio({static_cast<float>(std::clamp(a, 1, 100)), static_cast<float>(std::clamp(b, 1, 100))});
		return 1;
	case ids::CMD_SET_FLAG:
		switch (a)
		{
		case ids::FLAG_SOUNDS:
			_appSettings->PlaySounds = b != 0;
			_soundSystem->SetMuted(b == 0);
			return 1;
		case ids::FLAG_SOUND_PITCH: _appSettings->FramerateAffectsPitch = b != 0; return 1;
		case ids::FLAG_INVERT_X: _appSettings->SetInvertMouseX(b != 0); return 1;
		case ids::FLAG_INVERT_Y: _appSettings->SetInvertMouseY(b != 0); return 1;
		case ids::FLAG_LIGHT_EDIT: _lightEditing = b != 0; return 1;
		case ids::FLAG_POW2:
			_appSettings->SetResizeTexturesToPowerOf2(b != 0);
			QueueGl([this]()
				{
					_textureLoader->SetResizeToPowerOf2(_appSettings->ShouldResizeTexturesToPowerOf2());

					if (_asset)
					{
						_asset->GetEditableStudioModel()->UpdateTextures(*_textureLoader);
					}
				});
			return 1;
		default: break;
		}
		break;
	case ids::CMD_SET_TEX_FILTER:
	{
		const auto minFilter = static_cast<graphics::TextureFilter>(std::clamp(a, 0, 1));
		const auto magFilter = static_cast<graphics::TextureFilter>(std::clamp(b, 0, 1));
		const auto mipFilter = static_cast<graphics::MipmapFilter>(std::clamp(static_cast<int>(f), 0, 2));
		_appSettings->SetTextureFilters(minFilter, magFilter, mipFilter);
		QueueGl([this, minFilter, magFilter, mipFilter]()
			{
				_textureLoader->SetTextureFilters(minFilter, magFilter, mipFilter);

				if (_asset)
				{
					_asset->GetEditableStudioModel()->UpdateFilters(*_textureLoader);
				}
			});
		return 1;
	}
	default: break;
	}

	if (!_asset)
	{
		return 0;
	}

	auto asset = _asset.get();
	auto entity = asset->GetEntity();
	auto model = asset->GetEditableStudioModel();
	auto scene = asset->GetScene();
	auto provider = asset->GetProvider();
	auto cameras = provider->GetCameraOperators();

	const int sequenceCount = static_cast<int>(model->Sequences.size());

	switch (cmd)
	{
	case ids::CMD_PLAY_PAUSE:
		asset->PlaySequence = a < 0 ? !asset->PlaySequence : a != 0;
		return asset->PlaySequence ? 1 : 0;

	case ids::CMD_STOP:
		asset->PlaySequence = false;
		entity->SetFrame(0);
		return 1;

	case ids::CMD_RESTART:
		entity->SetFrame(0);
		return 1;

	case ids::CMD_STEP_FRAME:
	{
		const int sequenceIndex = entity->GetSequence();

		if (sequenceIndex < 0 || sequenceIndex >= sequenceCount)
		{
			return 0;
		}

		// Timeline::ModifyFrame оригинала.
		const auto& sequence = *model->Sequences[static_cast<std::size_t>(sequenceIndex)];
		float newFrame = entity->GetFrame() + a;

		if (newFrame < 0)
		{
			newFrame += (sequence.NumFrames - 1);
		}

		if (newFrame >= sequence.NumFrames)
		{
			newFrame -= sequence.NumFrames - 1;
		}

		entity->SetFrame(newFrame);
		return 1;
	}

	case ids::CMD_SET_FRAME:
		entity->SetFrame(f);

		if (b != 0)
		{
			asset->PlaySequence = false;
		}
		return 1;

	case ids::CMD_SET_SPEED: entity->SetFrameRate(f); return 1;

	case ids::CMD_SET_SEQUENCE:
		// a == -1 — поза Skeleton (OnPoseChanged оригинала вызывает SetSequence(-1)).
		if (a == -1 || (a >= 0 && a < sequenceCount))
		{
			entity->SetSequence(a);
			ResetBlenders();
			return 1;
		}
		return 0;

	case ids::CMD_SET_LOOP_MODE: entity->SetLoopingMode(static_cast<StudioLoopingMode>(std::clamp(a, 0, 2))); return 1;

	case ids::CMD_SET_BLEND_MODE:
		_blendMode = a == 1 ? 1 : 0;
		ResetBlenders();
		return 1;

	case ids::CMD_SET_BLEND: entity->SetBlending(a, f); return 1;

	case ids::CMD_SET_SEQ_FPS:
		if (a >= 0 && a < sequenceCount)
		{
			model->Sequences[static_cast<std::size_t>(a)]->FPS = std::max(0.f, f);
			++_editRevision;
			return 1;
		}
		return 0;

	case ids::CMD_SET_SEQ_LOOPING:
		if (a >= 0 && a < sequenceCount)
		{
			auto& flags = model->Sequences[static_cast<std::size_t>(a)]->Flags;
			flags = b != 0 ? (flags | STUDIO_LOOPING) : (flags & ~STUDIO_LOOPING);
			++_editRevision;
			return 1;
		}
		return 0;

	case ids::CMD_SET_SEQ_ACTIVITY:
		if (a >= 0 && a < sequenceCount)
		{
			model->Sequences[static_cast<std::size_t>(a)]->Activity = b;
			++_editRevision;
			return 1;
		}
		return 0;

	case ids::CMD_SET_SEQ_ACTWEIGHT:
		if (a >= 0 && a < sequenceCount)
		{
			model->Sequences[static_cast<std::size_t>(a)]->ActivityWeight = b;
			++_editRevision;
			return 1;
		}
		return 0;

	case ids::CMD_SET_BODYGROUP: entity->SetBodygroup(a, b); return 1;
	case ids::CMD_SET_SKIN: entity->SetSkin(a); return 1;
	case ids::CMD_SET_CONTROLLER:
		// a — поле Index контроллера кости: 0-3 пользовательские, 4 (STUDIO_MOUTH_CONTROLLER) — рот (как в BoneControllersPanel).
		if (a >= STUDIO_MOUTH_CONTROLLER)
		{
			entity->SetMouth(static_cast<std::uint8_t>(std::clamp(f, 0.f, 255.f)));
		}
		else
		{
			entity->SetController(a, f);
		}
		return 1;

	case ids::CMD_SET_TOP_COLOR:
	case ids::CMD_SET_BOTTOM_COLOR:
		if (cmd == ids::CMD_SET_TOP_COLOR)
		{
			model->TopColor = std::clamp(a, 0, 255);
		}
		else
		{
			model->BottomColor = std::clamp(a, 0, 255);
		}

		QueueGl([this]()
			{
				if (_asset)
				{
					_asset->GetEditableStudioModel()->UpdateTextures(*_textureLoader);
				}
			});
		return 1;

	case ids::CMD_SET_RENDER_MODE: asset->CurrentRenderMode = static_cast<RenderMode>(std::clamp(a, 0, 3)); return 1;
	case ids::CMD_SET_OPACITY: entity->SetTransparency(std::clamp(f, 0.f, 1.f)); return 1;
	case ids::CMD_SET_FLAG: return SetFlag(a, b != 0) ? 1 : 0;

	case ids::CMD_SET_DRAW_SINGLE:
		if (a == 0)
		{
			asset->DrawSingleBoneIndex = b;
		}
		else if (a == 1)
		{
			asset->DrawSingleAttachmentIndex = b;
		}
		else
		{
			asset->DrawSingleHitboxIndex = b;
		}
		return 1;

	case ids::CMD_SET_MODEL_ORIGIN: entity->SetOrigin(ParseVec3(s)); return 1;
	case ids::CMD_CENTER_MODEL: entity->SetOrigin({0, 0, 0}); return 1;
	case ids::CMD_ALIGN_ON_GROUND: entity->AlignOnGround(); return 1;
	case ids::CMD_SET_GROUND_ORIGIN: asset->GetGroundEntity()->SetOrigin(ParseVec3(s)); return 1;
	case ids::CMD_SET_GROUND_TEXTURE_LENGTH: asset->GetGroundEntity()->GroundTextureLength = std::max(a, 1); return 1;

	case ids::CMD_SET_LIGHT_ANGLES: scene->SkyLight.Direction = AnglesToAimVector({static_cast<float>(a), static_cast<float>(b), 0.f}); return 1;
	case ids::CMD_SET_LIGHT_COLOR:
	{
		const auto color = ArgbToVector(static_cast<std::uint32_t>(a));
		scene->SkyLight.Color = glm::vec3{color.r, color.g, color.b};
		_appSettings->GetColorSettings()->Set(studiomodel::SkyLightColor, glm::vec4{color.r, color.g, color.b, 1.f});
		return 1;
	}
	case ids::CMD_SET_LIGHT_AMBIENT: scene->SkyLight.Ambient = static_cast<std::uint8_t>(std::clamp(a, 0, 255)); return 1;
	case ids::CMD_SET_LIGHT_SHADE: scene->SkyLight.Shade = static_cast<std::uint8_t>(std::clamp(a, 0, 255)); return 1;

	case ids::CMD_CAM_SELECT:
		cameras->SetCurrent(cameras->Get(a));
		return 1;
	case ids::CMD_CAM_NEXT: cameras->NextCamera(); return 1;
	case ids::CMD_CAM_PREV: cameras->PreviousCamera(); return 1;
	case ids::CMD_CAM_RESET: asset->OnCenterView(Axis::X, true); return 1;
	case ids::CMD_CAM_CENTER: asset->OnCenterView(static_cast<Axis>(std::clamp(a, 0, 2)), b != 0); return 1;
	case ids::CMD_CAM_FOV:
		if (auto op = a >= 0 ? cameras->Get(a) : cameras->GetCurrent(); op)
		{
			op->GetCamera()->SetFieldOfView(std::clamp(f, 1.f, 179.f));
			_studioSettings->SetCameraFOV(op->GetName().toStdString(), op->GetCamera()->GetFieldOfView());
			return 1;
		}
		return 0;

	case ids::CMD_SET_SCENE: asset->SetCurrentSceneIndex(a); return 1;

	case ids::CMD_TEX_SELECT:
	{
		// Индекс меши проверяется здесь: TextureEntity::SetMeshIndex не защищён от выхода за границы списка.
		const int meshCount = a >= 0 ? static_cast<int>(model->ComputeMeshList(a).size()) : 0;
		auto textureEntity = asset->GetTextureEntity();
		textureEntity->XOffset = textureEntity->YOffset = 0;
		textureEntity->SetTextureIndex(a, (b >= 0 && b < meshCount) ? b : -1);
		return 1;
	}
	case ids::CMD_TEX_MESH: return 0;
	case ids::CMD_TEX_SCALE: asset->GetTextureEntity()->TextureScale = std::clamp(f, 0.05f, 40.f); return 1;
	case ids::CMD_TEX_RESET_VIEW:
		asset->GetTextureEntity()->XOffset = asset->GetTextureEntity()->YOffset = 0;
		asset->GetTextureEntity()->TextureScale = 1.f;
		return 1;

	case ids::CMD_CLEAR_IMAGE:
		if (a == ids::IMG_GROUND)
		{
			asset->GetGroundEntity()->ClearImage();
		}
		else
		{
			asset->GetBackgroundEntity()->ShowBackground = false;
		}
		return 1;

	case ids::CMD_SET_EYE: model->EyePosition = ParseVec3(s); ++_editRevision; return 1;
	case ids::CMD_SET_BBOX:
	case ids::CMD_SET_CBOX:
	{
		const auto v = ParseFloats(s);

		if (v.size() < 6)
		{
			return 0;
		}

		auto& mins = cmd == ids::CMD_SET_BBOX ? model->BoundingMin : model->ClippingMin;
		auto& maxs = cmd == ids::CMD_SET_BBOX ? model->BoundingMax : model->ClippingMax;
		mins = {v[0], v[1], v[2]};
		maxs = {v[3], v[4], v[5]};
		++_editRevision;
		return 1;
	}
	case ids::CMD_SET_MODEL_FLAGS: model->Flags = a; ++_editRevision; return 1;
	case ids::CMD_FLIP_NORMALS: asset->FlipNormals(); ++_editRevision; return 1;

	case ids::CMD_XFORM_MOVE:
		studiomdl::ApplyMoveData(*model, studiomdl::GetMoveData(*model), ParseVec3(s));
		++_editRevision;
		return 1;
	case ids::CMD_XFORM_ROTATE:
		studiomdl::ApplyRotateData(*model, studiomdl::GetRotateData(*model), ParseVec3(s));
		++_editRevision;
		return 1;
	case ids::CMD_XFORM_SCALE:
	{
		const auto data = studiomdl::CalculateScaleData(*model, a);
		studiomdl::ApplyScaleData(*model, data, f);
		++_editRevision;
		return 1;
	}

	case ids::CMD_SAVE_VIEW: _savedViews = cameras->SaveViews(); return 1;
	case ids::CMD_RESTORE_VIEW:
		if (!_savedViews.empty())
		{
			cameras->RestoreViews(_savedViews);
			return 1;
		}
		return 0;

	default: break;
	}

	return 0;
}

// ---------------------------------------------------------------- состояние

void ViewerSession::FillState(float* out, int count)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	for (int i = 0; i < count; ++i)
	{
		out[i] = 0.f;
	}

	auto set = [&](int index, float value)
	{
		if (index >= 0 && index < count)
		{
			out[index] = value;
		}
	};

	set(ids::S_MODEL_REV, static_cast<float>(_modelRevision));
	set(ids::S_EDIT_REV, static_cast<float>(_editRevision));

	if (!_asset)
	{
		return;
	}

	set(ids::S_HAS_MODEL, 1.f);

	auto entity = _asset->GetEntity();
	auto model = _asset->GetEditableStudioModel();
	const int sequenceIndex = entity->GetSequence();
	const bool validSequence = sequenceIndex >= 0 && sequenceIndex < static_cast<int>(model->Sequences.size());

	set(ids::S_SEQUENCE, static_cast<float>(sequenceIndex));
	set(ids::S_FRAME, entity->GetFrame());
	set(ids::S_NUM_FRAMES, validSequence ? static_cast<float>(model->Sequences[static_cast<std::size_t>(sequenceIndex)]->NumFrames) : 0.f);
	set(ids::S_SPEED, entity->GetFrameRate());
	set(ids::S_PLAYING, _asset->PlaySequence ? 1.f : 0.f);
	set(ids::S_POLYS, static_cast<float>(_asset->GetScene()->GetDrawnPolygonsCount()));
	set(ids::S_SCENE, static_cast<float>(_asset->GetCurrentSceneIndex()));
	set(ids::S_CAMERA, static_cast<float>(_asset->GetProvider()->GetCameraOperators()->IndexOf(_asset->GetProvider()->GetCameraOperators()->GetCurrent())));
	set(ids::S_SEQ_FPS, validSequence ? model->Sequences[static_cast<std::size_t>(sequenceIndex)]->FPS : 0.f);
	set(ids::S_LOOP_MODE, static_cast<float>(static_cast<int>(entity->GetLoopingMode())));
	set(ids::S_BLEND0, entity->GetBlendingValue(0));
	set(ids::S_BLEND1, entity->GetBlendingValue(1));
	set(ids::S_BLEND_MODE, static_cast<float>(_blendMode));
	set(ids::S_SKIN, static_cast<float>(entity->GetSkin()));
	set(ids::S_BODY, static_cast<float>(entity->GetBodygroup()));
	set(ids::S_TEX_SCALE, _asset->GetTextureEntity()->TextureScale);
	{
		// Как SkyLightPanel оригинала: ползунки показывают углы, восстановленные из вектора направления.
		const auto& light = _asset->GetScene()->SkyLight;
		const glm::vec3 angles = VectorToAngles(light.Direction);
		set(ids::S_LIGHT_X, angles.x);
		set(ids::S_LIGHT_Y, angles.y);
		set(ids::S_LIGHT_AMBIENT, static_cast<float>(light.Ambient));
		set(ids::S_LIGHT_SHADE, static_cast<float>(light.Shade));
	}

	if (auto cameraOperator = _asset->GetProvider()->GetCameraOperators()->GetCurrent(); cameraOperator)
	{
		set(ids::S_FOV, cameraOperator->GetCamera()->GetFieldOfView());
	}

	set(ids::S_TOP_COLOR, static_cast<float>(model->TopColor));
	set(ids::S_BOTTOM_COLOR, static_cast<float>(model->BottomColor));
	set(ids::S_RENDER_MODE, static_cast<float>(static_cast<int>(_asset->CurrentRenderMode)));
	set(ids::S_OPACITY, entity->GetTransparency());
	set(ids::S_TEX_COUNT, static_cast<float>(model->Textures.size()));
	set(ids::S_FPS, _fps);
}

// ---------------------------------------------------------------- ввод

void ViewerSession::Touch(int kind, float x, float y, float extra)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset)
	{
		return;
	}

	const QPoint position{static_cast<int>(x), static_cast<int>(y)};

	auto send = [&](QEvent::Type type, Qt::MouseButton button, Qt::MouseButtons buttons, Qt::KeyboardModifiers modifiers)
	{
		QMouseEvent event{type, position, button, buttons, modifiers};
		_asset->MouseEvent(event, _lightEditing);
	};

	// Один палец — левая кнопка мыши (вращение). Два пальца — Shift + левая кнопка (перенос цели), как в оригинале.
	switch (kind)
	{
	case ids::T_ROTATE_DOWN: send(QEvent::MouseButtonPress, Qt::LeftButton, Qt::LeftButton, Qt::NoModifier); break;
	case ids::T_ROTATE_MOVE: send(QEvent::MouseMove, Qt::NoButton, Qt::LeftButton, Qt::NoModifier); break;
	case ids::T_ROTATE_UP: send(QEvent::MouseButtonRelease, Qt::LeftButton, Qt::NoButton, Qt::NoModifier); break;
	case ids::T_PAN_DOWN: send(QEvent::MouseButtonPress, Qt::LeftButton, Qt::LeftButton, Qt::ShiftModifier); break;
	case ids::T_PAN_MOVE: send(QEvent::MouseMove, Qt::NoButton, Qt::LeftButton, Qt::ShiftModifier); break;
	case ids::T_PAN_UP: send(QEvent::MouseButtonRelease, Qt::LeftButton, Qt::NoButton, Qt::ShiftModifier); break;
	case ids::T_ZOOM:
	{
		if (extra <= 0.f)
		{
			break;
		}

		if (_asset->GetCurrentSceneIndex() == 1)
		{
			auto textureEntity = _asset->GetTextureEntity();
			textureEntity->TextureScale = std::clamp(textureEntity->TextureScale * extra, 0.05f, 40.f);
		}
		else if (auto cameraOperator = _asset->GetProvider()->GetCameraOperators()->GetCurrent(); cameraOperator)
		{
			cameraOperator->PinchZoom(extra);
		}
		break;
	}
	default: break;
	}
}
}
