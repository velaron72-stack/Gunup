// См. MemoryFileSystem.hpp.
#include "bridge/MemoryFileSystem.hpp"

#include <algorithm>
#include <cctype>
#include <cstdio>

namespace bridge
{
static std::string NormalizeKey(const std::string& fileName)
{
	std::string name = fileName;

	if (const auto slash = name.find_last_of("/\\"); slash != std::string::npos)
	{
		name = name.substr(slash + 1);
	}

	std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
	return name;
}

MemoryFileSystem::MemoryFileSystem(Loader loader)
	: _loader(std::move(loader))
{
}

void MemoryFileSystem::AddFile(const std::string& name, std::vector<std::uint8_t>&& data)
{
	std::lock_guard<std::mutex> guard(_mutex);
	_files[NormalizeKey(name)] = std::make_shared<std::vector<std::uint8_t>>(std::move(data));
}

std::shared_ptr<std::vector<std::uint8_t>> MemoryFileSystem::Find(const std::string& fileName) const
{
	const std::string key = NormalizeKey(fileName);

	{
		std::lock_guard<std::mutex> guard(_mutex);

		if (auto it = _files.find(key); it != _files.end())
		{
			return it->second;
		}
	}

	if (_loader)
	{
		std::vector<std::uint8_t> bytes;

		if (_loader(key, bytes) && !bytes.empty())
		{
			auto shared = std::make_shared<std::vector<std::uint8_t>>(std::move(bytes));
			std::lock_guard<std::mutex> guard(_mutex);
			_files[key] = shared;
			return shared;
		}
	}

	return {};
}

bool MemoryFileSystem::FileExists(const std::string& fileName) const
{
	return Find(fileName) != nullptr;
}

FilePtr MemoryFileSystem::TryOpenAbsolute(const std::string& fileName, bool binary, bool exclusive) const
{
	(void)binary;
	(void)exclusive;

	auto data = Find(fileName);

	if (!data || data->empty())
	{
		return {};
	}

	// Буфер принадлежит _files и живёт, пока жива файловая система; FILE* только читает из него.
	return FilePtr{fmemopen(data->data(), data->size(), "rb")};
}

FilePtr MemoryFileSystem::TryOpen(std::string_view fileName, bool binary, bool exclusive) const
{
	return TryOpenAbsolute(std::string{fileName}, binary, exclusive);
}
}
