// JNI-мост Kotlin ↔ C++ (класс app.lambdaviewer.NativeBridge).
// Связь с HLAM: JNI используется исключительно как транспорт — вся логика находится в ViewerSession и перенесённом ядре HLAM.
// Здесь же настраивается gl4es (режим NOEGL поверх контекста GLES, созданного GLSurfaceView).
#include <jni.h>

#include <atomic>
#include <cstring>
#include <string>
#include <vector>

#include <dlfcn.h>

#include "bridge/BridgeIds.hpp"
#include "bridge/ImageCodec.hpp"
#include "bridge/MemoryFileSystem.hpp"
#include "bridge/MessageLog.hpp"
#include "bridge/ViewerSession.hpp"
#include "gl4esinit.h"

extern "C" void* eglGetProcAddress(const char* procname);

namespace
{
JavaVM* g_vm = nullptr;
jobject g_soundCallback = nullptr;
jmethodID g_soundMethod = nullptr;
std::atomic<int> g_surfaceWidth{1};
std::atomic<int> g_surfaceHeight{1};

void* GetProcAddressForGl4es(const char* name)
{
	static void* gles = dlopen("libGLESv2.so", RTLD_NOW | RTLD_GLOBAL);

	void* address = gles ? dlsym(gles, name) : nullptr;

	if (!address)
	{
		address = eglGetProcAddress(name);
	}

	return address;
}

void GetMainFramebufferSize(int* width, int* height)
{
	*width = g_surfaceWidth.load();
	*height = g_surfaceHeight.load();
}

std::string ToStdString(JNIEnv* env, jstring value)
{
	if (!value)
	{
		return {};
	}

	const char* chars = env->GetStringUTFChars(value, nullptr);
	std::string result = chars ? chars : "";

	if (chars)
	{
		env->ReleaseStringUTFChars(value, chars);
	}

	return result;
}

std::vector<std::uint8_t> ToBytes(JNIEnv* env, jbyteArray array)
{
	std::vector<std::uint8_t> result;

	if (!array)
	{
		return result;
	}

	const jsize length = env->GetArrayLength(array);
	result.resize(static_cast<std::size_t>(length));

	if (length > 0)
	{
		env->GetByteArrayRegion(array, 0, length, reinterpret_cast<jbyte*>(result.data()));
	}

	return result;
}

jbyteArray FromBytes(JNIEnv* env, const std::vector<std::uint8_t>& bytes)
{
	jbyteArray array = env->NewByteArray(static_cast<jsize>(bytes.size()));

	if (array && !bytes.empty())
	{
		env->SetByteArrayRegion(array, 0, static_cast<jsize>(bytes.size()), reinterpret_cast<const jbyte*>(bytes.data()));
	}

	return array;
}

jstring FromString(JNIEnv* env, const std::string& text)
{
	return env->NewStringUTF(text.c_str());
}

void PlaySoundOnJava(const std::string& name, float volume, int pitch)
{
	if (!g_vm || !g_soundCallback || !g_soundMethod)
	{
		return;
	}

	JNIEnv* env = nullptr;
	bool attached = false;

	if (g_vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK)
	{
		if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK)
		{
			return;
		}

		attached = true;
	}

	jstring jname = env->NewStringUTF(name.c_str());
	env->CallVoidMethod(g_soundCallback, g_soundMethod, jname, volume, static_cast<jint>(pitch));
	env->DeleteLocalRef(jname);

	if (env->ExceptionCheck())
	{
		env->ExceptionClear();
	}

	if (attached)
	{
		g_vm->DetachCurrentThread();
	}
}
}

extern "C"
{
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*)
{
	g_vm = vm;
	return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL Java_app_lambdaviewer_NativeBridge_nativeSurfaceCreated(JNIEnv*, jclass)
{
	set_getprocaddress(GetProcAddressForGl4es);
	set_getmainfbsize(GetMainFramebufferSize);
	bridge::ViewerSession::Instance().OnSurfaceCreated();
}

JNIEXPORT void JNICALL Java_app_lambdaviewer_NativeBridge_nativeSurfaceChanged(JNIEnv*, jclass, jint width, jint height)
{
	g_surfaceWidth = width;
	g_surfaceHeight = height;
	bridge::ViewerSession::Instance().OnSurfaceChanged(width, height);
}

JNIEXPORT void JNICALL Java_app_lambdaviewer_NativeBridge_nativeDrawFrame(JNIEnv*, jclass)
{
	bridge::ViewerSession::Instance().OnDrawFrame();
}

JNIEXPORT jstring JNICALL Java_app_lambdaviewer_NativeBridge_nativeLoadModel(
	JNIEnv* env, jclass, jstring name, jbyteArray data, jobject host)
{
	const std::string displayName = ToStdString(env, name);
	auto bytes = ToBytes(env, data);

	jclass hostClass = host ? env->GetObjectClass(host) : nullptr;
	jmethodID readSibling = hostClass ? env->GetMethodID(hostClass, "readSibling", "(Ljava/lang/String;)[B") : nullptr;

	// Колбэк запрашивает у Kotlin соседние файлы (NNT.mdl, NN01.mdl ...) из той же папки SAF.
	bridge::MemoryFileSystem::Loader loader = [env, host, readSibling](const std::string& baseName, std::vector<std::uint8_t>& out)
	{
		if (!host || !readSibling)
		{
			return false;
		}

		jstring jname = env->NewStringUTF(baseName.c_str());
		jobject result = env->CallObjectMethod(host, readSibling, jname);
		env->DeleteLocalRef(jname);

		if (env->ExceptionCheck())
		{
			env->ExceptionClear();
			return false;
		}

		if (!result)
		{
			return false;
		}

		out = ToBytes(env, static_cast<jbyteArray>(result));
		env->DeleteLocalRef(result);
		return !out.empty();
	};

	const std::string json = bridge::ViewerSession::Instance().LoadModel(displayName, std::move(bytes), std::move(loader));
	return FromString(env, json);
}

JNIEXPORT void JNICALL Java_app_lambdaviewer_NativeBridge_nativeCloseModel(JNIEnv*, jclass)
{
	bridge::ViewerSession::Instance().CloseModel();
}

JNIEXPORT jboolean JNICALL Java_app_lambdaviewer_NativeBridge_nativeHasModel(JNIEnv*, jclass)
{
	return bridge::ViewerSession::Instance().HasModel() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL Java_app_lambdaviewer_NativeBridge_nativeCommand(
	JNIEnv* env, jclass, jint cmd, jint a, jint b, jfloat f, jstring s)
{
	return bridge::ViewerSession::Instance().Command(cmd, a, b, f, ToStdString(env, s));
}

JNIEXPORT jstring JNICALL Java_app_lambdaviewer_NativeBridge_nativeQuery(JNIEnv* env, jclass, jint query, jint a, jint b)
{
	return FromString(env, bridge::ViewerSession::Instance().Query(query, a, b));
}

JNIEXPORT void JNICALL Java_app_lambdaviewer_NativeBridge_nativeState(JNIEnv* env, jclass, jfloatArray out)
{
	const jsize length = env->GetArrayLength(out);
	std::vector<float> values(static_cast<std::size_t>(length), 0.f);
	bridge::ViewerSession::Instance().FillState(values.data(), static_cast<int>(length));
	env->SetFloatArrayRegion(out, 0, length, values.data());
}

JNIEXPORT void JNICALL Java_app_lambdaviewer_NativeBridge_nativeTouch(JNIEnv*, jclass, jint kind, jfloat x, jfloat y, jfloat extra)
{
	bridge::ViewerSession::Instance().Touch(kind, x, y, extra);
}

JNIEXPORT jboolean JNICALL Java_app_lambdaviewer_NativeBridge_nativeTextureInfo(JNIEnv* env, jclass, jint index, jintArray out)
{
	int values[3] = {0, 0, 0};

	if (!bridge::ViewerSession::Instance().TextureInfo(index, values))
	{
		return JNI_FALSE;
	}

	env->SetIntArrayRegion(out, 0, 3, reinterpret_cast<const jint*>(values));
	return JNI_TRUE;
}

JNIEXPORT jintArray JNICALL Java_app_lambdaviewer_NativeBridge_nativeTextureArgb(JNIEnv* env, jclass, jint index)
{
	const auto pixels = bridge::ViewerSession::Instance().TextureArgb(index);

	if (pixels.empty())
	{
		return nullptr;
	}

	jintArray array = env->NewIntArray(static_cast<jsize>(pixels.size()));

	if (array)
	{
		env->SetIntArrayRegion(array, 0, static_cast<jsize>(pixels.size()), reinterpret_cast<const jint*>(pixels.data()));
	}

	return array;
}

JNIEXPORT jbyteArray JNICALL Java_app_lambdaviewer_NativeBridge_nativeTextureBmp(JNIEnv* env, jclass, jint index)
{
	const auto bytes = bridge::ViewerSession::Instance().TextureBmp(index);
	return bytes.empty() ? nullptr : FromBytes(env, bytes);
}

JNIEXPORT jstring JNICALL Java_app_lambdaviewer_NativeBridge_nativeImportBmp(
	JNIEnv* env, jclass, jint index, jbyteArray data)
{
	const auto bytes = ToBytes(env, data);
	return FromString(env, bridge::ViewerSession::Instance().ImportBmp(index, bytes.data(), bytes.size()));
}

JNIEXPORT jstring JNICALL Java_app_lambdaviewer_NativeBridge_nativeImportArgb(
	JNIEnv* env, jclass, jint index, jint width, jint height, jintArray pixels)
{
	const jsize length = env->GetArrayLength(pixels);

	if (length < width * height || width <= 0 || height <= 0)
	{
		return FromString(env, "{\"ok\":false,\"error\":\"Invalid pixel buffer\"}");
	}

	std::vector<std::uint32_t> values(static_cast<std::size_t>(length));
	env->GetIntArrayRegion(pixels, 0, length, reinterpret_cast<jint*>(values.data()));
	return FromString(env, bridge::ViewerSession::Instance().ImportArgb(index, width, height, values.data()));
}

JNIEXPORT jboolean JNICALL Java_app_lambdaviewer_NativeBridge_nativeSetSceneImage(
	JNIEnv* env, jclass, jint kind, jstring name, jint width, jint height, jintArray pixels)
{
	const jsize length = env->GetArrayLength(pixels);

	if (width <= 0 || height <= 0 || length < width * height)
	{
		return JNI_FALSE;
	}

	std::vector<std::uint32_t> values(static_cast<std::size_t>(length));
	env->GetIntArrayRegion(pixels, 0, length, reinterpret_cast<jint*>(values.data()));
	return bridge::ViewerSession::Instance().SetSceneImage(kind, ToStdString(env, name), width, height, values.data()) ? JNI_TRUE
																																  : JNI_FALSE;
}

JNIEXPORT jobjectArray JNICALL Java_app_lambdaviewer_NativeBridge_nativeSerialize(JNIEnv* env, jclass, jstring fileName)
{
	std::vector<std::uint8_t> mainFile;
	std::vector<std::uint8_t> textureFile;

	if (!bridge::ViewerSession::Instance().Serialize(ToStdString(env, fileName), mainFile, textureFile))
	{
		return nullptr;
	}

	jclass byteArrayClass = env->FindClass("[B");
	jobjectArray result = env->NewObjectArray(2, byteArrayClass, nullptr);

	if (!result)
	{
		return nullptr;
	}

	jbyteArray main = FromBytes(env, mainFile);
	env->SetObjectArrayElement(result, 0, main);
	env->DeleteLocalRef(main);

	if (!textureFile.empty())
	{
		jbyteArray texture = FromBytes(env, textureFile);
		env->SetObjectArrayElement(result, 1, texture);
		env->DeleteLocalRef(texture);
	}

	return result;
}

// Декодирует BMP/TGA в массив [width, height, pixels...] (ARGB). PNG/JPEG декодирует Kotlin через Bitmap.
JNIEXPORT jintArray JNICALL Java_app_lambdaviewer_NativeBridge_nativeDecodeImage(JNIEnv* env, jclass, jbyteArray data)
{
	const auto bytes = ToBytes(env, data);
	bridge::imagecodec::DecodedBmp decoded;
	std::string error;

	const bool isBmp = bytes.size() > 2 && bytes[0] == 'B' && bytes[1] == 'M';
	const bool ok = isBmp ? bridge::imagecodec::DecodeBmp(bytes.data(), bytes.size(), decoded, error)
						  : bridge::imagecodec::DecodeTga(bytes.data(), bytes.size(), decoded, error);

	if (!ok)
	{
		bridge::LogError("Image decode failed: " + error);
		return nullptr;
	}

	const jsize total = static_cast<jsize>(2 + decoded.argb.size());
	jintArray array = env->NewIntArray(total);

	if (!array)
	{
		return nullptr;
	}

	jint header[2] = {decoded.width, decoded.height};
	env->SetIntArrayRegion(array, 0, 2, header);
	env->SetIntArrayRegion(array, 2, static_cast<jsize>(decoded.argb.size()), reinterpret_cast<const jint*>(decoded.argb.data()));
	return array;
}

JNIEXPORT void JNICALL Java_app_lambdaviewer_NativeBridge_nativeSetSoundCallback(JNIEnv* env, jclass, jobject callback)
{
	if (g_soundCallback)
	{
		env->DeleteGlobalRef(g_soundCallback);
		g_soundCallback = nullptr;
		g_soundMethod = nullptr;
	}

	if (callback)
	{
		g_soundCallback = env->NewGlobalRef(callback);
		jclass callbackClass = env->GetObjectClass(callback);
		g_soundMethod = env->GetMethodID(callbackClass, "play", "(Ljava/lang/String;FI)V");
		bridge::ViewerSession::Instance().SetSoundCallback(PlaySoundOnJava);
	}
	else
	{
		bridge::ViewerSession::Instance().SetSoundCallback(nullptr);
	}
}
}
