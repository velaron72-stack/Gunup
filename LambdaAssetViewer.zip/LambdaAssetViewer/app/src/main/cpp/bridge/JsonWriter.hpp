// Минимальный сборщик JSON для ответов моста (Kotlin разбирает их через org.json).
// Связь с HLAM: служебный класс, у оригинала аналога нет (данные панелей Qt читались напрямую из EditableStudioModel).
#pragma once

#include <cstdio>
#include <string>

namespace bridge
{
class JsonWriter final
{
public:
	JsonWriter& BeginObject()
	{
		Separator();
		_text += '{';
		_needComma = false;
		return *this;
	}

	JsonWriter& EndObject()
	{
		_text += '}';
		_needComma = true;
		return *this;
	}

	JsonWriter& BeginArray()
	{
		Separator();
		_text += '[';
		_needComma = false;
		return *this;
	}

	JsonWriter& EndArray()
	{
		_text += ']';
		_needComma = true;
		return *this;
	}

	JsonWriter& Key(const char* key)
	{
		Separator();
		AppendString(key);
		_text += ':';
		_needComma = false;
		return *this;
	}

	JsonWriter& Str(const std::string& value)
	{
		Separator();
		AppendString(value);
		_needComma = true;
		return *this;
	}

	JsonWriter& Int(long long value)
	{
		Separator();
		_text += std::to_string(value);
		_needComma = true;
		return *this;
	}

	JsonWriter& Float(double value)
	{
		Separator();
		char buffer[48];
		std::snprintf(buffer, sizeof(buffer), "%.6g", value);
		_text += buffer;
		_needComma = true;
		return *this;
	}

	JsonWriter& Bool(bool value)
	{
		Separator();
		_text += value ? "true" : "false";
		_needComma = true;
		return *this;
	}

	JsonWriter& Field(const char* key, const std::string& value) { return Key(key).Str(value); }
	JsonWriter& Field(const char* key, const char* value) { return Key(key).Str(value); }
	JsonWriter& Field(const char* key, int value) { return Key(key).Int(value); }
	JsonWriter& Field(const char* key, long long value) { return Key(key).Int(value); }
	JsonWriter& Field(const char* key, std::size_t value) { return Key(key).Int(static_cast<long long>(value)); }
	JsonWriter& Field(const char* key, float value) { return Key(key).Float(value); }
	JsonWriter& Field(const char* key, double value) { return Key(key).Float(value); }
	JsonWriter& Field(const char* key, bool value) { return Key(key).Bool(value); }

	JsonWriter& Vec3(const char* key, float x, float y, float z)
	{
		Key(key).BeginArray().Float(x).Float(y).Float(z).EndArray();
		return *this;
	}

	const std::string& Text() const { return _text; }

private:
	void Separator()
	{
		if (_needComma)
		{
			_text += ',';
		}
	}

	void AppendString(const std::string& value)
	{
		_text += '"';

		for (unsigned char c : value)
		{
			switch (c)
			{
			case '"': _text += "\\\""; break;
			case '\\': _text += "\\\\"; break;
			case '\n': _text += "\\n"; break;
			case '\r': _text += "\\r"; break;
			case '\t': _text += "\\t"; break;
			default:
				if (c < 0x20)
				{
					char buffer[8];
					std::snprintf(buffer, sizeof(buffer), "\\u%04x", c);
					_text += buffer;
				}
				else
				{
					_text += static_cast<char>(c);
				}
				break;
			}
		}

		_text += '"';
	}

	std::string _text;
	bool _needComma = false;
};
}
