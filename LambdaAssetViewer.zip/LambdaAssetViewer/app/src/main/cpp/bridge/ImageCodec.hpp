// Кодеки изображений для работы с текстурами MDL без Qt.
// Связь с HLAM: заменяет plugins/halflife/studiomodel/ui/StudioModelTextureUtilities.cpp (ConvertImageToTexture,
// ConvertTextureToIndexed8Image, ConvertTextureToRGBImage), где использовались QImage/QPainter.
// Декодирование/кодирование PNG выполняет Kotlin (Bitmap), сюда приходят готовые ARGB-пиксели; BMP обрабатывается здесь,
// чтобы 8-битные палитры HL сохранялись побайтно.
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

#include "formats/studiomodel/EditableStudioModel.hpp"

namespace bridge::imagecodec
{
struct DecodedBmp
{
	int width = 0;
	int height = 0;
	bool indexed = false;
	std::vector<std::uint8_t> indices;
	std::vector<std::uint32_t> palette;
	std::vector<std::uint32_t> argb;
};

/// Кодирует текстуру MDL в 8-битный BMP с палитрой (формат, ожидаемый Half-Life и другими инструментами).
std::vector<std::uint8_t> EncodeBmp8(const studiomdl::StudioTextureData& texture);

/// Разбирает BMP 1/4/8/24/32 бит без сжатия. При ошибке возвращает false и заполняет error.
bool DecodeBmp(const std::uint8_t* data, std::size_t size, DecodedBmp& out, std::string& error);

/// Разбирает TGA (типы 1/2/3 и RLE-варианты 9/10/11; 8/15/16/24/32 бит). Результат — в DecodedBmp::argb.
bool DecodeTga(const std::uint8_t* data, std::size_t size, DecodedBmp& out, std::string& error);

/// Палитровая текстура → 0xAARRGGBB. Если masked — индекс 255 прозрачный.
std::vector<std::uint32_t> ToArgb(const studiomdl::StudioTextureData& texture, bool masked);

/// Квантует ARGB в индексированную текстуру MDL (точно, если уникальных цветов не больше 256, иначе median cut).
studiomdl::StudioTextureData Quantize(int width, int height, const std::uint32_t* argb, bool masked);

/// Масштабирование ближайшим соседом (Qt::FastTransformation оригинала).
std::vector<std::uint32_t> ScaleNearest(const std::uint32_t* src, int srcWidth, int srcHeight, int dstWidth, int dstHeight);
std::vector<std::uint8_t> ScaleNearest8(const std::uint8_t* src, int srcWidth, int srcHeight, int dstWidth, int dstHeight);

/// Правило оригинала: число пикселей должно быть кратно 4, ширина увеличивается до выполнения условия.
/// Возвращает true, если размер изменился.
bool AdjustToMultipleOf4(int& width, int& height);
}
