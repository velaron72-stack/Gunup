// ViewerSession: JSON-запросы для панелей интерфейса и операции с текстурами (просмотр, экспорт, импорт).
// Связь с HLAM: данные, которые в оригинале панели Qt (SequencesPanel, BodyPartsPanel, TexturesPanel, BonesPanel,
// BoneControllersPanel, AttachmentsPanel, HitboxesPanel, ModelDataPanel) читали из EditableStudioModel напрямую.
#include <algorithm>
#include <cstdio>

#include "bridge/BridgeIds.hpp"
#include "bridge/ImageCodec.hpp"
#include "bridge/MessageLog.hpp"
#include "bridge/ViewerSession.hpp"
#include "bridge/ViewerSessionInternal.hpp"
#include "entity/BackgroundEntity.hpp"
#include "entity/GroundEntity.hpp"
#include "entity/HLMVStudioModelEntity.hpp"
#include "entity/TextureEntity.hpp"
#include "formats/activity.hpp"
#include "formats/studiomodel/EditableStudioModel.hpp"
#include "formats/studiomodel/StudioModelUtils.hpp"
#include "graphics/GraphicsUtils.hpp"
#include "graphics/Palette.hpp"
#include "graphics/Scene.hpp"
#include "graphics/TextureLoader.hpp"
#include "plugins/halflife/studiomodel/StudioModelAsset.hpp"
#include "plugins/halflife/studiomodel/StudioModelColors.hpp"
#include "settings/ApplicationSettings.hpp"

namespace bridge
{
namespace ids = bridge::ids;

namespace
{
void WriteVec3(JsonWriter& json, const char* key, const glm::vec3& v)
{
	json.Vec3(key, v.x, v.y, v.z);
}

std::uint32_t VectorToArgb(const glm::vec4& color)
{
	auto to8 = [](float v) { return static_cast<std::uint32_t>(std::clamp(v, 0.f, 1.f) * 255.f + 0.5f); };
	return (to8(color.a) << 24) | (to8(color.r) << 16) | (to8(color.g) << 8) | to8(color.b);
}

int BoneIndex(const studiomdl::StudioBone* bone)
{
	return bone ? bone->ArrayIndex : -1;
}
}

std::string ViewerSession::Query(int query, int a, int b)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	switch (query)
	{
	case ids::Q_MESSAGES: return GetLogText();
	case ids::Q_COLORS: return QueryColors();
	case ids::Q_ACTIVITIES: return QueryActivities();
	default: break;
	}

	if (!_asset)
	{
		return "[]";
	}

	switch (query)
	{
	case ids::Q_INFO: return QueryInfo();
	case ids::Q_SEQUENCES: return QuerySequences();
	case ids::Q_BODYPARTS: return QueryBodyparts();
	case ids::Q_TEXTURES: return QueryTextures();
	case ids::Q_BONES: return QueryBones();
	case ids::Q_CONTROLLERS: return QueryControllers();
	case ids::Q_ATTACHMENTS: return QueryAttachments();
	case ids::Q_HITBOXES: return QueryHitboxes();
	case ids::Q_CAMERAS: return QueryCameras();
	case ids::Q_TEXTURE_MESHES:
		return std::to_string(_asset->GetEditableStudioModel()->ComputeMeshList(a).size());
	default: break;
	}

	(void)b;
	return "[]";
}

std::string ViewerSession::QueryInfo()
{
	auto model = _asset->GetEditableStudioModel();
	JsonWriter json;
	json.BeginObject();
	json.Field("fileName", _fileName);
	json.Field("bones", model->Bones.size());
	json.Field("controllers", model->BoneControllers.size());
	json.Field("hitboxes", model->Hitboxes.size());
	json.Field("sequences", model->Sequences.size());
	json.Field("sequenceGroups", model->SequenceGroups.size());
	json.Field("textures", model->Textures.size());
	json.Field("skinFamilies", model->SkinFamilies.size());
	json.Field("skinRefs", model->SkinFamilies.empty() ? static_cast<std::size_t>(0) : model->SkinFamilies[0].size());
	json.Field("bodyparts", model->Bodyparts.size());
	json.Field("attachments", model->Attachments.size());
	json.Field("transitions", model->Transitions.size());

	std::size_t submodels = 0;
	std::size_t meshes = 0;
	std::size_t vertices = 0;
	std::size_t normals = 0;
	std::size_t triangles = 0;

	for (const auto& part : model->Bodyparts)
	{
		submodels += part->Models.size();

		for (const auto& sub : part->Models)
		{
			meshes += sub.Meshes.size();
			vertices += sub.Vertices.size();
			normals += sub.Normals.size();

			for (const auto& mesh : sub.Meshes)
			{
				triangles += static_cast<std::size_t>(std::max(mesh.NumTriangles, 0));
			}
		}
	}

	std::size_t textureBytes = 0;

	for (const auto& texture : model->Textures)
	{
		textureBytes += texture->Data.Pixels.size() + graphics::RGBPalette::EntriesCount * 3;
	}

	json.Field("submodels", submodels);
	json.Field("meshes", meshes);
	json.Field("vertices", vertices);
	json.Field("normals", normals);
	json.Field("triangles", triangles);
	json.Field("textureBytes", textureBytes);
	WriteVec3(json, "eye", model->EyePosition);
	WriteVec3(json, "bbmin", model->BoundingMin);
	WriteVec3(json, "bbmax", model->BoundingMax);
	WriteVec3(json, "cbmin", model->ClippingMin);
	WriteVec3(json, "cbmax", model->ClippingMax);
	json.Field("flags", model->Flags);
	json.Field("xash", model->IsXashModel);
	json.Field("externalTextures", model->HasExternalTextureFile);
	json.Field("topColor", model->TopColor);
	json.Field("bottomColor", model->BottomColor);
	json.EndObject();
	return json.Text();
}

std::string ViewerSession::QuerySequences()
{
	auto model = _asset->GetEditableStudioModel();
	JsonWriter json;
	json.BeginArray();

	int index = 0;

	for (const auto& sequencePtr : model->Sequences)
	{
		const auto& sequence = *sequencePtr;
		json.BeginObject();
		json.Field("i", index++);
		json.Field("name", sequence.Label);
		json.Field("frames", sequence.NumFrames);
		json.Field("fps", sequence.FPS);
		json.Field("flags", sequence.Flags);
		json.Field("looping", (sequence.Flags & STUDIO_LOOPING) != 0);
		json.Field("activity", sequence.Activity);
		json.Field("actWeight", sequence.ActivityWeight);
		json.Field("motionType", sequence.MotionType);
		json.Field("motionBone", sequence.MotionBone);
		json.Field("blends", sequence.AnimationBlends.size());
		WriteVec3(json, "linear", sequence.LinearMovement);
		WriteVec3(json, "bbmin", sequence.BBMin);
		WriteVec3(json, "bbmax", sequence.BBMax);
		json.Field("entryNode", sequence.EntryNode);
		json.Field("exitNode", sequence.ExitNode);
		json.Field("nodeFlags", sequence.NodeFlags);
		json.Field("nextSequence", sequence.NextSequence);

		json.Key("blendData").BeginArray();

		for (const auto& blend : sequence.BlendData)
		{
			json.BeginObject();
			json.Field("type", blend.Type);
			json.Field("start", blend.Start);
			json.Field("end", blend.End);
			json.EndObject();
		}

		json.EndArray();

		json.Key("events").BeginArray();

		for (const auto& event : sequence.Events)
		{
			json.BeginObject();
			json.Field("frame", event->Frame);
			json.Field("id", event->EventId);
			json.Field("type", event->Type);
			json.Field("options", event->Options);
			json.EndObject();
		}

		json.EndArray();
		json.EndObject();
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryBodyparts()
{
	auto model = _asset->GetEditableStudioModel();
	auto entity = _asset->GetEntity();
	JsonWriter json;
	json.BeginArray();

	int index = 0;

	for (const auto& partPtr : model->Bodyparts)
	{
		const auto& part = *partPtr;
		json.BeginObject();
		json.Field("i", index);
		json.Field("name", part.Name);
		json.Field("base", part.Base);
		json.Field("value", entity->GetBodyValueForGroup(index));
		json.Key("models").BeginArray();

		for (const auto& sub : part.Models)
		{
			json.Str(sub.Name);
		}

		json.EndArray();
		json.EndObject();
		++index;
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryTextures()
{
	auto model = _asset->GetEditableStudioModel();
	JsonWriter json;
	json.BeginObject();
	json.Key("textures").BeginArray();

	int index = 0;

	for (const auto& texturePtr : model->Textures)
	{
		const auto& texture = *texturePtr;
		int low;
		int mid;
		int high;

		json.BeginObject();
		json.Field("i", index);
		json.Field("name", texture.Name);
		json.Field("w", texture.Data.Width);
		json.Field("h", texture.Data.Height);
		json.Field("flags", texture.Flags);
		json.Field("meshes", model->ComputeMeshList(index).size());
		json.Field("remap", graphics::TryGetRemapColors(texture.Name, low, mid, high));
		json.EndObject();
		++index;
	}

	json.EndArray();
	json.Key("skinFamilies").BeginArray();

	for (const auto& family : model->SkinFamilies)
	{
		json.BeginArray();

		for (const auto value : family)
		{
			json.Int(value);
		}

		json.EndArray();
	}

	json.EndArray();
	json.Field("topColor", model->TopColor);
	json.Field("bottomColor", model->BottomColor);
	json.EndObject();
	return json.Text();
}

std::string ViewerSession::QueryBones()
{
	auto model = _asset->GetEditableStudioModel();
	JsonWriter json;
	json.BeginArray();

	for (const auto& bonePtr : model->Bones)
	{
		const auto& bone = *bonePtr;
		json.BeginObject();
		json.Field("i", bone.ArrayIndex);
		json.Field("name", bone.Name);
		json.Field("parent", BoneIndex(bone.Parent));
		json.Field("parentName", bone.Parent ? bone.Parent->Name : std::string{});
		json.Field("flags", bone.Flags);
		json.Key("axes").BeginArray();

		for (const auto& axis : bone.Axes)
		{
			json.BeginObject();
			json.Field("controller", axis.Controller ? axis.Controller->ArrayIndex : -1);
			json.Field("value", axis.Value);
			json.Field("scale", axis.Scale);
			json.EndObject();
		}

		json.EndArray();
		json.EndObject();
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryControllers()
{
	auto model = _asset->GetEditableStudioModel();
	auto entity = _asset->GetEntity();
	JsonWriter json;
	json.BeginArray();

	int index = 0;

	for (const auto& controllerPtr : model->BoneControllers)
	{
		const auto& controller = *controllerPtr;
		const bool isMouth = controller.Index == STUDIO_MOUTH_CONTROLLER;
		const char* typeName = studiomdl::ControlToString(controller.Type & STUDIO_TYPES);

		json.BeginObject();
		json.Field("i", index);
		json.Field("type", controller.Type);
		json.Field("typeName", std::string{isMouth ? "Mouth" : (typeName ? typeName : "?")});
		json.Field("isMouth", isMouth);
		json.Field("start", isMouth ? 0.f : controller.Start);
		json.Field("end", isMouth ? 255.f : controller.End);
		json.Field("rest", controller.Rest);
		json.Field("index", controller.Index);
		json.Field("value", isMouth ? static_cast<float>(entity->GetMouth()) : entity->GetControllerValue(controller.Index));

		const auto attached = model->FindBoneControllerIsAttachedTo(index);
		json.Field("bone", attached ? attached->first : -1);
		json.Field("axis", attached ? attached->second : -1);
		json.EndObject();
		++index;
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryAttachments()
{
	auto model = _asset->GetEditableStudioModel();
	JsonWriter json;
	json.BeginArray();

	int index = 0;

	for (const auto& attachmentPtr : model->Attachments)
	{
		const auto& attachment = *attachmentPtr;
		json.BeginObject();
		json.Field("i", index++);
		json.Field("name", attachment.Name);
		json.Field("type", attachment.Type);
		json.Field("bone", BoneIndex(attachment.Bone));
		json.Field("boneName", attachment.Bone ? attachment.Bone->Name : std::string{});
		WriteVec3(json, "origin", attachment.Origin);
		json.EndObject();
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryHitboxes()
{
	auto model = _asset->GetEditableStudioModel();
	JsonWriter json;
	json.BeginArray();

	int index = 0;

	for (const auto& hitboxPtr : model->Hitboxes)
	{
		const auto& hitbox = *hitboxPtr;
		json.BeginObject();
		json.Field("i", index++);
		json.Field("bone", BoneIndex(hitbox.Bone));
		json.Field("boneName", hitbox.Bone ? hitbox.Bone->Name : std::string{});
		json.Field("group", hitbox.Group);
		WriteVec3(json, "min", hitbox.Min);
		WriteVec3(json, "max", hitbox.Max);
		json.EndObject();
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryCameras()
{
	auto cameras = _asset->GetProvider()->GetCameraOperators();
	JsonWriter json;
	json.BeginArray();

	for (int i = 0; i < cameras->Count(); ++i)
	{
		auto op = cameras->Get(i);
		json.BeginObject();
		json.Field("i", i);
		json.Field("name", op->GetName().toStdString());
		json.Field("fov", op->GetCamera()->GetFieldOfView());
		json.Field("current", op == cameras->GetCurrent());
		json.EndObject();
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryColors()
{
	auto colors = _appSettings->GetColorSettings();
	JsonWriter json;
	json.BeginArray();

	struct Entry
	{
		int Id;
		const QString* Key;
		const char* Title;
	};

	const Entry entries[] = {
		{ids::COLOR_GROUND, &studiomodel::GroundColor, "Ground"},
		{ids::COLOR_BACKGROUND, &studiomodel::BackgroundColor, "Background"},
		{ids::COLOR_CROSSHAIR, &studiomodel::CrosshairColor, "Crosshair"},
		{ids::COLOR_SKYLIGHT, &studiomodel::SkyLightColor, "Sky light"},
		{ids::COLOR_WIREFRAME, &studiomodel::WireframeColor, "Wireframe"},
		{ids::COLOR_HITBOX_EDGE, &studiomodel::HitboxEdgeColor, "Hitbox edge"},
		{ids::COLOR_HITBOX_FACE, &studiomodel::HitboxFaceColor, "Hitbox face"},
		{ids::COLOR_SINGLE_HITBOX_EDGE, &studiomodel::SingleHitboxEdgeColor, "Single hitbox edge"},
		{ids::COLOR_SINGLE_HITBOX_FACE, &studiomodel::SingleHitboxFaceColor, "Single hitbox face"},
	};

	for (const auto& entry : entries)
	{
		json.BeginObject();
		json.Field("id", entry.Id);
		json.Field("title", entry.Title);
		json.Field("argb", static_cast<long long>(VectorToArgb(colors->GetColor(*entry.Key))));
		json.Field("default", static_cast<long long>(VectorToArgb(colors->GetDefaultColor(*entry.Key))));
		json.Field("alpha", colors->HasAlphaChannel(*entry.Key));
		json.EndObject();
	}

	json.EndArray();
	return json.Text();
}

std::string ViewerSession::QueryActivities()
{
	JsonWriter json;
	json.BeginArray();
	json.BeginObject().Field("id", 0).Field("name", "None").EndObject();

	for (const auto& entry : ActivityMap)
	{
		json.BeginObject().Field("id", entry.Type).Field("name", entry.Name).EndObject();
	}

	json.EndArray();
	return json.Text();
}

// ---------------------------------------------------------------- текстуры

bool ViewerSession::TextureInfo(int index, int* out3)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset)
	{
		return false;
	}

	auto model = _asset->GetEditableStudioModel();

	if (index < 0 || index >= static_cast<int>(model->Textures.size()))
	{
		return false;
	}

	const auto& texture = *model->Textures[static_cast<std::size_t>(index)];
	out3[0] = texture.Data.Width;
	out3[1] = texture.Data.Height;
	out3[2] = texture.Flags;
	return true;
}

std::vector<std::uint32_t> ViewerSession::TextureArgb(int index)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset)
	{
		return {};
	}

	auto model = _asset->GetEditableStudioModel();

	if (index < 0 || index >= static_cast<int>(model->Textures.size()))
	{
		return {};
	}

	const auto& texture = *model->Textures[static_cast<std::size_t>(index)];
	return imagecodec::ToArgb(texture.Data, (texture.Flags & STUDIO_NF_MASKED) != 0);
}

std::vector<std::uint8_t> ViewerSession::TextureBmp(int index)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset)
	{
		return {};
	}

	auto model = _asset->GetEditableStudioModel();

	if (index < 0 || index >= static_cast<int>(model->Textures.size()))
	{
		return {};
	}

	return imagecodec::EncodeBmp8(model->Textures[static_cast<std::size_t>(index)]->Data);
}

namespace
{
// Правило ImportTextureFrom оригинала: если текстура используется только в части скинов, её размер менять нельзя.
bool AllowTextureResizing(const studiomdl::EditableStudioModel& model, int textureIndex)
{
	if (model.SkinFamilies.size() > 1)
	{
		for (std::size_t i = 0; i < model.SkinFamilies[0].size(); ++i)
		{
			std::size_t count = 0;

			for (std::size_t j = 0; j < model.SkinFamilies.size(); ++j)
			{
				if (textureIndex == model.SkinFamilies[j][i])
				{
					++count;
				}
			}

			if (count != 0 && count != model.SkinFamilies.size())
			{
				return false;
			}
		}
	}

	return true;
}

std::string ErrorJson(const std::string& message)
{
	JsonWriter json;
	json.BeginObject().Field("ok", false).Field("error", message).EndObject();
	return json.Text();
}
}

std::string ViewerSession::ImportBmp(int index, const std::uint8_t* data, std::size_t size)
{
	imagecodec::DecodedBmp decoded;
	std::string error;

	if (!imagecodec::DecodeBmp(data, size, decoded, error))
	{
		return ErrorJson(error);
	}

	// Индексированный BMP сохраняет свою палитру; остальные форматы проходят квантование в ImportArgb.
	if (!decoded.indexed)
	{
		return ImportArgb(index, decoded.width, decoded.height, decoded.argb.data());
	}

	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset)
	{
		return ErrorJson("No model loaded");
	}

	auto model = _asset->GetEditableStudioModel();

	if (index < 0 || index >= static_cast<int>(model->Textures.size()))
	{
		return ErrorJson("Invalid texture index");
	}

	auto& texture = *model->Textures[static_cast<std::size_t>(index)];
	JsonWriter json;
	json.BeginObject().Field("ok", true).Key("warnings").BeginArray();

	int width = decoded.width;
	int height = decoded.height;
	std::vector<std::uint8_t> indices = decoded.indices;

	if (!AllowTextureResizing(*model, index))
	{
		if (width != texture.Data.Width || height != texture.Data.Height)
		{
			indices = imagecodec::ScaleNearest8(indices.data(), width, height, texture.Data.Width, texture.Data.Height);
			width = texture.Data.Width;
			height = texture.Data.Height;
			json.Str("Image was rescaled to the original size: the texture is used in only some skins");
		}
	}
	else if (int newWidth = width; imagecodec::AdjustToMultipleOf4(newWidth, height))
	{
		indices = imagecodec::ScaleNearest8(indices.data(), width, height, newWidth, height);
		width = newWidth;
		json.Str("Image pixel count is not a multiple of 4 and was upscaled");
	}

	studiomdl::StudioTextureData newData;
	newData.Width = width;
	newData.Height = height;
	newData.Pixels.resize(indices.size());

	for (std::size_t i = 0; i < indices.size(); ++i)
	{
		newData.Pixels[i] = std::byte{indices[i]};
	}

	for (std::size_t i = 0; i < graphics::RGBPalette::EntriesCount; ++i)
	{
		const std::uint32_t color = decoded.palette[i];
		newData.Palette[i] = {static_cast<std::uint8_t>((color >> 16) & 0xFF), static_cast<std::uint8_t>((color >> 8) & 0xFF),
			static_cast<std::uint8_t>(color & 0xFF)};
	}

	json.EndArray();

	auto scaled = studiomdl::CalculateScaledSTCoordinatesData(
		*model, index, texture.Data.Width, texture.Data.Height, newData.Width, newData.Height);

	texture.Data = std::move(newData);
	studiomdl::ApplyScaledSTCoordinatesData(*model, index, scaled.second);
	++_editRevision;

	QueueGl([this, index]()
		{
			if (_asset)
			{
				_asset->GetEditableStudioModel()->UpdateTexture(*_textureLoader, static_cast<std::size_t>(index));
			}
		});

	json.EndObject();
	return json.Text();
}

std::string ViewerSession::ImportArgb(int index, int width, int height, const std::uint32_t* argb)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset)
	{
		return ErrorJson("No model loaded");
	}

	auto model = _asset->GetEditableStudioModel();

	if (index < 0 || index >= static_cast<int>(model->Textures.size()))
	{
		return ErrorJson("Invalid texture index");
	}

	if (width <= 0 || height <= 0 || width > 16384 || height > 16384)
	{
		return ErrorJson("Invalid image dimensions");
	}

	auto& texture = *model->Textures[static_cast<std::size_t>(index)];
	const bool masked = (texture.Flags & STUDIO_NF_MASKED) != 0;

	JsonWriter json;
	json.BeginObject().Field("ok", true).Key("warnings").BeginArray();

	std::vector<std::uint32_t> pixels{argb, argb + static_cast<std::size_t>(width) * height};

	if (!AllowTextureResizing(*model, index))
	{
		if (width != texture.Data.Width || height != texture.Data.Height)
		{
			pixels = imagecodec::ScaleNearest(pixels.data(), width, height, texture.Data.Width, texture.Data.Height);
			width = texture.Data.Width;
			height = texture.Data.Height;
			json.Str("Image was rescaled to the original size: the texture is used in only some skins");
		}
	}
	else if (int newWidth = width; imagecodec::AdjustToMultipleOf4(newWidth, height))
	{
		pixels = imagecodec::ScaleNearest(pixels.data(), width, height, newWidth, height);
		width = newWidth;
		json.Str("Image pixel count is not a multiple of 4 and was upscaled");
	}

	json.Str("Image was converted to an indexed 8 bit image. Loss of color depth may occur.");
	json.EndArray();

	auto newData = imagecodec::Quantize(width, height, pixels.data(), masked);

	auto scaled = studiomdl::CalculateScaledSTCoordinatesData(
		*model, index, texture.Data.Width, texture.Data.Height, newData.Width, newData.Height);

	texture.Data = std::move(newData);
	studiomdl::ApplyScaledSTCoordinatesData(*model, index, scaled.second);
	++_editRevision;

	QueueGl([this, index]()
		{
			if (_asset)
			{
				_asset->GetEditableStudioModel()->UpdateTexture(*_textureLoader, static_cast<std::size_t>(index));
			}
		});

	json.EndObject();
	return json.Text();
}

bool ViewerSession::SetSceneImage(int kind, const std::string& name, int width, int height, const std::uint32_t* argb)
{
	std::lock_guard<std::recursive_mutex> guard(_mutex);

	if (!_asset || width <= 0 || height <= 0)
	{
		return false;
	}

	std::vector<std::byte> rgba(static_cast<std::size_t>(width) * height * 4);

	for (std::size_t i = 0; i < static_cast<std::size_t>(width) * height; ++i)
	{
		const std::uint32_t p = argb[i];
		rgba[i * 4 + 0] = std::byte{static_cast<unsigned char>((p >> 16) & 0xFF)};
		rgba[i * 4 + 1] = std::byte{static_cast<unsigned char>((p >> 8) & 0xFF)};
		rgba[i * 4 + 2] = std::byte{static_cast<unsigned char>(p & 0xFF)};
		rgba[i * 4 + 3] = std::byte{static_cast<unsigned char>((p >> 24) & 0xFF)};
	}

	if (kind == ids::IMG_GROUND)
	{
		auto ground = _asset->GetGroundEntity();
		ground->SetImage(std::string{name}, graphics::Image{width, height, std::move(rgba)});
		ground->ShowGround = true;
		ground->EnableTexture = true;
	}
	else
	{
		auto background = _asset->GetBackgroundEntity();
		background->SetImage(std::string{name}, graphics::Image{width, height, std::move(rgba)});
		background->ShowBackground = true;
	}

	return true;
}
}
