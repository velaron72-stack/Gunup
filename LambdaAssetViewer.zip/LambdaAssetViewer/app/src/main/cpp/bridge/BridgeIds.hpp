// ФАЙЛ СГЕНЕРИРОВАН tools/gen_bridge_ids.py — не редактировать вручную.
#pragma once

namespace bridge::ids
{
// Команды nativeCommand(cmd, a, b, f, s)
inline constexpr int CMD_PLAY_PAUSE = 1;
inline constexpr int CMD_STOP = 2;
inline constexpr int CMD_RESTART = 3;
inline constexpr int CMD_STEP_FRAME = 4;
inline constexpr int CMD_SET_FRAME = 5;
inline constexpr int CMD_SET_SPEED = 6;
inline constexpr int CMD_SET_SEQUENCE = 7;
inline constexpr int CMD_SET_LOOP_MODE = 8;
inline constexpr int CMD_SET_BLEND_MODE = 9;
inline constexpr int CMD_SET_BLEND = 10;
inline constexpr int CMD_SET_SEQ_FPS = 11;
inline constexpr int CMD_SET_SEQ_LOOPING = 12;
inline constexpr int CMD_SET_SEQ_ACTIVITY = 13;
inline constexpr int CMD_SET_SEQ_ACTWEIGHT = 14;
inline constexpr int CMD_SET_BODYGROUP = 15;
inline constexpr int CMD_SET_SKIN = 16;
inline constexpr int CMD_SET_CONTROLLER = 17;
inline constexpr int CMD_SET_TOP_COLOR = 18;
inline constexpr int CMD_SET_BOTTOM_COLOR = 19;
inline constexpr int CMD_SET_RENDER_MODE = 20;
inline constexpr int CMD_SET_OPACITY = 21;
inline constexpr int CMD_SET_FLAG = 22;
inline constexpr int CMD_SET_DRAW_SINGLE = 23;
inline constexpr int CMD_SET_GROUND_LENGTH = 24;
inline constexpr int CMD_SET_ASPECT = 25;
inline constexpr int CMD_SET_MODEL_ORIGIN = 26;
inline constexpr int CMD_CENTER_MODEL = 27;
inline constexpr int CMD_ALIGN_ON_GROUND = 28;
inline constexpr int CMD_SET_GROUND_ORIGIN = 29;
inline constexpr int CMD_SET_LIGHT_ANGLES = 30;
inline constexpr int CMD_SET_LIGHT_COLOR = 31;
inline constexpr int CMD_SET_LIGHT_AMBIENT = 32;
inline constexpr int CMD_SET_LIGHT_SHADE = 33;
inline constexpr int CMD_CAM_SELECT = 34;
inline constexpr int CMD_CAM_RESET = 35;
inline constexpr int CMD_CAM_CENTER = 36;
inline constexpr int CMD_CAM_FOV = 37;
inline constexpr int CMD_CAM_NEXT = 38;
inline constexpr int CMD_CAM_PREV = 39;
inline constexpr int CMD_SET_SCENE = 40;
inline constexpr int CMD_TEX_SELECT = 41;
inline constexpr int CMD_TEX_MESH = 42;
inline constexpr int CMD_TEX_SCALE = 43;
inline constexpr int CMD_TEX_RESET_VIEW = 44;
inline constexpr int CMD_SET_COLOR = 45;
inline constexpr int CMD_RESET_COLORS = 46;
inline constexpr int CMD_SET_MOUSE_SENS = 47;
inline constexpr int CMD_SET_WHEEL_SPEED = 48;
inline constexpr int CMD_SET_TEX_FILTER = 49;
inline constexpr int CMD_SET_EYE = 50;
inline constexpr int CMD_SET_BBOX = 51;
inline constexpr int CMD_SET_CBOX = 52;
inline constexpr int CMD_SET_MODEL_FLAGS = 53;
inline constexpr int CMD_FLIP_NORMALS = 54;
inline constexpr int CMD_XFORM_MOVE = 55;
inline constexpr int CMD_XFORM_ROTATE = 56;
inline constexpr int CMD_XFORM_SCALE = 57;
inline constexpr int CMD_CLEAR_IMAGE = 58;
inline constexpr int CMD_SET_GROUND_TEXTURE_LENGTH = 59;
inline constexpr int CMD_SAVE_VIEW = 60;
inline constexpr int CMD_RESTORE_VIEW = 61;
inline constexpr int CMD_CLEAR_LOG = 62;
inline constexpr int CMD_SET_AUTODETECT_VIEWMODEL = 63;

// Флаги для CMD_SET_FLAG (b = 0/1)
inline constexpr int FLAG_HITBOXES = 0;
inline constexpr int FLAG_BONES = 1;
inline constexpr int FLAG_ATTACHMENTS = 2;
inline constexpr int FLAG_EYE = 3;
inline constexpr int FLAG_BBOX = 4;
inline constexpr int FLAG_CBOX = 5;
inline constexpr int FLAG_BACKFACE = 6;
inline constexpr int FLAG_WIREFRAME_OVERLAY = 7;
inline constexpr int FLAG_SHADOWS = 8;
inline constexpr int FLAG_SHADOW_FIX = 9;
inline constexpr int FLAG_AXES = 10;
inline constexpr int FLAG_NORMALS = 11;
inline constexpr int FLAG_PLAYER_HITBOX = 12;
inline constexpr int FLAG_MIRROR_X = 13;
inline constexpr int FLAG_MIRROR_Y = 14;
inline constexpr int FLAG_MIRROR_Z = 15;
inline constexpr int FLAG_CROSSHAIR = 16;
inline constexpr int FLAG_GUIDELINES = 17;
inline constexpr int FLAG_OFFSCREEN = 18;
inline constexpr int FLAG_GROUND = 19;
inline constexpr int FLAG_GROUND_MIRROR = 20;
inline constexpr int FLAG_GROUND_TEXTURE = 21;
inline constexpr int FLAG_GROUND_TILING = 22;
inline constexpr int FLAG_BACKGROUND = 23;
inline constexpr int FLAG_SOUNDS = 24;
inline constexpr int FLAG_SOUND_PITCH = 25;
inline constexpr int FLAG_LIGHT_EDIT = 26;
inline constexpr int FLAG_UV_SHOW = 27;
inline constexpr int FLAG_UV_OVERLAY = 28;
inline constexpr int FLAG_UV_AA = 29;
inline constexpr int FLAG_POW2 = 30;
inline constexpr int FLAG_INVERT_X = 31;
inline constexpr int FLAG_INVERT_Y = 32;

// Строковые запросы nativeQuery(q, a, b)
inline constexpr int Q_INFO = 0;
inline constexpr int Q_SEQUENCES = 1;
inline constexpr int Q_BODYPARTS = 2;
inline constexpr int Q_TEXTURES = 3;
inline constexpr int Q_BONES = 4;
inline constexpr int Q_CONTROLLERS = 5;
inline constexpr int Q_ATTACHMENTS = 6;
inline constexpr int Q_HITBOXES = 7;
inline constexpr int Q_MESSAGES = 8;
inline constexpr int Q_FLAGS = 9;
inline constexpr int Q_COLORS = 10;
inline constexpr int Q_ACTIVITIES = 11;
inline constexpr int Q_TEXTURE_MESHES = 12;
inline constexpr int Q_CAMERAS = 13;

// Индексы вектора состояния nativeState()
inline constexpr int S_HAS_MODEL = 0;
inline constexpr int S_SEQUENCE = 1;
inline constexpr int S_FRAME = 2;
inline constexpr int S_NUM_FRAMES = 3;
inline constexpr int S_SPEED = 4;
inline constexpr int S_PLAYING = 5;
inline constexpr int S_POLYS = 6;
inline constexpr int S_SCENE = 7;
inline constexpr int S_CAMERA = 8;
inline constexpr int S_SEQ_FPS = 9;
inline constexpr int S_LOOP_MODE = 10;
inline constexpr int S_BLEND0 = 11;
inline constexpr int S_BLEND1 = 12;
inline constexpr int S_BLEND_MODE = 13;
inline constexpr int S_SKIN = 14;
inline constexpr int S_BODY = 15;
inline constexpr int S_MODEL_REV = 16;
inline constexpr int S_EDIT_REV = 17;
inline constexpr int S_TEX_SCALE = 18;
inline constexpr int S_TEXTURE = 19;
inline constexpr int S_LIGHT_X = 20;
inline constexpr int S_LIGHT_Y = 21;
inline constexpr int S_FOV = 22;
inline constexpr int S_TOP_COLOR = 23;
inline constexpr int S_BOTTOM_COLOR = 24;
inline constexpr int S_RENDER_MODE = 25;
inline constexpr int S_OPACITY = 26;
inline constexpr int S_TEX_COUNT = 27;
inline constexpr int S_LIGHT_AMBIENT = 28;
inline constexpr int S_LIGHT_SHADE = 29;
inline constexpr int S_FPS = 30;
inline constexpr int S_COUNT = 31;

// Типы касаний nativeTouch(kind, x, y)
inline constexpr int T_ROTATE_DOWN = 0;
inline constexpr int T_ROTATE_MOVE = 1;
inline constexpr int T_ROTATE_UP = 2;
inline constexpr int T_PAN_DOWN = 3;
inline constexpr int T_PAN_MOVE = 4;
inline constexpr int T_PAN_UP = 5;
inline constexpr int T_ZOOM = 6;

// Идентификаторы цветов (CMD_SET_COLOR a = id, b = ARGB)
inline constexpr int COLOR_GROUND = 0;
inline constexpr int COLOR_BACKGROUND = 1;
inline constexpr int COLOR_CROSSHAIR = 2;
inline constexpr int COLOR_SKYLIGHT = 3;
inline constexpr int COLOR_WIREFRAME = 4;
inline constexpr int COLOR_HITBOX_EDGE = 5;
inline constexpr int COLOR_HITBOX_FACE = 6;
inline constexpr int COLOR_SINGLE_HITBOX_EDGE = 7;
inline constexpr int COLOR_SINGLE_HITBOX_FACE = 8;

// Виды внешних изображений сцены
inline constexpr int IMG_GROUND = 0;
inline constexpr int IMG_BACKGROUND = 1;

} // namespace bridge::ids
