package app.lambdaviewer

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.GestureDetector
import android.view.MotionEvent
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10

/**
 * Окно просмотра модели (аналог SceneWidget оригинала). Рисует нативное ядро через gl4es поверх контекста GLES 2.
 * Жесты: один палец — вращение (левая кнопка мыши), два пальца — перенос камеры (Shift + левая кнопка) и Pinch-to-Zoom,
 * двойное касание — возврат камеры в стандартное положение, свайп от края — выдвижные панели.
 */
class ViewerSurfaceView(context: Context) : GLSurfaceView(context) {
    var onEdgeSwipe: ((Boolean) -> Unit)? = null
    var onViewerTap: (() -> Unit)? = null
    var onViewerDoubleTap: (() -> Unit)? = null

    private var mode = MODE_NONE
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var lastDistance = 0f
    private val edgeWidth = context.dp(24)
    private val swipeThreshold = context.dp(48)

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            onViewerDoubleTap?.invoke()
            return true
        }
    })

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(FallbackConfigChooser())
        setRenderer(SceneRenderer())
        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        preserveEGLContextOnPause = true
    }

    private class SceneRenderer : GLSurfaceView.Renderer {
        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            NativeBridge.nativeSurfaceCreated()
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            NativeBridge.nativeSurfaceChanged(width, height)
        }

        override fun onDrawFrame(gl: GL10?) {
            NativeBridge.nativeDrawFrame()
        }
    }

    /** Подбирает конфигурацию EGL: нужны глубина и stencil (тени и зеркало на полу используют stencil-буфер). */
    private class FallbackConfigChooser : GLSurfaceView.EGLConfigChooser {
        override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
            val renderable = 0x3040
            val es2Bit = 4
            val specs = arrayOf(
                intArrayOf(EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_ALPHA_SIZE, 8,
                    EGL10.EGL_DEPTH_SIZE, 24, EGL10.EGL_STENCIL_SIZE, 8, renderable, es2Bit, EGL10.EGL_NONE),
                intArrayOf(EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8,
                    EGL10.EGL_DEPTH_SIZE, 16, EGL10.EGL_STENCIL_SIZE, 8, renderable, es2Bit, EGL10.EGL_NONE),
                intArrayOf(EGL10.EGL_RED_SIZE, 5, EGL10.EGL_GREEN_SIZE, 6, EGL10.EGL_BLUE_SIZE, 5,
                    EGL10.EGL_DEPTH_SIZE, 16, EGL10.EGL_STENCIL_SIZE, 8, renderable, es2Bit, EGL10.EGL_NONE),
                intArrayOf(EGL10.EGL_DEPTH_SIZE, 16, renderable, es2Bit, EGL10.EGL_NONE)
            )
            for (spec in specs) {
                val count = IntArray(1)
                if (egl.eglChooseConfig(display, spec, null, 0, count) && count[0] > 0) {
                    val configs = arrayOfNulls<EGLConfig>(count[0])
                    if (egl.eglChooseConfig(display, spec, configs, count[0], count)) {
                        val first = configs[0]
                        if (first != null) {
                            return first
                        }
                    }
                }
            }
            throw IllegalArgumentException("No suitable EGL configuration")
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        detector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x
                downY = e.y
                moved = false
                if (e.x < edgeWidth || e.x > width - edgeWidth) {
                    mode = MODE_EDGE
                } else {
                    mode = MODE_ROTATE
                    NativeBridge.nativeTouch(Ids.T_ROTATE_DOWN, e.x, e.y, 0f)
                }
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2 && mode != MODE_EDGE && mode != MODE_CONSUMED) {
                    if (mode == MODE_ROTATE) {
                        NativeBridge.nativeTouch(Ids.T_ROTATE_UP, e.getX(0), e.getY(0), 0f)
                    }
                    mode = MODE_PAN
                    lastDistance = distance(e)
                    NativeBridge.nativeTouch(Ids.T_PAN_DOWN, centerX(e), centerY(e), 0f)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (Math.abs(e.x - downX) > swipeThreshold / 4 || Math.abs(e.y - downY) > swipeThreshold / 4) {
                    moved = true
                }
                when (mode) {
                    MODE_ROTATE -> NativeBridge.nativeTouch(Ids.T_ROTATE_MOVE, e.x, e.y, 0f)
                    MODE_PAN -> if (e.pointerCount >= 2) {
                        val d = distance(e)
                        if (lastDistance > 1f && d > 1f && Math.abs(d / lastDistance - 1f) > 0.002f) {
                            NativeBridge.nativeTouch(Ids.T_ZOOM, 0f, 0f, d / lastDistance)
                            lastDistance = d
                        }
                        NativeBridge.nativeTouch(Ids.T_PAN_MOVE, centerX(e), centerY(e), 0f)
                    }
                    MODE_EDGE -> {
                        val dx = e.x - downX
                        val leftEdge = downX < edgeWidth
                        if ((leftEdge && dx > swipeThreshold) || (!leftEdge && -dx > swipeThreshold)) {
                            mode = MODE_CONSUMED
                            onEdgeSwipe?.invoke(leftEdge)
                        }
                    }
                    else -> {}
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == MODE_PAN) {
                    NativeBridge.nativeTouch(Ids.T_PAN_UP, centerX(e), centerY(e), 0f)
                    val remaining = if (e.actionIndex == 0) 1 else 0
                    if (e.pointerCount >= 2 && remaining < e.pointerCount) {
                        mode = MODE_ROTATE
                        NativeBridge.nativeTouch(Ids.T_ROTATE_DOWN, e.getX(remaining), e.getY(remaining), 0f)
                    } else {
                        mode = MODE_CONSUMED
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                when (mode) {
                    MODE_ROTATE -> NativeBridge.nativeTouch(Ids.T_ROTATE_UP, e.x, e.y, 0f)
                    MODE_PAN -> NativeBridge.nativeTouch(Ids.T_PAN_UP, e.x, e.y, 0f)
                    else -> {}
                }
                if (!moved && e.actionMasked == MotionEvent.ACTION_UP) {
                    onViewerTap?.invoke()
                }
                mode = MODE_NONE
            }
        }
        return true
    }

    private fun centerX(e: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until e.pointerCount) {
            sum += e.getX(i)
        }
        return sum / e.pointerCount
    }

    private fun centerY(e: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until e.pointerCount) {
            sum += e.getY(i)
        }
        return sum / e.pointerCount
    }

    private fun distance(e: MotionEvent): Float {
        if (e.pointerCount < 2) {
            return 0f
        }
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }

    companion object {
        private const val MODE_NONE = 0
        private const val MODE_ROTATE = 1
        private const val MODE_PAN = 2
        private const val MODE_EDGE = 3
        private const val MODE_CONSUMED = 4
    }
}
