package app.lambdaviewer

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Настройки приложения и списки каталогов/файлов. Связь с HLAM: заменяет QSettings (ApplicationSettings, RecentFiles, пути игр).
 * Последние открытые каталоги и файлы сохраняются автоматически и восстанавливаются при запуске.
 */
class Prefs(context: Context) {
    class Root(val uri: String, val name: String, val category: String)
    class Recent(val uri: String, val name: String, val tree: String, val parent: String)

    private val sp: SharedPreferences = context.getSharedPreferences("lambda_viewer", Context.MODE_PRIVATE)

    fun getInt(key: String, def: Int): Int = sp.getInt(key, def)
    fun putInt(key: String, v: Int) {
        sp.edit().putInt(key, v).apply()
    }

    fun getBool(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    fun putBool(key: String, v: Boolean) {
        sp.edit().putBoolean(key, v).apply()
    }

    fun getFloat(key: String, def: Float): Float = sp.getFloat(key, def)
    fun putFloat(key: String, v: Float) {
        sp.edit().putFloat(key, v).apply()
    }

    fun getString(key: String, def: String): String = sp.getString(key, def) ?: def
    fun putString(key: String, v: String) {
        sp.edit().putString(key, v).apply()
    }

    fun roots(): MutableList<Root> {
        val result = ArrayList<Root>()
        try {
            val array = JSONArray(getString("roots", "[]"))
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                result.add(Root(o.getString("uri"), o.getString("name"), o.getString("category")))
            }
        } catch (e: Exception) {
            // повреждённый список игнорируется
        }
        return result
    }

    fun saveRoots(list: List<Root>) {
        val array = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("uri", r.uri)
            o.put("name", r.name)
            o.put("category", r.category)
            array.put(o)
        }
        putString("roots", array.toString())
    }

    fun recents(): MutableList<Recent> {
        val result = ArrayList<Recent>()
        try {
            val array = JSONArray(getString("recents", "[]"))
            for (i in 0 until array.length()) {
                val o = array.getJSONObject(i)
                result.add(Recent(o.getString("uri"), o.getString("name"), o.optString("tree", ""), o.optString("parent", "")))
            }
        } catch (e: Exception) {
            // повреждённый список игнорируется
        }
        return result
    }

    fun addRecent(uri: String, name: String, tree: String, parent: String) {
        val list = recents()
        list.removeAll { it.uri == uri }
        list.add(0, Recent(uri, name, tree, parent))
        while (list.size > 15) {
            list.removeAt(list.size - 1)
        }
        val array = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("uri", r.uri)
            o.put("name", r.name)
            o.put("tree", r.tree)
            o.put("parent", r.parent)
            array.put(o)
        }
        putString("recents", array.toString())
    }

    fun clearRecents() {
        putString("recents", "[]")
    }
}
