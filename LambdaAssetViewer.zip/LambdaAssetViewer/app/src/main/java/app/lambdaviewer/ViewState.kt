package app.lambdaviewer

import android.graphics.Color

/**
 * Состояние режимов отображения, которое сохраняется между запусками и повторно применяется к каждой новой модели
 * (в оригинале эти флаги жили в StudioModelAsset и переключались чекбоксами ModelDisplayPanel/панелей объектов).
 */
class ViewState(private val prefs: Prefs) {
    private val sceneFlags: IntArray = intArrayOf(
        Ids.FLAG_HITBOXES, Ids.FLAG_BONES, Ids.FLAG_ATTACHMENTS, Ids.FLAG_EYE, Ids.FLAG_BBOX, Ids.FLAG_CBOX,
        Ids.FLAG_BACKFACE, Ids.FLAG_WIREFRAME_OVERLAY, Ids.FLAG_SHADOWS, Ids.FLAG_SHADOW_FIX, Ids.FLAG_AXES,
        Ids.FLAG_NORMALS, Ids.FLAG_PLAYER_HITBOX, Ids.FLAG_MIRROR_X, Ids.FLAG_MIRROR_Y, Ids.FLAG_MIRROR_Z,
        Ids.FLAG_CROSSHAIR, Ids.FLAG_GUIDELINES, Ids.FLAG_OFFSCREEN, Ids.FLAG_GROUND, Ids.FLAG_GROUND_MIRROR,
        Ids.FLAG_GROUND_TEXTURE, Ids.FLAG_GROUND_TILING, Ids.FLAG_BACKGROUND, Ids.FLAG_UV_SHOW, Ids.FLAG_UV_OVERLAY,
        Ids.FLAG_UV_AA
    )
    private val optionFlags: IntArray = intArrayOf(
        Ids.FLAG_SOUNDS, Ids.FLAG_SOUND_PITCH, Ids.FLAG_INVERT_X, Ids.FLAG_INVERT_Y, Ids.FLAG_POW2, Ids.FLAG_LIGHT_EDIT
    )
    val colorIds: IntArray = intArrayOf(
        Ids.COLOR_GROUND, Ids.COLOR_BACKGROUND, Ids.COLOR_CROSSHAIR, Ids.COLOR_SKYLIGHT, Ids.COLOR_WIREFRAME,
        Ids.COLOR_HITBOX_EDGE, Ids.COLOR_HITBOX_FACE, Ids.COLOR_SINGLE_HITBOX_EDGE, Ids.COLOR_SINGLE_HITBOX_FACE
    )

    private fun default(id: Int): Boolean = id == Ids.FLAG_BACKFACE || id == Ids.FLAG_SOUNDS || id == Ids.FLAG_UV_SHOW || id == Ids.FLAG_UV_AA

    fun flag(id: Int): Boolean = prefs.getBool("flag_$id", default(id))

    fun setFlag(id: Int, value: Boolean) {
        prefs.putBool("flag_$id", value)
        // Взаимосвязи как в панели пола оригинала: зеркало и текстура требуют видимого пола, скрытие пола выключает зеркало.
        if ((id == Ids.FLAG_GROUND_MIRROR || id == Ids.FLAG_GROUND_TEXTURE) && value) {
            prefs.putBool("flag_" + Ids.FLAG_GROUND, true)
        }
        if (id == Ids.FLAG_GROUND && !value) {
            prefs.putBool("flag_" + Ids.FLAG_GROUND_MIRROR, false)
        }
        NativeBridge.command(Ids.CMD_SET_FLAG, id, if (value) 1 else 0)
    }

    var renderMode: Int
        get() = prefs.getInt("render_mode", 3)
        set(value) {
            prefs.putInt("render_mode", value)
            NativeBridge.command(Ids.CMD_SET_RENDER_MODE, value)
        }

    var opacity: Float
        get() = prefs.getFloat("opacity", 1f)
        set(value) {
            prefs.putFloat("opacity", value)
            NativeBridge.command(Ids.CMD_SET_OPACITY, 0, 0, value)
        }

    fun colorOverride(id: Int): Int = prefs.getInt("color_$id", 0)

    fun setColor(id: Int, argb: Int) {
        prefs.putInt("color_$id", argb)
        NativeBridge.command(Ids.CMD_SET_COLOR, id, argb)
    }

    fun resetColors() {
        for (id in colorIds) {
            prefs.putInt("color_$id", 0)
        }
        NativeBridge.command(Ids.CMD_RESET_COLORS)
    }

    /** Применяется один раз при запуске: параметры сессии (мышь, звук, фильтры, цвета). */
    fun applyOptions() {
        for (id in optionFlags) {
            NativeBridge.command(Ids.CMD_SET_FLAG, id, if (flag(id)) 1 else 0)
        }
        NativeBridge.command(Ids.CMD_SET_MOUSE_SENS, prefs.getInt("mouse_sens", 5))
        NativeBridge.command(Ids.CMD_SET_WHEEL_SPEED, prefs.getInt("wheel_speed", 5))
        NativeBridge.command(Ids.CMD_SET_TEX_FILTER, prefs.getInt("min_filter", 1), prefs.getInt("mag_filter", 1), prefs.getInt("mip_filter", 0).toFloat())
        NativeBridge.command(Ids.CMD_SET_AUTODETECT_VIEWMODEL, if (prefs.getBool("autodetect_vm", true)) 1 else 0)
        NativeBridge.command(Ids.CMD_SET_GROUND_LENGTH, prefs.getInt("ground_length", 100))
        NativeBridge.command(Ids.CMD_SET_ASPECT, prefs.getInt("aspect_x", 16), prefs.getInt("aspect_y", 9))
        for (id in colorIds) {
            val argb = colorOverride(id)
            if (argb != 0) {
                NativeBridge.command(Ids.CMD_SET_COLOR, id, argb)
            }
        }
    }

    /** Применяется к каждой новой модели: флаги сцены, режим рендера и прозрачность. */
    fun applyScene() {
        for (id in sceneFlags) {
            NativeBridge.command(Ids.CMD_SET_FLAG, id, if (flag(id)) 1 else 0)
        }
        NativeBridge.command(Ids.CMD_SET_RENDER_MODE, renderMode)
        NativeBridge.command(Ids.CMD_SET_OPACITY, 0, 0, opacity)
        NativeBridge.command(Ids.CMD_SET_GROUND_TEXTURE_LENGTH, prefs.getInt("ground_tile", 128))
    }

    fun swatchColor(argb: Int): Int = Color.argb(255, Color.red(argb), Color.green(argb), Color.blue(argb))
}
