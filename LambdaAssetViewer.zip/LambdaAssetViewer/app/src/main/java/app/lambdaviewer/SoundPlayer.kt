package app.lambdaviewer

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Воспроизведение звуковых событий анимаций (ISoundSystem оригинала). Нативное ядро вызывает play() из GL-потока,
 * файл ищется в сохранённых каталогах игр: <корень>/sound/<имя>, <корень>/<имя>, <корень>/<мод>/sound/<имя>.
 */
class SoundPlayer(private val ctx: Context, private val prefs: Prefs) : SoundCallback {
    private val pool: SoundPool
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val ids = HashMap<String, Int>()
    private val missing = HashSet<String>()
    private val ready = HashSet<Int>()
    private val pending = HashMap<Int, FloatArray>()

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build()
        pool.setOnLoadCompleteListener { _, sampleId, status -> onLoaded(sampleId, status) }
    }

    override fun play(name: String, volume: Float, pitch: Int) {
        val rate = (pitch / 100f).coerceIn(0.5f, 2f)
        val vol = volume.coerceIn(0f, 1f)
        executor.execute { playInternal(name, vol, rate) }
    }

    fun release() {
        executor.shutdownNow()
        pool.release()
    }

    private fun playInternal(name: String, volume: Float, rate: Float) {
        synchronized(ids) {
            val id = ids[name]
            if (id != null) {
                if (ready.contains(id)) {
                    pool.play(id, volume, volume, 1, 0, rate)
                } else {
                    pending[id] = floatArrayOf(volume, rate)
                }
                return
            }
            if (missing.contains(name)) {
                return
            }
        }
        val bytes = findSound(name)
        if (bytes == null) {
            synchronized(ids) { missing.add(name) }
            return
        }
        try {
            val file = File(ctx.cacheDir, "snd_" + name.hashCode() + ".wav")
            file.writeBytes(bytes)
            val id = pool.load(file.absolutePath, 1)
            synchronized(ids) {
                ids[name] = id
                pending[id] = floatArrayOf(volume, rate)
            }
        } catch (e: Exception) {
            synchronized(ids) { missing.add(name) }
        }
    }

    private fun onLoaded(sampleId: Int, status: Int) {
        synchronized(ids) {
            if (status == 0) {
                ready.add(sampleId)
                val p = pending.remove(sampleId)
                if (p != null) {
                    pool.play(sampleId, p[0], p[0], 1, 0, p[1])
                }
            }
        }
    }

    private fun resolve(tree: Uri, rootId: String, path: String): Saf.Entry? {
        var current = rootId
        var entry: Saf.Entry? = null
        for (part in path.split('/')) {
            if (part.isEmpty()) {
                continue
            }
            val found = Saf.findChild(ctx, tree, current, part) ?: return null
            entry = found
            current = found.docId
        }
        return entry
    }

    private fun findSound(rawName: String): ByteArray? {
        val name = rawName.trimStart('*', '#', '!', '^', '@').replace('\\', '/')
        for (root in prefs.roots()) {
            val tree = Uri.parse(root.uri)
            val rootId = Saf.treeRootDocId(tree)
            val direct = resolve(tree, rootId, "sound/$name") ?: resolve(tree, rootId, name)
            if (direct != null && !direct.isDir) {
                return Saf.readBytes(ctx, direct.uri)
            }
            var checked = 0
            for (child in Saf.listChildren(ctx, tree, rootId)) {
                if (!child.isDir || checked >= 12) {
                    continue
                }
                checked++
                val inMod = resolve(tree, child.docId, "sound/$name")
                if (inMod != null && !inMod.isDir) {
                    return Saf.readBytes(ctx, inMod.uri)
                }
            }
        }
        return null
    }
}
