package app.lambdaviewer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream

/**
 * Декодирование и кодирование растровых форматов на стороне Android (PNG/JPG через Bitmap, TGA — собственный разбор).
 * Связь с HLAM: заменяет QImage/QImageReader из StudioModelTextureUtilities. BMP с палитрой обрабатывается в C++ (ImageCodec).
 */
object ImageIo {
    class Decoded(val width: Int, val height: Int, val argb: IntArray)

    fun decode(name: String, bytes: ByteArray): Decoded? {
        if (name.lowercase().endsWith(".tga")) {
            // Основной декодер TGA — C++ (ImageCodec), Kotlin-вариант служит запасным.
            val packed = NativeBridge.nativeDecodeImage(bytes)
            if (packed != null && packed.size > 2) {
                val w = packed[0]
                val h = packed[1]
                if (w > 0 && h > 0 && packed.size >= 2 + w * h) {
                    return Decoded(w, h, packed.copyOfRange(2, 2 + w * h))
                }
            }
            return Tga.decode(bytes)
        }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()
        return Decoded(w, h, px)
    }

    fun encodePng(width: Int, height: Int, argb: IntArray): ByteArray {
        val bmp = Bitmap.createBitmap(argb, width, height, Bitmap.Config.ARGB_8888)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        bmp.recycle()
        return out.toByteArray()
    }
}

/** Разбор TGA: типы 1/2/3 и их RLE-варианты 9/10/11, глубина 8/15/16/24/32 бит. */
object Tga {
    private fun u8(d: ByteArray, i: Int): Int = d[i].toInt() and 0xFF
    private fun u16(d: ByteArray, i: Int): Int = u8(d, i) or (u8(d, i + 1) shl 8)

    fun decode(d: ByteArray): ImageIo.Decoded? {
        if (d.size < 18) {
            return null
        }
        val idLen = u8(d, 0)
        val colorMapType = u8(d, 1)
        val imageType = u8(d, 2)
        val mapStart = u16(d, 3)
        val mapLen = u16(d, 5)
        val mapBits = u8(d, 7)
        val w = u16(d, 12)
        val h = u16(d, 14)
        val bpp = u8(d, 16)
        val desc = u8(d, 17)
        if (w <= 0 || h <= 0 || w > 16384 || h > 16384) {
            return null
        }
        val rle = imageType == 9 || imageType == 10 || imageType == 11
        val base = imageType and 7
        if (base != 1 && base != 2 && base != 3) {
            return null
        }
        val pixelBytes = (bpp + 7) / 8
        if (pixelBytes < 1 || pixelBytes > 4) {
            return null
        }

        var pos = 18 + idLen
        val palette = IntArray(256)
        if (colorMapType == 1) {
            val entryBytes = (mapBits + 7) / 8
            for (i in 0 until mapLen) {
                val p = pos + i * entryBytes
                if (p + entryBytes > d.size) {
                    return null
                }
                if (mapStart + i < 256) {
                    palette[mapStart + i] = convert(d, p, entryBytes, mapBits)
                }
            }
            pos += mapLen * entryBytes
        }

        val raw = ByteArray(w * h * pixelBytes)
        if (!rle) {
            if (pos + raw.size > d.size) {
                return null
            }
            System.arraycopy(d, pos, raw, 0, raw.size)
        } else {
            var out = 0
            while (out < raw.size) {
                if (pos >= d.size) {
                    return null
                }
                val header = u8(d, pos++)
                val count = (header and 0x7F) + 1
                if ((header and 0x80) != 0) {
                    if (pos + pixelBytes > d.size) {
                        return null
                    }
                    for (n in 0 until count) {
                        if (out + pixelBytes > raw.size) {
                            break
                        }
                        System.arraycopy(d, pos, raw, out, pixelBytes)
                        out += pixelBytes
                    }
                    pos += pixelBytes
                } else {
                    val bytes = count * pixelBytes
                    if (pos + bytes > d.size) {
                        return null
                    }
                    val take = Math.min(bytes, raw.size - out)
                    System.arraycopy(d, pos, raw, out, take)
                    out += take
                    pos += bytes
                }
            }
        }

        val argb = IntArray(w * h)
        val topToBottom = (desc and 0x20) != 0
        val rightToLeft = (desc and 0x10) != 0
        for (row in 0 until h) {
            val y = if (topToBottom) row else h - 1 - row
            for (col in 0 until w) {
                val x = if (rightToLeft) w - 1 - col else col
                val p = (row * w + col) * pixelBytes
                val value = if (base == 1) {
                    palette[u8(raw, p) and 0xFF]
                } else if (base == 3) {
                    val g = u8(raw, p)
                    val a = if (pixelBytes > 1) u8(raw, p + 1) else 255
                    (a shl 24) or (g shl 16) or (g shl 8) or g
                } else {
                    convert(raw, p, pixelBytes, bpp)
                }
                argb[y * w + x] = value
            }
        }
        return ImageIo.Decoded(w, h, argb)
    }

    private fun convert(d: ByteArray, p: Int, bytes: Int, bits: Int): Int {
        return when (bytes) {
            2 -> {
                val v = u16(d, p)
                val r = ((v shr 10) and 31) * 255 / 31
                val g = ((v shr 5) and 31) * 255 / 31
                val b = (v and 31) * 255 / 31
                (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            3 -> (0xFF shl 24) or (u8(d, p + 2) shl 16) or (u8(d, p + 1) shl 8) or u8(d, p)
            4 -> {
                val a = if (bits == 32) u8(d, p + 3) else 255
                (a shl 24) or (u8(d, p + 2) shl 16) or (u8(d, p + 1) shl 8) or u8(d, p)
            }
            else -> 0xFF000000.toInt()
        }
    }
}
