package app.lambdaviewer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.PixelCopy
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/**
 * Главное окно (горизонтальная ориентация). Собирает интерфейс: верхняя панель, окно просмотра модели, панель воспроизведения,
 * выдвижные панели файлов (слева) и свойств (справа); отвечает за работу с Storage Access Framework (открытие, сохранение,
 * экспорт и импорт текстур) и за связь с нативным ядром, перенесённым из Half-Life Asset Manager.
 */
class MainActivity : Activity(), FilePanel.Host, PropertiesPanel.Host {
    private lateinit var prefs: Prefs
    private lateinit var viewState: ViewState
    private lateinit var surface: ViewerSurfaceView
    private lateinit var playback: PlaybackBar
    private lateinit var filePanel: FilePanel
    private lateinit var propsPanel: PropertiesPanel
    private lateinit var leftSlide: SlidePanel
    private lateinit var rightSlide: SlidePanel
    private lateinit var sequenceButton: TextView
    private lateinit var textureBar: LinearLayout
    private lateinit var textureLabel: TextView
    private lateinit var emptyView: LinearLayout
    private lateinit var busyView: TextView
    private lateinit var textureToggle: IconButton
    private lateinit var saveButton: IconButton
    private var lastSequence = 0
    private lateinit var sound: SoundPlayer

    private val handler = Handler(Looper.getMainLooper())
    private val state = FloatArray(Ids.S_COUNT)

    private var lastModelRev = -1f
    private var lastEditRev = -1f
    private var savedEditRev = 0f
    private var hasModel = false
    private var sequenceNames: List<String> = emptyList()
    private var textureNames: List<String> = emptyList()
    private var textureIndex = 0

    private var currentUri: Uri? = null
    private var currentName = ""
    private var currentTree: Uri? = null
    private var currentParentDoc: String? = null

    private var pendingCategory = "Custom"
    private var pendingTextureIndex = 0
    private var pendingExportPng = true
    private var pendingSceneKind = 0
    private var pendingImageEntry: Saf.Entry? = null
    private var pendingTextureBytes: ByteArray? = null
    private var pendingScreenshot: Bitmap? = null

    private val poll = object : Runnable {
        override fun run() {
            NativeBridge.nativeState(state)
            onState()
            handler.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = Prefs(this)
        viewState = ViewState(prefs)
        sound = SoundPlayer(this, prefs)
        buildUi()
        NativeBridge.nativeSetSoundCallback(sound)
        viewState.applyOptions()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        surface.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        surface.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        NativeBridge.nativeSetSoundCallback(null)
        sound.release()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (rightSlide.isOpen || leftSlide.isOpen) {
            closePanels()
        } else if (state[Ids.S_SCENE].toInt() == 1) {
            NativeBridge.command(Ids.CMD_SET_SCENE, 0)
        } else {
            super.onBackPressed()
        }
    }

    // ---------------------------------------------------------------------------------------------------- интерфейс

    private fun buildUi() {
        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)

        val column = vbox()
        column.add(buildTopBar(), MATCH, dp(48))

        val viewerBox = FrameLayout(this)
        surface = ViewerSurfaceView(this)
        viewerBox.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH))
        textureBar = buildTextureBar()
        textureBar.visibility = View.GONE
        viewerBox.addView(textureBar, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        emptyView = vbox()
        emptyView.gravity = Gravity.CENTER_HORIZONTAL
        val emptyTitle = label("Open a model to start", 16f, Ui.TEXT, true)
        emptyTitle.gravity = Gravity.CENTER
        emptyView.add(emptyTitle)
        val emptyHint = label("or swipe from the left edge to browse files", 12f, Ui.TEXT_DIM)
        emptyHint.gravity = Gravity.CENTER
        emptyHint.setPadding(0, dp(4), 0, dp(14))
        emptyView.add(emptyHint)
        emptyView.add(textButton("Open file", true) { openFiles() }, WRAP, WRAP)
        viewerBox.addView(emptyView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))

        busyView = label("", 14f, Ui.TEXT, true)
        busyView.setPadding(dp(20), dp(12), dp(20), dp(12))
        busyView.background = roundRect(0xE6262A31.toInt(), dpf(10f))
        busyView.visibility = View.GONE
        viewerBox.addView(busyView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        column.add(viewerBox, MATCH, 0, 1f)

        playback = PlaybackBar(this)
        column.add(playback, MATCH, dp(48))
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        val screenWidth = resources.displayMetrics.widthPixels
        val leftWidth = Math.min(dp(320), screenWidth / 2)
        val rightWidth = Math.min(dp(360), screenWidth * 11 / 20)

        filePanel = FilePanel(this, prefs, this)
        leftSlide = SlidePanel(this, filePanel, true, leftWidth)
        root.addView(leftSlide, FrameLayout.LayoutParams(leftWidth, MATCH, Gravity.START))

        propsPanel = PropertiesPanel(this, prefs, viewState, this)
        rightSlide = SlidePanel(this, propsPanel, false, rightWidth)
        root.addView(rightSlide, FrameLayout.LayoutParams(rightWidth, MATCH, Gravity.END))

        surface.onEdgeSwipe = { left -> if (left) openLeft() else openRight() }
        surface.onViewerTap = { closePanels() }
        surface.onViewerDoubleTap = { NativeBridge.command(Ids.CMD_CAM_RESET) }

        setContentView(root)
    }

    /** Верхняя панель: файлы, открыть, сохранить, выбор последовательности, текстуры, меню отображения, сброс камеры, свойства. */
    private fun buildTopBar(): View {
        val bar = hbox()
        bar.setBackgroundColor(Ui.BAR)
        bar.setPadding(dp(4), 0, dp(4), 0)

        bar.add(IconButton(this, Icon.MENU, null, false) { toggleLeft() }, WRAP, MATCH)
        bar.add(IconButton(this, Icon.FOLDER, null, false) { openFiles() }, WRAP, MATCH)
        saveButton = IconButton(this, Icon.SAVE, null, false) { save() }
        saveButton.setOnLongClickListener {
            saveAs()
            true
        }
        bar.add(saveButton, WRAP, MATCH)

        sequenceButton = dropdownButton({ sequenceNames }, { state[Ids.S_SEQUENCE].toInt() }, { idx ->
            NativeBridge.command(Ids.CMD_SET_SEQUENCE, idx)
            if (rightSlide.isOpen && propsPanel.tab == PropertiesPanel.TAB_ANIMATION) {
                propsPanel.refresh()
            }
        })
        sequenceButton.text = "No model  \u25BE"
        val seqLp = LinearLayout.LayoutParams(0, dp(40), 1f)
        seqLp.setMargins(dp(8), 0, dp(8), 0)
        bar.addView(sequenceButton, seqLp)

        textureToggle = IconButton(this, Icon.TEXTURE, null, true) { b ->
            if (b.checked) enterTextureView(textureIndex) else NativeBridge.command(Ids.CMD_SET_SCENE, 0)
        }
        bar.add(textureToggle, WRAP, MATCH)
        bar.add(IconButton(this, Icon.EYE, null, false) { b -> showViewMenu(b) }, WRAP, MATCH)
        bar.add(IconButton(this, Icon.TARGET, null, false) { NativeBridge.command(Ids.CMD_CAM_RESET) }, WRAP, MATCH)
        bar.add(IconButton(this, Icon.PANEL, null, false) { toggleRight() }, WRAP, MATCH)
        return bar
    }

    /** Быстрое меню отображения: самые частые переключатели в две колонки. Остальное — вкладка View. */
    private fun showViewMenu(anchor: View) {
        val columns = hbox()
        columns.gravity = Gravity.TOP
        columns.setPadding(dp(8), dp(8), dp(8), dp(8))
        val left = vbox()
        val right = vbox()
        columns.add(left, dp(172), WRAP)
        columns.add(right, dp(172), WRAP)
        val entries = listOf(
            Pair("Wireframe", Ids.FLAG_WIREFRAME_OVERLAY), Pair("Hitboxes", Ids.FLAG_HITBOXES),
            Pair("Bones", Ids.FLAG_BONES), Pair("Attachments", Ids.FLAG_ATTACHMENTS),
            Pair("Normals", Ids.FLAG_NORMALS), Pair("Eye position", Ids.FLAG_EYE),
            Pair("Bounding box", Ids.FLAG_BBOX), Pair("Axes", Ids.FLAG_AXES),
            Pair("Ground", Ids.FLAG_GROUND)
        )
        var index = 0
        for (entry in entries) {
            val flag = entry.second
            val column = if (index % 2 == 0) left else right
            index++
            column.add(switchRow(entry.first, viewState.flag(flag)) { on ->
                viewState.setFlag(flag, on)
                if (rightSlide.isOpen) {
                    propsPanel.refresh()
                }
            }, MATCH, WRAP)
        }
        val skeleton = switchRow("Skeleton pose", hasModel && state[Ids.S_SEQUENCE].toInt() < 0) { on -> setSkeletonPose(on) }
        (if (index % 2 == 0) left else right).add(skeleton, MATCH, WRAP)

        val holder = arrayOfNulls<PopupWindow>(1)
        val content = vbox()
        content.add(columns, WRAP, WRAP)
        content.add(textButton("Screenshot") {
            holder[0]?.dismiss()
            screenshot()
        }, MATCH, WRAP)
        val popup = PopupWindow(content, WRAP, WRAP, true)
        holder[0] = popup
        popup.setBackgroundDrawable(roundRect(Ui.CARD, dpf(12f)))
        popup.isOutsideTouchable = true
        popup.elevation = dpf(10f)
        popup.showAsDropDown(anchor, 0, 0, Gravity.END)
    }

    private fun buildTextureBar(): LinearLayout {
        val bar = hbox()
        bar.setBackgroundColor(0xCC15171B.toInt())
        bar.setPadding(dp(6), 0, dp(6), 0)
        bar.add(IconButton(this, Icon.BACK, null, false) { NativeBridge.command(Ids.CMD_SET_SCENE, 0) })
        bar.add(IconButton(this, Icon.PREV, null, false) { stepTexture(-1) })
        textureLabel = label("", 13f, Ui.TEXT, true)
        textureLabel.gravity = Gravity.CENTER
        textureLabel.setSingleLine(true)
        bar.add(textureLabel, 0, WRAP, 1f)
        bar.add(IconButton(this, Icon.NEXT, null, false) { stepTexture(1) })
        bar.add(IconButton(this, Icon.EXPORT, null, false) { b ->
            showDropdown(b, listOf("Export PNG", "Export BMP"), 0) { idx -> exportTexture(textureIndex, idx == 0) }
        })
        bar.add(IconButton(this, Icon.IMPORT, null, false) { importTexture(textureIndex) })
        return bar
    }

    private fun openLeft() {
        rightSlide.close()
        leftSlide.open()
    }

    private fun openRight() {
        leftSlide.close()
        rightSlide.open()
    }

    private fun toggleLeft() {
        if (leftSlide.isOpen) leftSlide.close() else openLeft()
    }

    private fun toggleRight() {
        if (rightSlide.isOpen) rightSlide.close() else openRight()
    }

    private fun closePanels() {
        leftSlide.close()
        rightSlide.close()
    }

    private fun showBusy(text: String) {
        busyView.text = text
        busyView.visibility = View.VISIBLE
    }

    private fun hideBusy() {
        busyView.visibility = View.GONE
    }

    private fun showMessage(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------------------------------------------- состояние

    private fun onState() {
        val has = state[Ids.S_HAS_MODEL] > 0.5f
        val modelRev = state[Ids.S_MODEL_REV]
        val editRev = state[Ids.S_EDIT_REV]
        if (modelRev != lastModelRev) {
            lastModelRev = modelRev
            lastEditRev = editRev
            onModelChanged(has)
        } else if (editRev != lastEditRev) {
            lastEditRev = editRev
            reloadNames()
            if (rightSlide.isOpen) {
                propsPanel.refresh()
            }
        }
        playback.update(state)

        val current = state[Ids.S_SEQUENCE].toInt()
        val name = if (!has) "No model" else if (current >= 0 && current < sequenceNames.size) sequenceNames[current] else "Skeleton pose"
        sequenceButton.setTextIfChanged(name + "  \u25BE")

        val scene = state[Ids.S_SCENE].toInt()
        textureBar.visibility = if (has && scene == 1) View.VISIBLE else View.GONE
        textureToggle.checked = has && scene == 1
        saveButton.checked = has && editRev > savedEditRev
        emptyView.visibility = if (has) View.GONE else View.VISIBLE
        if (has && scene == 1) {
            updateTextureLabel()
        }
    }

    private fun onModelChanged(has: Boolean) {
        hasModel = has
        propsPanel.hasModel = has
        propsPanel.resetSelections()
        textureIndex = 0
        if (has) {
            viewState.applyScene()
            savedEditRev = state[Ids.S_EDIT_REV]
            NativeBridge.command(Ids.CMD_SET_SCENE, 0)
            propsPanel.selectTab(PropertiesPanel.TAB_MODEL)
        } else {
            currentUri = null
            currentName = ""
            propsPanel.refresh()
        }
        reloadNames()
    }

    private fun reloadNames() {
        if (!hasModel) {
            sequenceNames = emptyList()
            textureNames = emptyList()
            return
        }
        try {
            val array = JSONArray(NativeBridge.query(Ids.Q_SEQUENCES))
            val names = ArrayList<String>()
            for (i in 0 until array.length()) {
                names.add(array.getJSONObject(i).getString("name"))
            }
            sequenceNames = names
        } catch (e: Exception) {
            sequenceNames = emptyList()
        }
        try {
            val array = JSONObject(NativeBridge.query(Ids.Q_TEXTURES)).getJSONArray("textures")
            val names = ArrayList<String>()
            for (i in 0 until array.length()) {
                names.add(array.getJSONObject(i).getString("name"))
            }
            textureNames = names
        } catch (e: Exception) {
            textureNames = emptyList()
        }
    }

    private fun updateTextureLabel() {
        val info = IntArray(3)
        if (NativeBridge.nativeTextureInfo(textureIndex, info)) {
            val name = if (textureIndex < textureNames.size) textureNames[textureIndex] else "texture"
            textureLabel.setTextIfChanged(name + "   " + info[0] + " x " + info[1] + "   (" + (textureIndex + 1) + "/" + textureNames.size + ")")
        } else {
            textureLabel.text = "No texture"
        }
    }

    private fun enterTextureView(index: Int) {
        if (!hasModel || textureNames.isEmpty()) {
            showMessage("The model has no textures")
            textureToggle.checked = false
            return
        }
        textureIndex = index.coerceIn(0, textureNames.size - 1)
        NativeBridge.command(Ids.CMD_SET_SCENE, 1)
        NativeBridge.command(Ids.CMD_TEX_SELECT, textureIndex, -1)
        propsPanel.selectedTexture = textureIndex
        updateTextureLabel()
    }

    private fun stepTexture(delta: Int) {
        if (textureNames.isEmpty()) {
            return
        }
        val count = textureNames.size
        enterTextureView((textureIndex + delta + count) % count)
        if (rightSlide.isOpen && propsPanel.tab == PropertiesPanel.TAB_TEXTURES) {
            propsPanel.refresh()
        }
    }

    // ---------------------------------------------------------------------------------------------------- открытие файлов

    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_VIEW) {
            return
        }
        val data = i.data ?: return
        val name = Saf.displayName(this, data)
        loadModel(data, name, SiblingResolver(this, null, null, emptyMap()), null, null)
    }

    private fun loadModel(uri: Uri, name: String, resolver: SiblingProvider, tree: Uri?, parentDoc: String?) {
        showBusy("Loading " + name + "...")
        val ctx = this
        Thread {
            val bytes = Saf.readBytes(ctx, uri)
            if (bytes == null) {
                runOnUiThread {
                    hideBusy()
                    showMessage("Cannot read " + name)
                }
                return@Thread
            }
            val json = NativeBridge.nativeLoadModel(name, bytes, resolver)
            runOnUiThread { onLoadResult(json, uri, name, tree, parentDoc) }
        }.start()
    }

    private fun onLoadResult(json: String, uri: Uri, name: String, tree: Uri?, parentDoc: String?) {
        hideBusy()
        var ok = false
        var error = "Unknown error"
        try {
            val o = JSONObject(json)
            ok = o.getBoolean("ok")
            if (!ok) {
                error = o.optString("error", error)
            }
        } catch (e: Exception) {
            error = "Invalid response from the native core"
        }
        if (!ok) {
            AlertDialog.Builder(this)
                .setTitle("Cannot open " + name)
                .setMessage(error + "\n\nIf the model uses external files (NNT.mdl textures or NN01.mdl animations), open it from the file browser panel so the neighbouring files can be found.")
                .setPositiveButton(android.R.string.ok, null)
                .show()
            return
        }
        currentUri = uri
        currentName = name
        currentTree = tree
        currentParentDoc = parentDoc
        prefs.addRecent(uri.toString(), name, tree?.toString() ?: "", parentDoc ?: "")
        filePanel.showRoots()
        leftSlide.close()
    }

    override fun openFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i, REQ_OPEN_FILES)
    }

    override fun addRoot(category: String) {
        pendingCategory = category
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
        startActivityForResult(i, REQ_ADD_ROOT)
    }

    override fun openModel(entry: Saf.Entry, tree: Uri, parentDocId: String) {
        loadModel(entry.uri, entry.name, SiblingResolver(this, tree, parentDocId, emptyMap()), tree, parentDocId)
    }

    override fun openRecent(recent: Prefs.Recent) {
        val tree = if (recent.tree.isEmpty()) null else Uri.parse(recent.tree)
        val parent = if (recent.parent.isEmpty()) null else recent.parent
        loadModel(Uri.parse(recent.uri), recent.name, SiblingResolver(this, tree, parent, emptyMap()), tree, parent)
    }

    override fun openImage(entry: Saf.Entry) {
        pendingImageEntry = entry
        val options = arrayOf("Use as ground texture", "Use as background texture", "Replace a model texture")
        AlertDialog.Builder(this)
            .setTitle(entry.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> applySceneImage(entry.uri, entry.name, Ids.IMG_GROUND)
                    1 -> applySceneImage(entry.uri, entry.name, Ids.IMG_BACKGROUND)
                    else -> chooseTextureForImport(entry)
                }
            }
            .show()
    }

    private fun chooseTextureForImport(entry: Saf.Entry) {
        if (!hasModel || textureNames.isEmpty()) {
            showMessage("Open a model with textures first")
            return
        }
        val names = textureNames.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Replace texture")
            .setItems(names) { _, which -> importTextureFrom(entry.uri, entry.name, which) }
            .show()
    }

    private fun takePermission(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (e: Exception) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e2: Exception) {
                // разрешение действует только в текущем сеансе
            }
        }
    }

    private fun isCompanion(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith("t.mdl") && n.length > 5 || Regex(".*\\d\\d\\.mdl").matches(n)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) {
            if (requestCode == REQ_SCREENSHOT) {
                pendingScreenshot?.recycle()
                pendingScreenshot = null
            }
            return
        }
        when (requestCode) {
            REQ_OPEN_FILES -> onFilesPicked(data)
            REQ_ADD_ROOT -> {
                val uri = data.data ?: return
                takePermission(uri)
                val docUri = DocumentsContract.buildDocumentUriUsingTree(uri, Saf.treeRootDocId(uri))
                val roots = prefs.roots()
                roots.removeAll { it.uri == uri.toString() }
                roots.add(Prefs.Root(uri.toString(), Saf.displayName(this, docUri), pendingCategory))
                prefs.saveRoots(roots)
                filePanel.showRoots()
            }
            REQ_EXPORT -> {
                val uri = data.data ?: return
                writeTextureExport(uri)
            }
            REQ_IMPORT -> {
                val uri = data.data ?: return
                importTextureFrom(uri, Saf.displayName(this, uri), pendingTextureIndex)
            }
            REQ_SCENE_IMAGE -> {
                val uri = data.data ?: return
                applySceneImage(uri, Saf.displayName(this, uri), pendingSceneKind)
            }
            REQ_SAVE_AS -> {
                val uri = data.data ?: return
                currentUri = uri
                currentName = Saf.displayName(this, uri)
                currentTree = null
                currentParentDoc = null
                doSave(uri)
            }
            REQ_SAVE_TEXTURE_FILE -> {
                val uri = data.data ?: return
                val bytes = pendingTextureBytes
                pendingTextureBytes = null
                if (bytes != null) {
                    Thread {
                        val ok = Saf.writeBytes(this, uri, bytes)
                        runOnUiThread { showMessage(if (ok) "Texture file saved" else "Cannot write the texture file") }
                    }.start()
                }
            }
            REQ_SCREENSHOT -> {
                val uri = data.data ?: return
                val bitmap = pendingScreenshot ?: return
                pendingScreenshot = null
                Thread {
                    var ok = false
                    try {
                        val out = contentResolver.openOutputStream(uri, "wt")
                        if (out != null) {
                            out.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            ok = true
                        }
                    } catch (e: Exception) {
                        ok = false
                    }
                    bitmap.recycle()
                    runOnUiThread { showMessage(if (ok) "Screenshot saved" else "Cannot save the screenshot") }
                }.start()
            }
        }
    }

    private fun onFilesPicked(data: Intent) {
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                uris.add(clip.getItemAt(i).uri)
            }
        } else {
            val single = data.data
            if (single != null) {
                uris.add(single)
            }
        }
        val names = HashMap<String, Uri>()
        var main: Uri? = null
        var mainName = ""
        var image: Uri? = null
        var imageName = ""
        for (u in uris) {
            takePermission(u)
            val n = Saf.displayName(this, u)
            names[n.lowercase()] = u
            val lower = n.lowercase()
            if (lower.endsWith(".mdl")) {
                if (main == null || (isCompanion(mainName) && !isCompanion(n))) {
                    main = u
                    mainName = n
                }
            } else if (image == null) {
                image = u
                imageName = n
            }
        }
        if (main != null) {
            loadModel(main, mainName, SiblingResolver(this, null, null, names), null, null)
        } else if (image != null) {
            val entry = Saf.Entry("", image, imageName, false, 0L)
            openImage(entry)
        } else {
            showMessage("No supported files selected")
        }
    }

    // ---------------------------------------------------------------------------------------------------- текстуры

    override fun showTextureView(index: Int) {
        enterTextureView(index)
        closePanels()
    }

    override fun exportTexture(index: Int, png: Boolean) {
        if (!hasModel || index < 0 || index >= textureNames.size) {
            return
        }
        pendingTextureIndex = index
        pendingExportPng = png
        val base = textureNames[index].substringBeforeLast('.', textureNames[index])
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = if (png) "image/png" else "image/bmp"
        i.putExtra(Intent.EXTRA_TITLE, base + (if (png) ".png" else ".bmp"))
        startActivityForResult(i, REQ_EXPORT)
    }

    private fun writeTextureExport(uri: Uri) {
        val index = pendingTextureIndex
        val png = pendingExportPng
        showBusy("Exporting texture...")
        val ctx = this
        Thread {
            var ok = false
            try {
                if (png) {
                    val info = IntArray(3)
                    val argb = NativeBridge.nativeTextureArgb(index)
                    if (argb != null && NativeBridge.nativeTextureInfo(index, info)) {
                        ok = Saf.writeBytes(ctx, uri, ImageIo.encodePng(info[0], info[1], argb))
                    }
                } else {
                    val bmp = NativeBridge.nativeTextureBmp(index)
                    if (bmp != null) {
                        ok = Saf.writeBytes(ctx, uri, bmp)
                    }
                }
            } catch (e: Exception) {
                ok = false
            }
            runOnUiThread {
                hideBusy()
                showMessage(if (ok) "Texture exported" else "Texture export failed")
            }
        }.start()
    }

    override fun importTexture(index: Int) {
        if (!hasModel || index < 0 || index >= textureNames.size) {
            return
        }
        pendingTextureIndex = index
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/octet-stream"))
        startActivityForResult(i, REQ_IMPORT)
    }

    private fun importTextureFrom(uri: Uri, name: String, index: Int) {
        showBusy("Importing texture...")
        val ctx = this
        Thread {
            var result = "{\"ok\":false,\"error\":\"Cannot read the image\"}"
            val bytes = Saf.readBytes(ctx, uri)
            if (bytes != null) {
                if (name.lowercase().endsWith(".bmp")) {
                    result = NativeBridge.nativeImportBmp(index, bytes)
                } else {
                    val decoded = ImageIo.decode(name, bytes)
                    result = if (decoded != null) {
                        NativeBridge.nativeImportArgb(index, decoded.width, decoded.height, decoded.argb)
                    } else {
                        "{\"ok\":false,\"error\":\"Unsupported image format\"}"
                    }
                }
            }
            runOnUiThread {
                hideBusy()
                onImportResult(result, index)
            }
        }.start()
    }

    private fun onImportResult(json: String, index: Int) {
        try {
            val o = JSONObject(json)
            if (o.getBoolean("ok")) {
                val warnings = o.optJSONArray("warnings")
                val sb = StringBuilder()
                if (warnings != null) {
                    for (i in 0 until warnings.length()) {
                        sb.append(warnings.getString(i)).append('\n')
                    }
                }
                showMessage("Texture replaced")
                if (sb.isNotEmpty()) {
                    AlertDialog.Builder(this).setTitle("Texture imported").setMessage(sb.toString().trim())
                        .setPositiveButton(android.R.string.ok, null).show()
                }
                if (rightSlide.isOpen) {
                    propsPanel.refresh()
                }
                if (state[Ids.S_SCENE].toInt() == 1) {
                    NativeBridge.command(Ids.CMD_TEX_SELECT, index, -1)
                }
            } else {
                AlertDialog.Builder(this).setTitle("Import failed").setMessage(o.optString("error", "Unknown error"))
                    .setPositiveButton(android.R.string.ok, null).show()
            }
        } catch (e: Exception) {
            showMessage("Import failed")
        }
    }

    override fun pickSceneImage(kind: Int) {
        pendingSceneKind = kind
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/octet-stream"))
        startActivityForResult(i, REQ_SCENE_IMAGE)
    }

    private fun applySceneImage(uri: Uri, name: String, kind: Int) {
        val ctx = this
        Thread {
            var ok = false
            val bytes = Saf.readBytes(ctx, uri)
            val decoded = if (bytes != null) ImageIo.decode(name, bytes) else null
            if (decoded != null) {
                ok = NativeBridge.nativeSetSceneImage(kind, name, decoded.width, decoded.height, decoded.argb)
            }
            runOnUiThread {
                if (ok) {
                    if (kind == Ids.IMG_GROUND) {
                        viewState.setFlag(Ids.FLAG_GROUND_TEXTURE, true)
                    } else {
                        viewState.setFlag(Ids.FLAG_BACKGROUND, true)
                    }
                                if (rightSlide.isOpen) {
                        propsPanel.refresh()
                    }
                    showMessage("Texture applied")
                } else {
                    showMessage("Cannot load the image")
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------------------------------------------- сохранение

    override fun save() {
        if (!hasModel) {
            return
        }
        confirmXash {
            val uri = currentUri
            if (uri == null) {
                startSaveAs()
            } else {
                doSave(uri)
            }
        }
    }

    override fun saveAs() {
        if (!hasModel) {
            return
        }
        confirmXash { startSaveAs() }
    }

    /** Как в оригинале: перед сохранением модели Xash3D предупреждаем, что расширения Xash3D не сохраняются. */
    private fun confirmXash(next: () -> Unit) {
        var xash = false
        try {
            xash = JSONObject(NativeBridge.query(Ids.Q_INFO)).optBoolean("xash", false)
        } catch (e: Exception) {
            xash = false
        }
        if (!xash) {
            next()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Xash3D model")
            .setMessage("Xash3D-specific data is not preserved when the model is saved in the Half-Life format. Continue?")
            .setPositiveButton(android.R.string.ok) { _, _ -> next() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun startSaveAs() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/octet-stream"
        i.putExtra(Intent.EXTRA_TITLE, if (currentName.isEmpty()) "model.mdl" else currentName)
        startActivityForResult(i, REQ_SAVE_AS)
    }

    private fun doSave(uri: Uri) {
        showBusy("Saving...")
        val ctx = this
        val name = currentName
        val tree = currentTree
        val parent = currentParentDoc
        val revision = state[Ids.S_EDIT_REV]
        Thread {
            val parts = NativeBridge.nativeSerialize(name)
            var ok = false
            var note = ""
            var textureBytes: ByteArray? = null
            if (parts != null && parts.isNotEmpty() && parts[0] != null) {
                ok = Saf.writeBytes(ctx, uri, parts[0]!!)
                if (ok && parts.size > 1 && parts[1] != null) {
                    val data = parts[1]!!
                    val textureName = name.substringBeforeLast('.', name) + "T.mdl"
                    var target: Uri? = null
                    if (tree != null && parent != null) {
                        val existing = Saf.findChild(ctx, tree, parent, textureName)
                        target = existing?.uri ?: Saf.createFile(ctx, tree, parent, "application/octet-stream", textureName)
                    }
                    if (target != null && Saf.writeBytes(ctx, target, data)) {
                        note = " (with " + textureName + ")"
                    } else {
                        textureBytes = data
                    }
                }
            }
            val leftover: ByteArray? = textureBytes
            runOnUiThread {
                hideBusy()
                if (ok) {
                    savedEditRev = revision
                    showMessage("Saved" + note)
                    if (leftover != null) {
                        askSaveTextureFile(name.substringBeforeLast('.', name) + "T.mdl", leftover)
                    }
                } else {
                    showMessage("Save failed. Try Save as...")
                }
            }
        }.start()
    }

    private fun askSaveTextureFile(fileName: String, bytes: ByteArray) {
        pendingTextureBytes = bytes
        AlertDialog.Builder(this)
            .setTitle("Texture file")
            .setMessage("This model keeps textures in a separate file. Choose where to save " + fileName + ".")
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "application/octet-stream"
                i.putExtra(Intent.EXTRA_TITLE, fileName)
                startActivityForResult(i, REQ_SAVE_TEXTURE_FILE)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun closeModel() {
        NativeBridge.nativeCloseModel()
        closePanels()
    }

    private fun screenshot() {
        if (!hasModel || surface.width <= 0 || surface.height <= 0) {
            return
        }
        val bitmap = Bitmap.createBitmap(surface.width, surface.height, Bitmap.Config.ARGB_8888)
        PixelCopy.request(surface, bitmap, { result ->
            if (result == PixelCopy.SUCCESS) {
                pendingScreenshot = bitmap
                val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "image/png"
                i.putExtra(Intent.EXTRA_TITLE, currentName.substringBeforeLast('.', "screenshot") + ".png")
                startActivityForResult(i, REQ_SCREENSHOT)
            } else {
                bitmap.recycle()
                showMessage("Screenshot failed")
            }
        }, handler)
    }

    // ---------------------------------------------------------------------------------------------------- Host-методы панелей

    override fun closeFilePanel() {
        leftSlide.close()
    }

    override fun closePropsPanel() {
        rightSlide.close()
    }

    override fun toast(message: String) {
        showMessage(message)
    }

    override fun onPanelChanged() {
    }

    companion object {
        private const val REQ_OPEN_FILES = 101
        private const val REQ_ADD_ROOT = 102
        private const val REQ_EXPORT = 103
        private const val REQ_IMPORT = 104
        private const val REQ_SCENE_IMAGE = 105
        private const val REQ_SAVE_AS = 106
        private const val REQ_SAVE_TEXTURE_FILE = 107
        private const val REQ_SCREENSHOT = 108
    }
}
