package app.lambdaviewer

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListPopupWindow
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

/**
 * Палитра и фабрики элементов интерфейса. Все элементы создаются программно, без AndroidX.
 * Связь с HLAM: заменяет Qt-виджеты .ui оригинала; минимальный размер цели нажатия — 44dp.
 */
object Ui {
    val BG: Int = 0xFF15171B.toInt()
    val PANEL: Int = 0xF2181B20.toInt()
    val BAR: Int = 0xFF1D2025.toInt()
    val CARD: Int = 0xFF262A31.toInt()
    val CARD_HI: Int = 0xFF343A44.toInt()
    val ACCENT: Int = 0xFFFF8A00.toInt()
    val TEXT: Int = 0xFFE8EAED.toInt()
    val TEXT_DIM: Int = 0xFF9AA0A6.toInt()
    val DANGER: Int = 0xFFE5534B.toInt()
}

const val MATCH: Int = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP: Int = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

fun Context.dpf(value: Float): Float = value * resources.displayMetrics.density

fun roundRect(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable {
    val d = GradientDrawable()
    d.shape = GradientDrawable.RECTANGLE
    d.cornerRadius = radiusPx
    d.setColor(color)
    if (strokePx > 0) {
        d.setStroke(strokePx, strokeColor)
    }
    return d
}

fun Context.vbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    return l
}

fun Context.hbox(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.HORIZONTAL
    l.gravity = Gravity.CENTER_VERTICAL
    return l
}

fun <T : View> LinearLayout.add(view: T, w: Int = WRAP, h: Int = WRAP, weight: Float = 0f): T {
    addView(view, LinearLayout.LayoutParams(w, h, weight))
    return view
}

fun Context.label(text: CharSequence, sp: Float = 13f, color: Int = Ui.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    if (bold) {
        t.setTypeface(t.typeface, Typeface.BOLD)
    }
    return t
}

fun Context.sectionTitle(text: String): TextView {
    val t = label(text.uppercase(Locale.US), 11f, Ui.ACCENT, true)
    t.setPadding(dp(4), dp(14), dp(4), dp(4))
    return t
}

fun Context.textButton(text: String, accent: Boolean = false, onClick: () -> Unit): TextView {
    val b = TextView(this)
    b.text = text
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
    b.setTextColor(if (accent) Color.BLACK else Ui.TEXT)
    b.gravity = Gravity.CENTER
    b.setPadding(dp(14), dp(8), dp(14), dp(8))
    b.minimumHeight = dp(44)
    b.background = roundRect(if (accent) Ui.ACCENT else Ui.CARD_HI, dpf(8f))
    b.isClickable = true
    b.setOnClickListener { onClick() }
    return b
}

fun Context.switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch {
    val s = Switch(this)
    s.text = text
    s.setTextColor(Ui.TEXT)
    s.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
    s.isChecked = checked
    s.setPadding(dp(4), dp(8), dp(4), dp(8))
    s.minimumHeight = dp(44)
    s.setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
    return s
}

fun Context.hideKeyboard(view: View) {
    val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(view.windowToken, 0)
}

fun Context.numberField(initial: String, onCommit: (Float) -> Unit): EditText {
    val e = EditText(this)
    e.setText(initial)
    e.setTextColor(Ui.TEXT)
    e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
    e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
    e.imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
    e.setSingleLine(true)
    e.gravity = Gravity.CENTER
    e.setPadding(dp(6), dp(6), dp(6), dp(6))
    e.background = roundRect(Ui.CARD, dpf(6f))
    e.minimumHeight = dp(40)
    e.setSelectAllOnFocus(true)
    e.setOnEditorActionListener { v, actionId, _ ->
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            val value = v.text.toString().replace(',', '.').toFloatOrNull()
            if (value != null) {
                onCommit(value)
            }
            v.clearFocus()
            hideKeyboard(v)
            true
        } else {
            false
        }
    }
    return e
}

/** Присваивает текст только при изменении, чтобы опрос состояния 10 раз в секунду не вызывал лишних перерасчётов разметки. */
fun TextView.setTextIfChanged(value: String) {
    if (text.toString() != value) {
        text = value
    }
}

fun formatFloat(v: Float, decimals: Int): String {
    return if (decimals <= 0) v.toInt().toString() else String.format(Locale.US, "%." + decimals + "f", v)
}

/** Подписанный ползунок с вещественным диапазоном (аналог QSlider + QDoubleSpinBox оригинала). */
class SeekRow(
    context: Context,
    title: String,
    private val min: Float,
    private val max: Float,
    initial: Float,
    private val decimals: Int,
    private val onChange: (Float) -> Unit
) : LinearLayout(context) {
    private val valueView: TextView = context.label("", 12f, Ui.TEXT)
    private val seek: SeekBar = SeekBar(context)

    init {
        orientation = LinearLayout.VERTICAL
        val header = context.hbox()
        header.add(context.label(title, 12f, Ui.TEXT_DIM), 0, WRAP, 1f)
        header.add(valueView)
        addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
        seek.max = 1000
        addView(seek, LinearLayout.LayoutParams(MATCH, context.dp(36)))
        set(initial)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) {
                    return
                }
                val v = min + (max - min) * progress / 1000f
                valueView.text = formatFloat(v, decimals)
                onChange(v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
    }

    fun set(v: Float) {
        val range = if (max - min == 0f) 1f else max - min
        seek.progress = ((v - min) / range * 1000f).toInt().coerceIn(0, 1000)
        valueView.text = formatFloat(v, decimals)
    }

    fun isTracking(): Boolean = seek.isPressed
}

/** Выпадающий список (аналог QComboBox): открывается одним касанием и показывает все пункты сразу. */
fun Context.showDropdown(anchor: View, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val ctx: Context = this
    val popup = ListPopupWindow(ctx)
    popup.anchorView = anchor
    popup.setAdapter(object : ArrayAdapter<String>(ctx, android.R.layout.simple_list_item_1, items) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getView(position, convertView, parent) as TextView
            v.setTextColor(if (position == selected) Ui.ACCENT else Ui.TEXT)
            v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            v.minimumHeight = ctx.dp(44)
            return v
        }
    })
    popup.setBackgroundDrawable(roundRect(Ui.CARD, ctx.dpf(8f)))
    popup.width = Math.max(anchor.width, ctx.dp(240))
    popup.height = ListPopupWindow.WRAP_CONTENT
    popup.isModal = true
    popup.setOnItemClickListener { _, _, position, _ ->
        popup.dismiss()
        onPick(position)
    }
    popup.show()
    popup.listView?.setSelection(selected)
}

/** Кнопка-выпадающий список с текущим значением. */
fun Context.dropdownButton(items: () -> List<String>, selected: () -> Int, onPick: (Int) -> Unit): TextView {
    val b = TextView(this)
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
    b.setTextColor(Ui.TEXT)
    b.gravity = Gravity.CENTER_VERTICAL
    b.setPadding(dp(12), dp(8), dp(12), dp(8))
    b.minimumHeight = dp(44)
    b.background = roundRect(Ui.CARD_HI, dpf(8f))
    b.isClickable = true
    b.setSingleLine(true)
    b.setOnClickListener {
        val list = items()
        if (list.isNotEmpty()) {
            showDropdown(b, list, selected(), onPick)
        }
    }
    return b
}

fun Context.promptText(title: String, initial: String, numeric: Boolean, onOk: (String) -> Unit) {
    val edit = EditText(this)
    edit.setText(initial)
    edit.setSelectAllOnFocus(true)
    edit.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
    edit.inputType = if (numeric) {
        InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
    } else {
        InputType.TYPE_CLASS_TEXT
    }
    AlertDialog.Builder(this)
        .setTitle(title)
        .setView(edit)
        .setPositiveButton(android.R.string.ok) { _, _ -> onOk(edit.text.toString()) }
        .setNegativeButton(android.R.string.cancel, null)
        .show()
}

/** Диалог выбора цвета (замена QColorDialog): ползунки R/G/B и опционально прозрачность. */
fun Context.pickColor(title: String, initialArgb: Int, withAlpha: Boolean, onOk: (Int) -> Unit) {
    val ctx: Context = this
    val state = intArrayOf(Color.alpha(initialArgb), Color.red(initialArgb), Color.green(initialArgb), Color.blue(initialArgb))
    if (!withAlpha) {
        state[0] = 255
    }
    val root = ctx.vbox()
    root.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(8))
    val swatch = View(ctx)
    swatch.background = roundRect(Color.argb(state[0], state[1], state[2], state[3]), ctx.dpf(8f), Ui.TEXT_DIM, 2)
    root.add(swatch, MATCH, ctx.dp(40))
    val names = arrayOf("A", "R", "G", "B")
    for (i in 0 until 4) {
        if (i == 0 && !withAlpha) {
            continue
        }
        val index = i
        val row = SeekRow(ctx, names[i], 0f, 255f, state[i].toFloat(), 0) { v ->
            state[index] = v.toInt()
            swatch.background = roundRect(Color.argb(state[0], state[1], state[2], state[3]), ctx.dpf(8f), Ui.TEXT_DIM, 2)
        }
        root.add(row, MATCH, WRAP)
    }
    AlertDialog.Builder(ctx)
        .setTitle(title)
        .setView(root)
        .setPositiveButton(android.R.string.ok) { _, _ -> onOk(Color.argb(state[0], state[1], state[2], state[3])) }
        .setNegativeButton(android.R.string.cancel, null)
        .show()
}

fun Context.showText(title: String, text: String) {
    val tv = label(text, 12f, Ui.TEXT)
    tv.typeface = Typeface.MONOSPACE
    tv.setTextIsSelectable(true)
    tv.setPadding(dp(16), dp(8), dp(16), dp(8))
    val scroll = android.widget.ScrollView(this)
    scroll.addView(tv)
    AlertDialog.Builder(this).setTitle(title).setView(scroll).setPositiveButton(android.R.string.ok, null).show()
}
