package app.lambdaviewer

import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/*
 * Содержимое вкладок PropertiesPanel: Model, Animation, Textures, View, Parts, Settings.
 * Связь с HLAM: вкладки заменяют док-панели оригинала (ModelDataPanel, SequencesPanel, BodyPartsPanel, TexturesPanel,
 * BonesPanel, BoneControllersPanel, AttachmentsPanel, HitboxesPanel, ModelDisplayPanel, панели пола/фона/света,
 * TransformPanel, диалог Options). Редко нужные настройки спрятаны в сворачиваемые секции.
 */

private val uiHandler = Handler(Looper.getMainLooper())

private fun PropertiesPanel.state(): FloatArray {
    val s = FloatArray(Ids.S_COUNT)
    NativeBridge.nativeState(s)
    return s
}

private fun PropertiesPanel.put(view: View): View {
    target.addView(view, LinearLayout.LayoutParams(MATCH, WRAP))
    return view
}

private fun PropertiesPanel.subtitle(text: String) {
    val t = context.label(text, 12f, Ui.TEXT_DIM, true)
    t.setPadding(context.dp(4), context.dp(12), context.dp(4), context.dp(4))
    put(t)
}

private fun PropertiesPanel.kv(key: String, value: String) {
    val r = context.hbox()
    r.setPadding(context.dp(4), context.dp(3), context.dp(4), context.dp(3))
    r.add(context.label(key, 12f, Ui.TEXT_DIM), 0, WRAP, 1f)
    r.add(context.label(value, 12f, Ui.TEXT))
    put(r)
}

private fun PropertiesPanel.hint(text: String) {
    val t = context.label(text, 12f, Ui.TEXT_DIM)
    t.setPadding(context.dp(4), context.dp(4), context.dp(4), context.dp(4))
    put(t)
}

private fun PropertiesPanel.flagSwitch(title: String, id: Int, after: (() -> Unit)? = null) {
    put(context.switchRow(title, viewState.flag(id)) { v ->
        viewState.setFlag(id, v)
        host.onPanelChanged()
        if (after != null) {
            after()
        }
    })
}

private fun PropertiesPanel.dropdownRow(title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val ctx = context
    val row = ctx.hbox()
    row.setPadding(ctx.dp(4), ctx.dp(2), ctx.dp(4), ctx.dp(2))
    row.add(ctx.label(title, 13f, Ui.TEXT), 0, WRAP, 1f)
    var sel = selected
    val holder = arrayOfNulls<TextView>(1)
    val button = ctx.dropdownButton({ items }, { sel }, { idx ->
        sel = idx
        holder[0]?.text = items[idx] + "  \u25BE"
        onPick(idx)
    })
    holder[0] = button
    button.text = (if (selected >= 0 && selected < items.size) items[selected] else "-") + "  \u25BE"
    row.add(button, ctx.dp(190), WRAP)
    put(row)
}

private fun PropertiesPanel.actionRow(vararg buttons: TextView) {
    val row = context.hbox()
    for (b in buttons) {
        row.add(b, 0, WRAP, 1f)
        (b.layoutParams as LinearLayout.LayoutParams).setMargins(context.dp(2), context.dp(4), context.dp(2), context.dp(4))
    }
    put(row)
}

private fun readFloats(edits: List<EditText>): FloatArray {
    val out = FloatArray(edits.size)
    for (i in edits.indices) {
        out[i] = edits[i].text.toString().replace(',', '.').toFloatOrNull() ?: 0f
    }
    return out
}

private fun PropertiesPanel.fieldsRow(title: String, values: FloatArray, applyLabel: String, onApply: (FloatArray) -> Unit) {
    put(context.label(title, 12f, Ui.TEXT_DIM))
    val row = context.hbox()
    val edits = ArrayList<EditText>()
    for (v in values) {
        val e = context.numberField(formatFloat(v, 2)) { _ -> }
        edits.add(e)
        row.add(e, 0, WRAP, 1f)
    }
    row.add(context.textButton(applyLabel) { onApply(readFloats(edits)) })
    put(row)
}

private fun vec(o: JSONObject, key: String): FloatArray {
    val a = o.getJSONArray(key)
    return floatArrayOf(a.getDouble(0).toFloat(), a.getDouble(1).toFloat(), a.getDouble(2).toFloat())
}

private fun join(v: FloatArray): String = v[0].toString() + " " + v[1] + " " + v[2]

/** Сворачиваемая секция: по умолчанию свёрнута, состояние сохраняется при перестроении вкладки. */
internal fun PropertiesPanel.collapsible(title: String, build: () -> Unit) {
    val ctx = context
    val key = tab.toString() + ":" + title
    val open = expandedSections.contains(key)
    val container = ctx.vbox()
    container.visibility = if (open) View.VISIBLE else View.GONE
    container.setPadding(ctx.dp(4), 0, ctx.dp(4), ctx.dp(8))

    val line = View(ctx)
    line.setBackgroundColor(0x22FFFFFF)
    target.addView(line, LinearLayout.LayoutParams(MATCH, 1))

    val arrow = ctx.label(if (open) "\u25BE" else "\u25B8", 16f, Ui.TEXT_DIM)
    val header = ctx.hbox()
    header.minimumHeight = ctx.dp(48)
    header.setPadding(ctx.dp(4), 0, ctx.dp(4), 0)
    header.add(ctx.label(title, 14f, Ui.TEXT, true), 0, WRAP, 1f)
    header.add(arrow)
    header.isClickable = true
    header.setOnClickListener {
        if (container.visibility == View.VISIBLE) {
            container.visibility = View.GONE
            expandedSections.remove(key)
            arrow.text = "\u25B8"
        } else {
            container.visibility = View.VISIBLE
            expandedSections.add(key)
            arrow.text = "\u25BE"
        }
    }
    put(header)

    val parent = target
    target = container
    build()
    target = parent
    parent.addView(container, LinearLayout.LayoutParams(MATCH, WRAP))
}

// ------------------------------------------------------------------------------------------------ Model

private val MODEL_FLAGS: List<Pair<String, Int>> = listOf(
    Pair("Rocket Trail", 1), Pair("Grenade Smoke", 2), Pair("Gib Blood", 4), Pair("Model Rotate", 8),
    Pair("Green Trail", 16), Pair("Zombie Blood", 32), Pair("Orange Trail", 64), Pair("Purple Trail", 128),
    Pair("No Shade Lighting", 256), Pair("Hitbox Collision", 512), Pair("Force Skylight", 1024)
)

internal fun PropertiesPanel.buildModelTab() {
    val info = JSONObject(NativeBridge.query(Ids.Q_INFO))
    val name = context.label(info.getString("fileName").substringAfterLast('/'), 15f, Ui.TEXT, true)
    name.setSingleLine(true)
    name.setPadding(context.dp(4), context.dp(4), context.dp(4), 0)
    put(name)
    val xash = if (info.getBoolean("xash")) "   Xash3D" else ""
    hint(info.getInt("bones").toString() + " bones   " + info.getInt("sequences") + " sequences   " +
        info.getInt("textures") + " textures   " + info.getInt("triangles") + " triangles" + xash)

    buildBodyAndSkin()

    collapsible("Position and transform") { buildTransformSection() }
    collapsible("Model data") { buildModelDataSection(info) }

    actionRow(
        context.textButton("Save as...") { host.saveAs() },
        context.textButton("Close model") { host.closeModel() }
    )
}

private fun PropertiesPanel.buildBodyAndSkin() {
    val st = state()
    val parts = JSONArray(NativeBridge.query(Ids.Q_BODYPARTS))
    var selectable = 0
    for (i in 0 until parts.length()) {
        val p = parts.getJSONObject(i)
        val models = p.getJSONArray("models")
        if (models.length() < 2) {
            continue
        }
        if (selectable == 0) {
            subtitle("Body parts")
        }
        selectable++
        val names = ArrayList<String>()
        for (m in 0 until models.length()) {
            names.add(m.toString() + ": " + models.getString(m))
        }
        val index = i
        dropdownRow(p.getString("name"), names, p.getInt("value")) { idx -> NativeBridge.command(Ids.CMD_SET_BODYGROUP, index, idx) }
    }
    val tex = JSONObject(NativeBridge.query(Ids.Q_TEXTURES))
    val families = tex.getJSONArray("skinFamilies")
    if (families.length() > 1) {
        subtitle("Skin")
        val names = ArrayList<String>()
        for (i in 0 until families.length()) {
            names.add("Skin " + (i + 1))
        }
        dropdownRow("Skin family", names, st[Ids.S_SKIN].toInt()) { idx -> NativeBridge.command(Ids.CMD_SET_SKIN, idx) }
    }
}

private fun PropertiesPanel.buildTransformSection() {
    subtitle("Position")
    fieldsRow("X  Y  Z", floatArrayOf(0f, 0f, 0f), "Set") { v -> NativeBridge.command(Ids.CMD_SET_MODEL_ORIGIN, 0, 0, 0f, join(v)) }
    actionRow(
        context.textButton("Center on origin") { NativeBridge.command(Ids.CMD_CENTER_MODEL) },
        context.textButton("Align on ground") { NativeBridge.command(Ids.CMD_ALIGN_ON_GROUND) }
    )
    subtitle("Move model data")
    fieldsRow("X  Y  Z", floatArrayOf(0f, 0f, 0f), "Apply") { v ->
        NativeBridge.command(Ids.CMD_XFORM_MOVE, 0, 0, 0f, join(v))
        host.onPanelChanged()
    }
    subtitle("Rotate model data (degrees)")
    fieldsRow("X  Y  Z", floatArrayOf(0f, 0f, 0f), "Apply") { v ->
        NativeBridge.command(Ids.CMD_XFORM_ROTATE, 0, 0, 0f, join(v))
        host.onPanelChanged()
    }
    subtitle("Scale model data")
    var flags = 63
    val names = listOf("Meshes", "Hitboxes", "Sequence bounding boxes", "Bones", "Eye position", "Attachments")
    for (i in names.indices) {
        val bit = 1 shl i
        put(context.switchRow(names[i], true) { on -> flags = if (on) (flags or bit) else (flags and bit.inv()) })
    }
    val scaleRow = context.hbox()
    val factor = context.numberField("1.0") { _ -> }
    scaleRow.add(context.label("Factor", 12f, Ui.TEXT_DIM), 0, WRAP, 1f)
    scaleRow.add(factor, context.dp(90), WRAP)
    scaleRow.add(context.textButton("Apply") {
        val f = factor.text.toString().replace(',', '.').toFloatOrNull() ?: 1f
        if (f > 0f) {
            NativeBridge.command(Ids.CMD_XFORM_SCALE, flags, 0, f)
            host.onPanelChanged()
        }
    })
    put(scaleRow)
    hint("Changes modify the model data; use Save to write the file.")
}

private fun PropertiesPanel.buildModelDataSection(info: JSONObject) {
    subtitle("Eye position")
    fieldsRow("X  Y  Z", vec(info, "eye"), "Apply") { v ->
        NativeBridge.command(Ids.CMD_SET_EYE, 0, 0, 0f, join(v))
        host.onPanelChanged()
    }
    val bboxMin = vec(info, "bbmin")
    val bboxMax = vec(info, "bbmax")
    subtitle("Bounding box")
    kv("Min", bboxMin.joinToString("  ") { formatFloat(it, 2) })
    kv("Max", bboxMax.joinToString("  ") { formatFloat(it, 2) })
    actionRow(context.textButton("Edit bounding box") {
        context.promptText("minX minY minZ maxX maxY maxZ", bboxMin.joinToString(" ") + " " + bboxMax.joinToString(" "), false) { text ->
            NativeBridge.command(Ids.CMD_SET_BBOX, 0, 0, 0f, text)
            host.onPanelChanged()
        }
    })
    val cboxMin = vec(info, "cbmin")
    val cboxMax = vec(info, "cbmax")
    subtitle("Clipping box")
    kv("Min", cboxMin.joinToString("  ") { formatFloat(it, 2) })
    kv("Max", cboxMax.joinToString("  ") { formatFloat(it, 2) })
    actionRow(context.textButton("Edit clipping box") {
        context.promptText("minX minY minZ maxX maxY maxZ", cboxMin.joinToString(" ") + " " + cboxMax.joinToString(" "), false) { text ->
            NativeBridge.command(Ids.CMD_SET_CBOX, 0, 0, 0f, text)
            host.onPanelChanged()
        }
    })
    subtitle("Flags")
    var flags = info.getInt("flags")
    for (f in MODEL_FLAGS) {
        val bit = f.second
        put(context.switchRow(f.first, (flags and bit) != 0) { on ->
            flags = if (on) (flags or bit) else (flags and bit.inv())
            NativeBridge.command(Ids.CMD_SET_MODEL_FLAGS, flags)
            host.onPanelChanged()
        })
    }
    subtitle("Normals")
    actionRow(context.textButton("Flip normals") {
        NativeBridge.command(Ids.CMD_FLIP_NORMALS)
        host.onPanelChanged()
        host.toast("Normals flipped")
    })
    subtitle("Statistics")
    val st = state()
    kv("Vertices", info.getInt("vertices").toString())
    kv("Normals", info.getInt("normals").toString())
    kv("Meshes", info.getInt("meshes").toString())
    kv("Transitions", info.getInt("transitions").toString())
    kv("Texture data", formatFloat(info.getLong("textureBytes") / 1024f, 1) + " KB")
    kv("Polygons drawn", st[Ids.S_POLYS].toInt().toString())
    kv("Frames per second", st[Ids.S_FPS].toInt().toString())
}

// ------------------------------------------------------------------------------------------------ Animation

internal fun PropertiesPanel.buildAnimationTab() {
    val st = state()
    val seqs = JSONArray(NativeBridge.query(Ids.Q_SEQUENCES))
    val current = st[Ids.S_SEQUENCE].toInt()

    put(context.switchRow("Skeleton pose (no animation)", current < 0) { on -> host.setSkeletonPose(on) })
    dropdownRow("Looping", listOf("Always loop", "Never loop", "Use sequence setting"), st[Ids.S_LOOP_MODE].toInt()) { idx ->
        NativeBridge.command(Ids.CMD_SET_LOOP_MODE, idx)
    }

    if (current >= 0 && current < seqs.length()) {
        collapsible("Sequence details") { buildSequenceDetails(st, seqs.getJSONObject(current), current) }
    }

    subtitle("Sequences (" + seqs.length() + ")")
    for (i in 0 until seqs.length()) {
        val s = seqs.getJSONObject(i)
        val r = context.hbox()
        r.setPadding(context.dp(8), context.dp(4), context.dp(8), context.dp(4))
        r.minimumHeight = context.dp(44)
        r.background = if (i == current) roundRect(0x33FF8A00, context.dpf(6f)) else null
        val name = r.add(context.label(s.getString("name"), 13f, if (i == current) Ui.ACCENT else Ui.TEXT), 0, WRAP, 1f)
        name.setSingleLine(true)
        r.add(context.label(s.getInt("frames").toString() + " fr", 11f, Ui.TEXT_DIM))
        r.isClickable = true
        val index = i
        r.setOnClickListener {
            NativeBridge.command(Ids.CMD_SET_SEQUENCE, index)
            refresh()
        }
        put(r)
    }
}

private fun PropertiesPanel.buildSequenceDetails(st: FloatArray, seq: JSONObject, current: Int) {
    dropdownRow("Blend mode", listOf("Standard", "Counter-Strike"), st[Ids.S_BLEND_MODE].toInt()) { idx ->
        NativeBridge.command(Ids.CMD_SET_BLEND_MODE, idx)
        refresh()
    }
    val blendMode = st[Ids.S_BLEND_MODE].toInt()
    val blendData = seq.getJSONArray("blendData")
    for (i in 0 until 2) {
        val bd = blendData.getJSONObject(i)
        if (blendMode == 0 && bd.getInt("type") == 0) {
            continue
        }
        val lo: Float
        val hi: Float
        if (blendMode == 1) {
            lo = if (i == 0) -180f else -45f
            hi = if (i == 0) 180f else 45f
        } else {
            val a = bd.getDouble("start").toFloat()
            val b = bd.getDouble("end").toFloat()
            lo = Math.min(a, b)
            hi = Math.max(a, b)
        }
        val initial = st[if (i == 0) Ids.S_BLEND0 else Ids.S_BLEND1]
        val index = i
        put(SeekRow(context, "Blend $index", lo, hi, initial, 1) { v -> NativeBridge.command(Ids.CMD_SET_BLEND, index, 0, v) })
    }
    kv("Frames", seq.getInt("frames").toString())
    put(context.switchRow("Looping flag", seq.getBoolean("looping")) { on ->
        NativeBridge.command(Ids.CMD_SET_SEQ_LOOPING, current, if (on) 1 else 0)
        host.onPanelChanged()
    })
    val fpsRow = context.hbox()
    fpsRow.setPadding(context.dp(4), context.dp(2), context.dp(4), context.dp(2))
    fpsRow.add(context.label("Sequence FPS", 13f, Ui.TEXT), 0, WRAP, 1f)
    fpsRow.add(context.numberField(formatFloat(seq.getDouble("fps").toFloat(), 2)) { v ->
        NativeBridge.command(Ids.CMD_SET_SEQ_FPS, current, 0, v)
        host.onPanelChanged()
    }, context.dp(100), WRAP)
    put(fpsRow)

    val acts = JSONArray(NativeBridge.query(Ids.Q_ACTIVITIES))
    val names = ArrayList<String>()
    val ids = ArrayList<Int>()
    var selectedAct = 0
    for (i in 0 until acts.length()) {
        val o = acts.getJSONObject(i)
        names.add(o.getString("name"))
        ids.add(o.getInt("id"))
        if (o.getInt("id") == seq.getInt("activity")) {
            selectedAct = i
        }
    }
    dropdownRow("Activity", names, selectedAct) { idx ->
        NativeBridge.command(Ids.CMD_SET_SEQ_ACTIVITY, current, ids[idx])
        host.onPanelChanged()
    }
    val weightRow = context.hbox()
    weightRow.setPadding(context.dp(4), context.dp(2), context.dp(4), context.dp(2))
    weightRow.add(context.label("Activity weight", 13f, Ui.TEXT), 0, WRAP, 1f)
    weightRow.add(context.numberField(seq.getInt("actWeight").toString()) { v ->
        NativeBridge.command(Ids.CMD_SET_SEQ_ACTWEIGHT, current, v.toInt())
        host.onPanelChanged()
    }, context.dp(100), WRAP)
    put(weightRow)

    val lin = vec(seq, "linear")
    kv("Linear movement", lin.joinToString("  ") { formatFloat(it, 2) })
    val events = seq.getJSONArray("events")
    if (events.length() > 0) {
        subtitle("Events")
        for (i in 0 until events.length()) {
            val e = events.getJSONObject(i)
            kv("Frame " + e.getInt("frame"), "id " + e.getInt("id") + "  " + e.getString("options"))
        }
    }
}

// ------------------------------------------------------------------------------------------------ Textures

private fun flagsText(flags: Int): String {
    val names = ArrayList<String>()
    if ((flags and 0x0001) != 0) names.add("flatshade")
    if ((flags and 0x0002) != 0) names.add("chrome")
    if ((flags and 0x0004) != 0) names.add("fullbright")
    if ((flags and 0x0008) != 0) names.add("mipmaps")
    if ((flags and 0x0010) != 0) names.add("alpha")
    if ((flags and 0x0020) != 0) names.add("additive")
    if ((flags and 0x0040) != 0) names.add("masked")
    return if (names.isEmpty()) "" else names.joinToString(", ")
}

internal fun PropertiesPanel.buildTexturesTab() {
    val st = state()
    val tex = JSONObject(NativeBridge.query(Ids.Q_TEXTURES))
    val list = tex.getJSONArray("textures")

    collapsible("Texture view") {
        put(SeekRow(context, "Zoom", 0.1f, 8f, st[Ids.S_TEX_SCALE].coerceIn(0.1f, 8f), 2) { v -> NativeBridge.command(Ids.CMD_TEX_SCALE, 0, 0, v) })
        flagSwitch("Show UV map", Ids.FLAG_UV_SHOW)
        flagSwitch("Overlay UV map", Ids.FLAG_UV_OVERLAY)
        flagSwitch("Anti-alias UV lines", Ids.FLAG_UV_AA)
        if (selectedTexture >= 0 && selectedTexture < list.length()) {
            val meshCount = NativeBridge.query(Ids.Q_TEXTURE_MESHES, selectedTexture).toIntOrNull() ?: 0
            val items = ArrayList<String>()
            for (i in 0 until meshCount) {
                items.add("Mesh " + (i + 1))
            }
            if (meshCount > 1) {
                items.add("All")
            }
            if (items.isNotEmpty()) {
                val texIndex = selectedTexture
                dropdownRow("Mesh", items, items.size - 1) { idx ->
                    NativeBridge.command(Ids.CMD_TEX_SELECT, texIndex, if (meshCount > 1 && idx == meshCount) -1 else idx)
                }
            }
        }
        actionRow(context.textButton("Reset view") { NativeBridge.command(Ids.CMD_TEX_RESET_VIEW) })
    }
    collapsible("Remap colors") {
        put(SeekRow(context, "Top color", 0f, 255f, tex.getInt("topColor").toFloat(), 0) { v -> NativeBridge.command(Ids.CMD_SET_TOP_COLOR, v.toInt()) })
        put(SeekRow(context, "Bottom color", 0f, 255f, tex.getInt("bottomColor").toFloat(), 0) { v -> NativeBridge.command(Ids.CMD_SET_BOTTOM_COLOR, v.toInt()) })
    }

    subtitle("Textures (" + list.length() + ")")
    for (i in 0 until list.length()) {
        val t = list.getJSONObject(i)
        val index = i
        val card = context.vbox()
        card.setPadding(context.dp(8), context.dp(8), context.dp(8), context.dp(8))
        card.background = roundRect(if (i == selectedTexture) 0x33FF8A00 else Ui.CARD, context.dpf(8f))

        val top = context.hbox()
        val thumb = ImageView(context)
        thumb.scaleType = ImageView.ScaleType.FIT_CENTER
        thumb.setBackgroundColor(0xFF101216.toInt())
        top.add(thumb, context.dp(56), context.dp(56))
        val col = context.vbox()
        col.setPadding(context.dp(10), 0, 0, 0)
        val nameView = col.add(context.label(t.getString("name"), 13f, Ui.TEXT, true))
        nameView.setSingleLine(true)
        col.add(context.label(t.getInt("w").toString() + " x " + t.getInt("h"), 11f, Ui.TEXT_DIM))
        val flagsLine = flagsText(t.getInt("flags"))
        if (flagsLine.isNotEmpty()) {
            col.add(context.label(flagsLine, 11f, Ui.TEXT_DIM))
        }
        top.add(col, 0, WRAP, 1f)
        card.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val buttons = context.hbox()
        val viewBtn = context.textButton("View", true) {
            selectedTexture = index
            host.showTextureView(index)
        }
        val png = context.textButton("PNG") { host.exportTexture(index, true) }
        val bmp = context.textButton("BMP") { host.exportTexture(index, false) }
        val imp = context.textButton("Import") { host.importTexture(index) }
        for (b in arrayOf(viewBtn, png, bmp, imp)) {
            b.setPadding(context.dp(6), context.dp(6), context.dp(6), context.dp(6))
            buttons.add(b, 0, WRAP, 1f)
            (b.layoutParams as LinearLayout.LayoutParams).setMargins(context.dp(2), context.dp(6), context.dp(2), 0)
        }
        card.addView(buttons, LinearLayout.LayoutParams(MATCH, WRAP))

        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(0, context.dp(4), 0, context.dp(4))
        target.addView(card, lp)
        loadThumbnail(thumb, index)
    }
}

private fun PropertiesPanel.loadThumbnail(targetView: ImageView, index: Int) {
    val size = context.dp(56)
    Thread {
        val info = IntArray(3)
        var bitmap: Bitmap? = null
        if (NativeBridge.nativeTextureInfo(index, info)) {
            val argb = NativeBridge.nativeTextureArgb(index)
            if (argb != null && info[0] > 0 && info[1] > 0 && argb.size >= info[0] * info[1]) {
                try {
                    val full = Bitmap.createBitmap(argb, info[0], info[1], Bitmap.Config.ARGB_8888)
                    val scale = Math.min(size.toFloat() / info[0], size.toFloat() / info[1])
                    val w = Math.max(1, (info[0] * scale).toInt())
                    val h = Math.max(1, (info[1] * scale).toInt())
                    bitmap = Bitmap.createScaledBitmap(full, w, h, true)
                    if (bitmap !== full) {
                        full.recycle()
                    }
                } catch (e: Exception) {
                    bitmap = null
                }
            }
        }
        val result = bitmap
        uiHandler.post {
            if (result != null) {
                targetView.setImageBitmap(result)
            }
        }
    }.start()
}

// ------------------------------------------------------------------------------------------------ View

internal fun PropertiesPanel.buildViewTab() {
    val st = state()
    dropdownRow("Render mode", listOf("Wireframe", "Flat shaded", "Smooth shaded", "Texture shaded"), viewState.renderMode) { idx ->
        viewState.renderMode = idx
    }
    put(SeekRow(context, "Opacity", 0f, 1f, viewState.opacity, 2) { v -> viewState.opacity = v })

    collapsible("Overlays") {
        flagSwitch("Hitboxes", Ids.FLAG_HITBOXES)
        flagSwitch("Bones", Ids.FLAG_BONES)
        flagSwitch("Attachments", Ids.FLAG_ATTACHMENTS)
        flagSwitch("Eye position", Ids.FLAG_EYE)
        flagSwitch("Bounding box", Ids.FLAG_BBOX)
        flagSwitch("Clipping box", Ids.FLAG_CBOX)
        flagSwitch("Normals", Ids.FLAG_NORMALS)
        flagSwitch("Coordinate axes", Ids.FLAG_AXES)
        flagSwitch("Player hitbox", Ids.FLAG_PLAYER_HITBOX)
        flagSwitch("Crosshair", Ids.FLAG_CROSSHAIR)
        flagSwitch("Guidelines", Ids.FLAG_GUIDELINES)
        flagSwitch("Off-screen areas", Ids.FLAG_OFFSCREEN)
    }
    collapsible("Rendering") {
        flagSwitch("Backface culling", Ids.FLAG_BACKFACE)
        flagSwitch("Wireframe overlay", Ids.FLAG_WIREFRAME_OVERLAY)
        flagSwitch("Draw shadows", Ids.FLAG_SHADOWS)
        flagSwitch("Fix shadow Z-fighting", Ids.FLAG_SHADOW_FIX)
        flagSwitch("Mirror X axis", Ids.FLAG_MIRROR_X)
        flagSwitch("Mirror Y axis", Ids.FLAG_MIRROR_Y)
        flagSwitch("Mirror Z axis", Ids.FLAG_MIRROR_Z)
    }
    collapsible("Camera") {
        val cams = JSONArray(NativeBridge.query(Ids.Q_CAMERAS))
        val names = ArrayList<String>()
        var currentCamera = 0
        for (i in 0 until cams.length()) {
            val c = cams.getJSONObject(i)
            names.add(c.getString("name"))
            if (c.getBoolean("current")) {
                currentCamera = i
            }
        }
        dropdownRow("Camera", names, currentCamera) { idx ->
            NativeBridge.command(Ids.CMD_CAM_SELECT, idx)
            refresh()
        }
        put(SeekRow(context, "Field of view", 10f, 170f, st[Ids.S_FOV].coerceIn(10f, 170f), 0) { v -> NativeBridge.command(Ids.CMD_CAM_FOV, -1, 0, v) })
        subtitle("Center view on axis")
        actionRow(
            context.textButton("X+") { NativeBridge.command(Ids.CMD_CAM_CENTER, 0, 1) },
            context.textButton("X-") { NativeBridge.command(Ids.CMD_CAM_CENTER, 0, 0) },
            context.textButton("Y+") { NativeBridge.command(Ids.CMD_CAM_CENTER, 1, 1) }
        )
        actionRow(
            context.textButton("Y-") { NativeBridge.command(Ids.CMD_CAM_CENTER, 1, 0) },
            context.textButton("Z+") { NativeBridge.command(Ids.CMD_CAM_CENTER, 2, 1) },
            context.textButton("Z-") { NativeBridge.command(Ids.CMD_CAM_CENTER, 2, 0) }
        )
        actionRow(
            context.textButton("Save view") { NativeBridge.command(Ids.CMD_SAVE_VIEW); host.toast("View saved") },
            context.textButton("Restore view") { NativeBridge.command(Ids.CMD_RESTORE_VIEW) }
        )
        subtitle("Guideline aspect ratio")
        val aspectRow = context.hbox()
        val ex = context.numberField(prefs.getInt("aspect_x", 16).toString()) { _ -> }
        val ey = context.numberField(prefs.getInt("aspect_y", 9).toString()) { _ -> }
        aspectRow.add(ex, 0, WRAP, 1f)
        aspectRow.add(context.label(" : ", 14f), WRAP, WRAP)
        aspectRow.add(ey, 0, WRAP, 1f)
        aspectRow.add(context.textButton("Apply") {
            val x = (ex.text.toString().toFloatOrNull() ?: 16f).toInt().coerceIn(1, 100)
            val y = (ey.text.toString().toFloatOrNull() ?: 9f).toInt().coerceIn(1, 100)
            prefs.putInt("aspect_x", x)
            prefs.putInt("aspect_y", y)
            NativeBridge.command(Ids.CMD_SET_ASPECT, x, y)
        })
        put(aspectRow)
    }
    collapsible("Ground and background") {
        flagSwitch("Show ground", Ids.FLAG_GROUND) { refresh() }
        flagSwitch("Mirror model on ground", Ids.FLAG_GROUND_MIRROR) { refresh() }
        flagSwitch("Ground texture", Ids.FLAG_GROUND_TEXTURE) { refresh() }
        flagSwitch("Tile ground texture", Ids.FLAG_GROUND_TILING)
        val tileRow = context.hbox()
        tileRow.setPadding(context.dp(4), context.dp(2), context.dp(4), context.dp(2))
        tileRow.add(context.label("Tile size", 13f, Ui.TEXT), 0, WRAP, 1f)
        tileRow.add(context.numberField(prefs.getInt("ground_tile", 128).toString()) { v ->
            val size = v.toInt().coerceIn(1, 4096)
            prefs.putInt("ground_tile", size)
            NativeBridge.command(Ids.CMD_SET_GROUND_TEXTURE_LENGTH, size)
        }, context.dp(100), WRAP)
        put(tileRow)
        actionRow(
            context.textButton("Ground texture...") { host.pickSceneImage(Ids.IMG_GROUND) },
            context.textButton("Clear") { NativeBridge.command(Ids.CMD_CLEAR_IMAGE, Ids.IMG_GROUND) }
        )
        flagSwitch("Background texture", Ids.FLAG_BACKGROUND)
        actionRow(
            context.textButton("Background texture...") { host.pickSceneImage(Ids.IMG_BACKGROUND) },
            context.textButton("Clear") { NativeBridge.command(Ids.CMD_CLEAR_IMAGE, Ids.IMG_BACKGROUND) }
        )
    }
    collapsible("Light") {
        flagSwitch("Edit light by touch", Ids.FLAG_LIGHT_EDIT)
        put(SeekRow(context, "Pitch", 0f, 360f, st[Ids.S_LIGHT_X], 0) { v ->
            NativeBridge.command(Ids.CMD_SET_LIGHT_ANGLES, v.toInt(), st[Ids.S_LIGHT_Y].toInt())
            st[Ids.S_LIGHT_X] = v
        })
        put(SeekRow(context, "Yaw", 0f, 360f, st[Ids.S_LIGHT_Y], 0) { v ->
            NativeBridge.command(Ids.CMD_SET_LIGHT_ANGLES, st[Ids.S_LIGHT_X].toInt(), v.toInt())
            st[Ids.S_LIGHT_Y] = v
        })
        put(SeekRow(context, "Ambient", 0f, 255f, st[Ids.S_LIGHT_AMBIENT], 0) { v -> NativeBridge.command(Ids.CMD_SET_LIGHT_AMBIENT, v.toInt()) })
        put(SeekRow(context, "Shade", 0f, 255f, st[Ids.S_LIGHT_SHADE], 0) { v -> NativeBridge.command(Ids.CMD_SET_LIGHT_SHADE, v.toInt()) })
        actionRow(context.textButton("Light color...") {
            context.pickColor("Light color", Color.WHITE, false) { argb -> NativeBridge.command(Ids.CMD_SET_LIGHT_COLOR, argb) }
        })
    }
}

// ------------------------------------------------------------------------------------------------ Parts

internal fun PropertiesPanel.buildPartsTab() {
    val kinds = listOf("Bones", "Controllers", "Attachments", "Hitboxes")
    val row = context.hbox()
    for (i in kinds.indices) {
        val active = i == partsKind
        val b = context.textButton(kinds[i], active) {
            partsKind = i
            refresh()
        }
        b.setPadding(context.dp(4), context.dp(6), context.dp(4), context.dp(6))
        row.add(b, 0, WRAP, 1f)
        (b.layoutParams as LinearLayout.LayoutParams).setMargins(context.dp(2), context.dp(4), context.dp(2), context.dp(8))
    }
    put(row)
    when (partsKind) {
        0 -> buildBones()
        1 -> buildControllers()
        2 -> buildAttachments()
        else -> buildHitboxes()
    }
}

private fun PropertiesPanel.buildBones() {
    val bones = JSONArray(NativeBridge.query(Ids.Q_BONES))
    hint(bones.length().toString() + " bones. Tap a bone to draw only that bone; tap again to show all.")
    for (i in 0 until bones.length()) {
        val b = bones.getJSONObject(i)
        val index = i
        val selected = singleBone == i
        val r = context.hbox()
        r.setPadding(context.dp(8), context.dp(4), context.dp(8), context.dp(4))
        r.minimumHeight = context.dp(44)
        r.background = if (selected) roundRect(0x33FF8A00, context.dpf(6f)) else null
        val col = context.vbox()
        col.add(context.label("#" + i + "  " + b.getString("name"), 13f, if (selected) Ui.ACCENT else Ui.TEXT)).setSingleLine(true)
        col.add(context.label("parent: " + (if (b.getInt("parent") < 0) "none" else b.getString("parentName")), 11f, Ui.TEXT_DIM))
        r.add(col, 0, WRAP, 1f)
        r.isClickable = true
        r.setOnClickListener {
            singleBone = if (singleBone == index) -1 else index
            NativeBridge.command(Ids.CMD_SET_DRAW_SINGLE, 0, singleBone)
            if (singleBone >= 0 && !viewState.flag(Ids.FLAG_BONES)) {
                viewState.setFlag(Ids.FLAG_BONES, true)
            }
            refresh()
        }
        put(r)
    }
}

private fun PropertiesPanel.buildControllers() {
    val list = JSONArray(NativeBridge.query(Ids.Q_CONTROLLERS))
    if (list.length() == 0) {
        hint("The model has no bone controllers.")
    }
    for (i in 0 until list.length()) {
        val c = list.getJSONObject(i)
        val controllerIndex = c.getInt("index")
        val start = c.getDouble("start").toFloat()
        val end = c.getDouble("end").toFloat()
        val label = "#" + controllerIndex + "  " + c.getString("typeName")
        put(SeekRow(context, label, Math.min(start, end), Math.max(start, end), c.getDouble("value").toFloat(), 1) { v ->
            NativeBridge.command(Ids.CMD_SET_CONTROLLER, controllerIndex, 0, v)
        })
    }
}

private fun PropertiesPanel.buildAttachments() {
    val list = JSONArray(NativeBridge.query(Ids.Q_ATTACHMENTS))
    hint(list.length().toString() + " attachments. Tap one to draw only that attachment.")
    for (i in 0 until list.length()) {
        val a = list.getJSONObject(i)
        val index = i
        val selected = singleAttachment == i
        val r = context.vbox()
        r.setPadding(context.dp(8), context.dp(6), context.dp(8), context.dp(6))
        r.minimumHeight = context.dp(44)
        r.background = if (selected) roundRect(0x33FF8A00, context.dpf(6f)) else null
        r.add(context.label("#" + i + "  " + a.getString("name"), 13f, if (selected) Ui.ACCENT else Ui.TEXT))
        val o = vec(a, "origin")
        r.add(context.label("bone: " + a.getString("boneName") + "   origin: " + o.joinToString("  ") { formatFloat(it, 1) }, 11f, Ui.TEXT_DIM))
        r.isClickable = true
        r.setOnClickListener {
            singleAttachment = if (singleAttachment == index) -1 else index
            NativeBridge.command(Ids.CMD_SET_DRAW_SINGLE, 1, singleAttachment)
            if (singleAttachment >= 0 && !viewState.flag(Ids.FLAG_ATTACHMENTS)) {
                viewState.setFlag(Ids.FLAG_ATTACHMENTS, true)
            }
            refresh()
        }
        put(r)
    }
}

private fun PropertiesPanel.buildHitboxes() {
    val list = JSONArray(NativeBridge.query(Ids.Q_HITBOXES))
    hint(list.length().toString() + " hitboxes. Tap one to draw only that hitbox.")
    for (i in 0 until list.length()) {
        val h = list.getJSONObject(i)
        val index = i
        val selected = singleHitbox == i
        val r = context.vbox()
        r.setPadding(context.dp(8), context.dp(6), context.dp(8), context.dp(6))
        r.minimumHeight = context.dp(44)
        r.background = if (selected) roundRect(0x33FF8A00, context.dpf(6f)) else null
        r.add(context.label("#" + i + "  group " + h.getInt("group") + "  bone " + h.getString("boneName"), 13f, if (selected) Ui.ACCENT else Ui.TEXT))
        val mn = vec(h, "min")
        val mx = vec(h, "max")
        r.add(context.label("min " + mn.joinToString(" ") { formatFloat(it, 1) } + "   max " + mx.joinToString(" ") { formatFloat(it, 1) }, 11f, Ui.TEXT_DIM))
        r.isClickable = true
        r.setOnClickListener {
            singleHitbox = if (singleHitbox == index) -1 else index
            NativeBridge.command(Ids.CMD_SET_DRAW_SINGLE, 2, singleHitbox)
            if (singleHitbox >= 0 && !viewState.flag(Ids.FLAG_HITBOXES)) {
                viewState.setFlag(Ids.FLAG_HITBOXES, true)
            }
            refresh()
        }
        put(r)
    }
}

// ------------------------------------------------------------------------------------------------ Settings

internal fun PropertiesPanel.buildSettingsTab() {
    put(SeekRow(context, "Touch sensitivity", 1f, 20f, prefs.getInt("mouse_sens", 5).toFloat(), 0) { v ->
        prefs.putInt("mouse_sens", v.toInt())
        NativeBridge.command(Ids.CMD_SET_MOUSE_SENS, v.toInt())
    })
    flagSwitch("Invert horizontal axis", Ids.FLAG_INVERT_X)
    flagSwitch("Invert vertical axis", Ids.FLAG_INVERT_Y)
    flagSwitch("Play sounds", Ids.FLAG_SOUNDS)

    collapsible("Textures") {
        flagSwitch("Resize textures to power of 2", Ids.FLAG_POW2)
        val filters = listOf("Nearest", "Linear")
        val mips = listOf("None", "Nearest", "Linear")
        dropdownRow("Minification filter", filters, prefs.getInt("min_filter", 1)) { idx ->
            prefs.putInt("min_filter", idx)
            applyFilters()
        }
        dropdownRow("Magnification filter", filters, prefs.getInt("mag_filter", 1)) { idx ->
            prefs.putInt("mag_filter", idx)
            applyFilters()
        }
        dropdownRow("Mipmap filter", mips, prefs.getInt("mip_filter", 0)) { idx ->
            prefs.putInt("mip_filter", idx)
            applyFilters()
        }
    }
    collapsible("Colors") {
        val colors = JSONArray(NativeBridge.query(Ids.Q_COLORS))
        for (i in 0 until colors.length()) {
            val c = colors.getJSONObject(i)
            val id = c.getInt("id")
            val argb = c.getLong("argb").toInt()
            val withAlpha = c.getBoolean("alpha")
            val r = context.hbox()
            r.setPadding(context.dp(4), context.dp(4), context.dp(4), context.dp(4))
            r.minimumHeight = context.dp(44)
            val swatch = View(context)
            swatch.background = roundRect(viewState.swatchColor(argb), context.dpf(6f), Ui.TEXT_DIM, 2)
            r.add(swatch, context.dp(32), context.dp(24))
            val t = r.add(context.label(c.getString("title"), 13f), 0, WRAP, 1f)
            t.setPadding(context.dp(12), 0, 0, 0)
            r.isClickable = true
            r.setOnClickListener {
                context.pickColor(c.getString("title"), argb, withAlpha) { value ->
                    viewState.setColor(id, value)
                    refresh()
                }
            }
            put(r)
        }
        actionRow(context.textButton("Reset colors") {
            viewState.resetColors()
            refresh()
        })
    }
    collapsible("Advanced") {
        flagSwitch("Framerate affects sound pitch", Ids.FLAG_SOUND_PITCH)
        put(context.switchRow("Autodetect view models (v_ prefix)", prefs.getBool("autodetect_vm", true)) { on ->
            prefs.putBool("autodetect_vm", on)
            NativeBridge.command(Ids.CMD_SET_AUTODETECT_VIEWMODEL, if (on) 1 else 0)
        })
        val groundRow = context.hbox()
        groundRow.setPadding(context.dp(4), context.dp(2), context.dp(4), context.dp(2))
        groundRow.add(context.label("Ground length", 13f, Ui.TEXT), 0, WRAP, 1f)
        groundRow.add(context.numberField(prefs.getInt("ground_length", 100).toString()) { v ->
            val length = v.toInt().coerceIn(0, 2048)
            prefs.putInt("ground_length", length)
            NativeBridge.command(Ids.CMD_SET_GROUND_LENGTH, length)
        }, context.dp(100), WRAP)
        put(groundRow)
    }
    hint("Lambda Asset Viewer 1.0 - Android port of Half-Life Asset Manager. Licenses are in the licenses folder of the project.")
}

private fun PropertiesPanel.applyFilters() {
    NativeBridge.command(Ids.CMD_SET_TEX_FILTER, prefs.getInt("min_filter", 1), prefs.getInt("mag_filter", 1), prefs.getInt("mip_filter", 0).toFloat())
}
