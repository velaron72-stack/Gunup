package app.lambdaviewer

import android.content.Context
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Правая выдвижная панель свойств модели (аналог док-панелей оригинала). Вкладки: Model, Sequences, Body, Textures, Bones,
 * Controllers, Attachments, Hitboxes, Display, Scene, Transform, Options, Messages. Содержимое каждой вкладки строится
 * из JSON-ответов нативного ядра (см. PropertyTabs.kt) и пересоздаётся при смене модели или правке данных.
 */
class PropertiesPanel(context: Context, val prefs: Prefs, val viewState: ViewState, val host: Host) : LinearLayout(context) {
    interface Host {
        fun closePropsPanel()
        fun toast(message: String)
        fun showTextureView(index: Int)
        fun exportTexture(index: Int, png: Boolean)
        fun importTexture(index: Int)
        fun pickSceneImage(kind: Int)
        fun saveAs()
        fun setSkeletonPose(on: Boolean)
        fun closeModel()
        fun save()
        fun onPanelChanged()
    }

    val body: LinearLayout = context.vbox()
    /** Контейнер, в который вкладки добавляют элементы (тело вкладки или содержимое сворачиваемой секции). */
    var target: LinearLayout = body
    val expandedSections = HashSet<String>()
    private val tabButtons = ArrayList<TextView>()
    var tab: Int = TAB_MODEL
    var partsKind: Int = 0
    var hasModel: Boolean = false
    var selectedTexture: Int = 0
    var singleBone: Int = -1
    var singleAttachment: Int = -1
    var singleHitbox: Int = -1

    init {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Ui.PANEL)

        val header = context.hbox()
        header.setPadding(context.dp(12), context.dp(4), context.dp(4), context.dp(4))
        header.add(context.label("Properties", 16f, Ui.TEXT, true), 0, WRAP, 1f)
        header.add(IconButton(context, Icon.CLOSE, null, false) { host.closePropsPanel() })
        addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        val strip = context.hbox()
        for (i in TAB_TITLES.indices) {
            val t = context.label(TAB_TITLES[i], 12f, Ui.TEXT_DIM, true)
            t.gravity = android.view.Gravity.CENTER
            t.setPadding(context.dp(14), 0, context.dp(14), 0)
            t.minimumHeight = context.dp(44)
            t.isClickable = true
            t.setOnClickListener { selectTab(i) }
            tabButtons.add(t)
            strip.add(t, WRAP, MATCH)
        }
        val stripScroll = HorizontalScrollView(context)
        stripScroll.isHorizontalScrollBarEnabled = false
        stripScroll.addView(strip)
        addView(stripScroll, LinearLayout.LayoutParams(MATCH, WRAP))

        val scroll = ScrollView(context)
        body.setPadding(context.dp(10), context.dp(4), context.dp(10), context.dp(16))
        scroll.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        selectTab(TAB_MODEL)
    }

    fun selectTab(index: Int) {
        tab = index
        for (i in tabButtons.indices) {
            val active = i == index
            tabButtons[i].setTextColor(if (active) Ui.ACCENT else Ui.TEXT_DIM)
            tabButtons[i].background = if (active) roundRect(0x22FF8A00, context.dpf(6f)) else null
        }
        refresh()
    }

    /** Пересобирает содержимое текущей вкладки. */
    fun refresh() {
        body.removeAllViews()
        target = body
        val needsModel = tab != TAB_SETTINGS
        if (needsModel && !hasModel) {
            val hint = context.label("Open a model to see its properties.\nSwipe from the left edge to browse files.", 13f, Ui.TEXT_DIM)
            hint.setPadding(context.dp(4), context.dp(16), context.dp(4), 0)
            body.addView(hint)
            return
        }
        try {
            when (tab) {
                TAB_MODEL -> buildModelTab()
                TAB_ANIMATION -> buildAnimationTab()
                TAB_TEXTURES -> buildTexturesTab()
                TAB_VIEW -> buildViewTab()
                TAB_PARTS -> buildPartsTab()
                else -> buildSettingsTab()
            }
        } catch (e: Exception) {
            body.addView(context.label("Failed to build the tab: " + e.message, 12f, Ui.DANGER))
        }
    }

    fun resetSelections() {
        selectedTexture = 0
        singleBone = -1
        singleAttachment = -1
        singleHitbox = -1
    }

    companion object {
        const val TAB_MODEL = 0
        const val TAB_ANIMATION = 1
        const val TAB_TEXTURES = 2
        const val TAB_VIEW = 3
        const val TAB_PARTS = 4
        const val TAB_SETTINGS = 5
        val TAB_TITLES: List<String> = listOf("Model", "Animation", "Textures", "View", "Parts", "Settings")
    }
}
