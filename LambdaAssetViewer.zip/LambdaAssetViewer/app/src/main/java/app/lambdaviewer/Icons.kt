package app.lambdaviewer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** Набор собственных значков (рисуются через Canvas в сетке 24x24, ресурсов Qt-оригинала не используются). */
enum class Icon {
    PLAY, PAUSE, STOP, PREV, NEXT, LOOP, TARGET, MENU, FOLDER, SAVE, WIREFRAME, HITBOX, BONES, ATTACH, NORMALS, EYE,
    BBOX, AXES, GROUND, LIGHT, UV, TEXTURE, CAMERA, INFO, GEAR, CLOSE, PLUS, BACK, SOUND, CUBE, PANEL, EXPORT, IMPORT,
    RESTART, STEP_BACK5, STEP_FWD5, SKELETON
}

object Icons {
    private val path = Path()
    private val rect = RectF()

    fun draw(c: Canvas, icon: Icon, fill: Paint, stroke: Paint) {
        when (icon) {
            Icon.PLAY -> {
                path.reset(); path.moveTo(7f, 4.5f); path.lineTo(19f, 12f); path.lineTo(7f, 19.5f); path.close()
                c.drawPath(path, fill)
            }
            Icon.PAUSE -> {
                c.drawRect(6f, 5f, 10.5f, 19f, fill)
                c.drawRect(13.5f, 5f, 18f, 19f, fill)
            }
            Icon.STOP -> c.drawRect(6f, 6f, 18f, 18f, fill)
            Icon.PREV -> {
                c.drawRect(5f, 5f, 7.5f, 19f, fill)
                path.reset(); path.moveTo(19f, 5f); path.lineTo(9f, 12f); path.lineTo(19f, 19f); path.close()
                c.drawPath(path, fill)
            }
            Icon.NEXT -> {
                c.drawRect(16.5f, 5f, 19f, 19f, fill)
                path.reset(); path.moveTo(5f, 5f); path.lineTo(15f, 12f); path.lineTo(5f, 19f); path.close()
                c.drawPath(path, fill)
            }
            Icon.LOOP -> {
                rect.set(5f, 5f, 19f, 19f)
                c.drawArc(rect, -60f, 280f, false, stroke)
                path.reset(); path.moveTo(15f, 2.5f); path.lineTo(20.5f, 6f); path.lineTo(14f, 8.5f); path.close()
                c.drawPath(path, fill)
            }
            Icon.TARGET -> {
                c.drawCircle(12f, 12f, 5.5f, stroke)
                c.drawLine(12f, 2.5f, 12f, 7f, stroke); c.drawLine(12f, 17f, 12f, 21.5f, stroke)
                c.drawLine(2.5f, 12f, 7f, 12f, stroke); c.drawLine(17f, 12f, 21.5f, 12f, stroke)
            }
            Icon.MENU -> {
                c.drawLine(4f, 7f, 20f, 7f, stroke); c.drawLine(4f, 12f, 20f, 12f, stroke); c.drawLine(4f, 17f, 20f, 17f, stroke)
            }
            Icon.FOLDER -> {
                path.reset(); path.moveTo(3f, 6f); path.lineTo(9f, 6f); path.lineTo(11f, 8.5f); path.lineTo(21f, 8.5f)
                path.lineTo(21f, 19f); path.lineTo(3f, 19f); path.close()
                c.drawPath(path, stroke)
            }
            Icon.SAVE -> {
                rect.set(4.5f, 4.5f, 19.5f, 19.5f); c.drawRoundRect(rect, 2f, 2f, stroke)
                c.drawRect(8f, 4.5f, 16f, 9f, stroke)
                c.drawRect(8f, 13f, 16f, 19.5f, stroke)
            }
            Icon.WIREFRAME, Icon.CUBE -> {
                c.drawRect(4f, 9f, 15f, 20f, stroke)
                c.drawRect(9f, 4f, 20f, 15f, stroke)
                c.drawLine(4f, 9f, 9f, 4f, stroke); c.drawLine(15f, 9f, 20f, 4f, stroke)
                c.drawLine(4f, 20f, 9f, 15f, stroke); c.drawLine(15f, 20f, 20f, 15f, stroke)
            }
            Icon.HITBOX -> {
                rect.set(4.5f, 6f, 19.5f, 18f); c.drawRect(rect, stroke)
                c.drawLine(4.5f, 12f, 19.5f, 12f, stroke)
                c.drawLine(12f, 6f, 12f, 18f, stroke)
            }
            Icon.BONES -> {
                c.drawLine(6f, 18f, 12f, 12f, stroke); c.drawLine(12f, 12f, 18f, 6f, stroke)
                c.drawCircle(6f, 18f, 2.2f, fill); c.drawCircle(12f, 12f, 2.2f, fill); c.drawCircle(18f, 6f, 2.2f, fill)
            }
            Icon.ATTACH -> {
                c.drawCircle(12f, 12f, 4f, stroke)
                c.drawLine(12f, 3f, 12f, 8f, stroke); c.drawLine(12f, 16f, 12f, 21f, stroke)
                c.drawLine(3f, 12f, 8f, 12f, stroke); c.drawLine(16f, 12f, 21f, 12f, stroke)
            }
            Icon.NORMALS -> {
                c.drawLine(4f, 18f, 20f, 18f, stroke)
                for (x in intArrayOf(7, 12, 17)) {
                    c.drawLine(x.toFloat(), 18f, x.toFloat(), 6f, stroke)
                    c.drawLine(x.toFloat(), 6f, x - 2f, 9f, stroke); c.drawLine(x.toFloat(), 6f, x + 2f, 9f, stroke)
                }
            }
            Icon.EYE -> {
                rect.set(2.5f, 6.5f, 21.5f, 17.5f); c.drawOval(rect, stroke)
                c.drawCircle(12f, 12f, 3f, fill)
            }
            Icon.BBOX -> {
                c.drawRect(5f, 5f, 19f, 19f, stroke)
                c.drawCircle(5f, 5f, 1.8f, fill); c.drawCircle(19f, 5f, 1.8f, fill)
                c.drawCircle(5f, 19f, 1.8f, fill); c.drawCircle(19f, 19f, 1.8f, fill)
            }
            Icon.AXES -> {
                c.drawLine(6f, 18f, 19f, 18f, stroke); c.drawLine(6f, 18f, 6f, 5f, stroke); c.drawLine(6f, 18f, 15f, 9f, stroke)
            }
            Icon.GROUND -> {
                path.reset(); path.moveTo(8f, 7f); path.lineTo(16f, 7f); path.lineTo(21f, 18f); path.lineTo(3f, 18f); path.close()
                c.drawPath(path, stroke)
                c.drawLine(10.7f, 7f, 8.5f, 18f, stroke); c.drawLine(13.3f, 7f, 15.5f, 18f, stroke)
                c.drawLine(6f, 12.5f, 18f, 12.5f, stroke)
            }
            Icon.LIGHT -> {
                c.drawCircle(12f, 12f, 4f, stroke)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cx = Math.cos(a).toFloat()
                    val cy = Math.sin(a).toFloat()
                    c.drawLine(12f + cx * 6.5f, 12f + cy * 6.5f, 12f + cx * 9.5f, 12f + cy * 9.5f, stroke)
                }
            }
            Icon.UV -> {
                c.drawRect(4f, 4f, 20f, 20f, stroke)
                c.drawLine(12f, 4f, 12f, 20f, stroke); c.drawLine(4f, 12f, 20f, 12f, stroke)
                c.drawLine(4f, 20f, 20f, 4f, stroke)
            }
            Icon.TEXTURE -> {
                c.drawRect(4f, 4f, 12f, 12f, fill); c.drawRect(12f, 12f, 20f, 20f, fill)
                c.drawRect(4f, 4f, 20f, 20f, stroke)
            }
            Icon.CAMERA -> {
                rect.set(3f, 7f, 21f, 19f); c.drawRoundRect(rect, 2f, 2f, stroke)
                c.drawCircle(12f, 13f, 3.5f, stroke)
                c.drawLine(8f, 7f, 9.5f, 4.5f, stroke); c.drawLine(9.5f, 4.5f, 14.5f, 4.5f, stroke); c.drawLine(14.5f, 4.5f, 16f, 7f, stroke)
            }
            Icon.INFO -> {
                c.drawCircle(12f, 12f, 9f, stroke)
                c.drawCircle(12f, 7.8f, 1.2f, fill)
                c.drawLine(12f, 11f, 12f, 17f, stroke)
            }
            Icon.GEAR -> {
                c.drawCircle(12f, 12f, 3.5f, stroke)
                c.drawCircle(12f, 12f, 7.5f, stroke)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cx = Math.cos(a).toFloat()
                    val cy = Math.sin(a).toFloat()
                    c.drawLine(12f + cx * 7.5f, 12f + cy * 7.5f, 12f + cx * 10f, 12f + cy * 10f, stroke)
                }
            }
            Icon.CLOSE -> {
                c.drawLine(6f, 6f, 18f, 18f, stroke); c.drawLine(18f, 6f, 6f, 18f, stroke)
            }
            Icon.PLUS -> {
                c.drawLine(12f, 5f, 12f, 19f, stroke); c.drawLine(5f, 12f, 19f, 12f, stroke)
            }
            Icon.BACK -> {
                c.drawLine(19f, 12f, 5f, 12f, stroke); c.drawLine(5f, 12f, 11f, 6f, stroke); c.drawLine(5f, 12f, 11f, 18f, stroke)
            }
            Icon.SOUND -> {
                path.reset(); path.moveTo(4f, 9f); path.lineTo(8f, 9f); path.lineTo(13f, 5f); path.lineTo(13f, 19f); path.lineTo(8f, 15f); path.lineTo(4f, 15f); path.close()
                c.drawPath(path, fill)
                rect.set(14f, 8f, 20f, 16f); c.drawArc(rect, -60f, 120f, false, stroke)
            }
            Icon.PANEL -> {
                c.drawRect(3.5f, 5f, 20.5f, 19f, stroke)
                c.drawLine(14f, 5f, 14f, 19f, stroke)
                c.drawLine(16f, 9f, 18.5f, 9f, stroke); c.drawLine(16f, 12f, 18.5f, 12f, stroke); c.drawLine(16f, 15f, 18.5f, 15f, stroke)
            }
            Icon.EXPORT -> {
                c.drawLine(12f, 15f, 12f, 4f, stroke); c.drawLine(12f, 4f, 7.5f, 8.5f, stroke); c.drawLine(12f, 4f, 16.5f, 8.5f, stroke)
                c.drawLine(5f, 14f, 5f, 20f, stroke); c.drawLine(5f, 20f, 19f, 20f, stroke); c.drawLine(19f, 20f, 19f, 14f, stroke)
            }
            Icon.RESTART -> {
                c.save()
                c.scale(-1f, 1f, 12f, 12f)
                rect.set(5f, 5f, 19f, 19f)
                c.drawArc(rect, -60f, 280f, false, stroke)
                path.reset(); path.moveTo(15f, 2.5f); path.lineTo(20.5f, 6f); path.lineTo(14f, 8.5f); path.close()
                c.drawPath(path, fill)
                c.restore()
            }
            Icon.STEP_BACK5 -> {
                path.reset(); path.moveTo(12f, 5f); path.lineTo(4f, 12f); path.lineTo(12f, 19f); path.close()
                c.drawPath(path, fill)
                path.reset(); path.moveTo(21f, 5f); path.lineTo(13f, 12f); path.lineTo(21f, 19f); path.close()
                c.drawPath(path, fill)
            }
            Icon.STEP_FWD5 -> {
                path.reset(); path.moveTo(3f, 5f); path.lineTo(11f, 12f); path.lineTo(3f, 19f); path.close()
                c.drawPath(path, fill)
                path.reset(); path.moveTo(12f, 5f); path.lineTo(20f, 12f); path.lineTo(12f, 19f); path.close()
                c.drawPath(path, fill)
            }
            Icon.SKELETON -> {
                c.drawCircle(12f, 5f, 2.5f, stroke)
                c.drawLine(12f, 7.5f, 12f, 15f, stroke)
                c.drawLine(6f, 11f, 18f, 11f, stroke)
                c.drawLine(12f, 15f, 8f, 21f, stroke)
                c.drawLine(12f, 15f, 16f, 21f, stroke)
            }
            Icon.IMPORT -> {
                c.drawLine(12f, 4f, 12f, 15f, stroke); c.drawLine(12f, 15f, 7.5f, 10.5f, stroke); c.drawLine(12f, 15f, 16.5f, 10.5f, stroke)
                c.drawLine(5f, 14f, 5f, 20f, stroke); c.drawLine(5f, 20f, 19f, 20f, stroke); c.drawLine(19f, 20f, 19f, 14f, stroke)
            }
        }
    }
}

/** Вид одного значка; цвет меняется свойством [tint]. */
class IconView(context: Context, var icon: Icon) : View(context) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)

    var tint: Int = Ui.TEXT
        set(value) {
            field = value
            invalidate()
        }

    init {
        fill.style = Paint.Style.FILL
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = 2f
        stroke.strokeCap = Paint.Cap.ROUND
        stroke.strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        fill.color = tint
        stroke.color = tint
        canvas.save()
        canvas.scale(width / 24f, height / 24f)
        Icons.draw(canvas, icon, fill, stroke)
        canvas.restore()
    }
}

/**
 * Кнопка со значком и подписью. Если [toggle] = true, хранит состояние (подсвечивается акцентным цветом).
 * Область нажатия — не менее 48dp по высоте.
 */
class IconButton(context: Context, icon: Icon, caption: String?, val toggle: Boolean, private val onClick: (IconButton) -> Unit) :
    LinearLayout(context) {
    private val iconView = IconView(context, icon)
    private val captionView: TextView? = if (caption != null) context.label(caption, 9f, Ui.TEXT_DIM) else null

    var checked: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                refresh()
            }
        }

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        minimumWidth = context.dp(48)
        minimumHeight = context.dp(48)
        setPadding(context.dp(4), context.dp(4), context.dp(4), context.dp(2))
        addView(iconView, LinearLayout.LayoutParams(context.dp(24), context.dp(24)))
        if (captionView != null) {
            captionView.gravity = Gravity.CENTER
            captionView.setSingleLine(true)
            addView(captionView, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        isClickable = true
        setOnClickListener {
            if (toggle) {
                checked = !checked
            }
            onClick(this)
        }
        refresh()
    }

    fun setIcon(icon: Icon) {
        iconView.icon = icon
        iconView.invalidate()
    }

    fun setCaption(text: String) {
        captionView?.text = text
    }

    private fun refresh() {
        val color = if (checked) Ui.ACCENT else Ui.TEXT
        iconView.tint = color
        captionView?.setTextColor(if (checked) Ui.ACCENT else Ui.TEXT_DIM)
        background = if (checked) roundRect(0x33FF8A00, context.dpf(8f)) else null
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        alpha = if (enabled) 1f else 0.4f
    }
}
