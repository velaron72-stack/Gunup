package app.lambdaviewer

import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray

/**
 * Левая выдвижная панель: навигация по файлам (аналог файлового браузера оригинала).
 * Показывает каталоги игр Half-Life / Xash3D / Counter-Strike и пользовательские каталоги, добавленные через SAF,
 * дерево папок, модели и поддерживаемые форматы изображений. Последний открытый каталог восстанавливается при запуске.
 */
class FilePanel(context: Context, private val prefs: Prefs, private val host: Host) : LinearLayout(context) {
    interface Host {
        fun addRoot(category: String)
        fun openFiles()
        fun openModel(entry: Saf.Entry, tree: Uri, parentDocId: String)
        fun openImage(entry: Saf.Entry)
        fun openRecent(recent: Prefs.Recent)
        fun closeFilePanel()
    }

    private val ui = Handler(Looper.getMainLooper())
    private val list: LinearLayout = context.vbox()
    private val title: TextView = context.label("Files", 16f, Ui.TEXT, true)
    private val crumbs: LinearLayout = context.hbox()
    private val pathText: TextView = context.label("", 12f, Ui.TEXT_DIM)
    private var root: Prefs.Root? = null
    private val stack = ArrayList<Array<String>>()
    private var generation = 0

    init {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Ui.PANEL)

        val header = context.hbox()
        header.setPadding(context.dp(12), context.dp(4), context.dp(4), context.dp(4))
        header.add(title, 0, WRAP, 1f)
        header.add(IconButton(context, Icon.FOLDER, null, false) { host.openFiles() })
        header.add(IconButton(context, Icon.CLOSE, null, false) { host.closeFilePanel() })
        addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        crumbs.setPadding(context.dp(4), 0, context.dp(4), 0)
        crumbs.add(IconButton(context, Icon.BACK, null, false) { goUp() })
        pathText.setSingleLine(true)
        pathText.ellipsize = TextUtils.TruncateAt.START
        crumbs.add(pathText, 0, WRAP, 1f)
        addView(crumbs, LinearLayout.LayoutParams(MATCH, WRAP))

        val scroll = ScrollView(context)
        scroll.addView(list, LinearLayout.LayoutParams(MATCH, WRAP))
        addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        restoreLast()
    }

    /** Список каталогов игр (после добавления/удаления корня). */
    fun showRoots() {
        root = null
        stack.clear()
        saveLast()
        generation++
        crumbs.visibility = View.GONE
        title.text = "Files"
        list.removeAllViews()
        for (category in CATEGORIES) {
            val head = context.hbox()
            head.setPadding(context.dp(12), context.dp(8), context.dp(4), 0)
            head.add(context.label(category.uppercase(), 11f, Ui.ACCENT, true), 0, WRAP, 1f)
            head.add(IconButton(context, Icon.PLUS, null, false) { host.addRoot(category) })
            list.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
            var count = 0
            for (r in prefs.roots()) {
                if (r.category == category) {
                    count++
                    list.addView(row(Icon.FOLDER, r.name, null, true, { openRoot(r) }, { confirmRemove(r) }),
                        LinearLayout.LayoutParams(MATCH, WRAP))
                }
            }
            if (count == 0) {
                val hint = context.label("Tap + to choose the folder", 12f, Ui.TEXT_DIM)
                hint.setPadding(context.dp(16), context.dp(2), context.dp(8), context.dp(6))
                list.addView(hint)
            }
        }
        val recents = prefs.recents()
        if (recents.isNotEmpty()) {
            val head = context.hbox()
            head.setPadding(context.dp(12), context.dp(12), context.dp(4), 0)
            head.add(context.label("RECENT FILES", 11f, Ui.ACCENT, true), 0, WRAP, 1f)
            head.add(context.textButton("Clear") {
                prefs.clearRecents()
                showRoots()
            })
            list.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
            for (r in recents.take(8)) {
                list.addView(row(Icon.CUBE, r.name, null, false, { host.openRecent(r) }, null), LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }
    }

    private fun openRoot(r: Prefs.Root) {
        root = r
        stack.clear()
        saveLast()
        load()
    }

    private fun goUp() {
        if (stack.isNotEmpty()) {
            stack.removeAt(stack.size - 1)
            saveLast()
            load()
        } else {
            showRoots()
        }
    }

    private fun confirmRemove(r: Prefs.Root) {
        AlertDialog.Builder(context)
            .setTitle("Remove folder")
            .setMessage(r.name)
            .setPositiveButton("Remove") { _, _ ->
                val roots = prefs.roots()
                roots.removeAll { it.uri == r.uri }
                prefs.saveRoots(roots)
                showRoots()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun load() {
        val r = root ?: return
        val tree = Uri.parse(r.uri)
        val docId = if (stack.isEmpty()) Saf.treeRootDocId(tree) else stack[stack.size - 1][0]
        crumbs.visibility = View.VISIBLE
        val sb = StringBuilder(r.name)
        for (s in stack) {
            sb.append(" / ").append(s[1])
        }
        pathText.text = sb.toString()
        title.text = r.category
        val gen = ++generation
        list.removeAllViews()
        list.addView(context.label("Loading...", 13f, Ui.TEXT_DIM))
        val ctx = context
        Thread {
            val items = Saf.listChildren(ctx, tree, docId)
            ui.post {
                if (gen == generation) {
                    render(tree, docId, items)
                }
            }
        }.start()
    }

    private fun kindOf(e: Saf.Entry): Int {
        if (e.isDir) {
            return KIND_DIR
        }
        val n = e.name.lowercase()
        return when {
            n.endsWith(".mdl") -> KIND_MODEL
            n.endsWith(".bmp") || n.endsWith(".png") || n.endsWith(".tga") || n.endsWith(".jpg") || n.endsWith(".jpeg") -> KIND_IMAGE
            else -> KIND_OTHER
        }
    }

    private fun render(tree: Uri, parentDocId: String, items: List<Saf.Entry>) {
        list.removeAllViews()
        val sorted = items.sortedWith(compareBy<Saf.Entry>({ !it.isDir }, { it.name.lowercase() }))
        var shown = 0
        for (e in sorted) {
            val kind = kindOf(e)
            if (kind == KIND_OTHER) {
                continue
            }
            shown++
            val entry = e
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            when (kind) {
                KIND_DIR -> list.addView(row(Icon.FOLDER, e.name, null, true, {
                    stack.add(arrayOf(entry.docId, entry.name))
                    saveLast()
                    load()
                }, null), lp)
                KIND_MODEL -> list.addView(row(Icon.CUBE, e.name, formatSize(e.size), false, {
                    host.openModel(entry, tree, parentDocId)
                }, null), lp)
                KIND_IMAGE -> list.addView(row(Icon.TEXTURE, e.name, formatSize(e.size), false, { host.openImage(entry) }, null), lp)
                else -> list.addView(row(Icon.PANEL, e.name, formatSize(e.size), false, {}, null), lp)
            }
        }
        if (shown == 0) {
            val empty = context.label("No supported files here", 13f, Ui.TEXT_DIM)
            empty.setPadding(context.dp(16), context.dp(12), context.dp(8), context.dp(8))
            list.addView(empty)
        }
    }

    private fun formatSize(size: Long): String? {
        if (size <= 0L) {
            return null
        }
        return if (size >= 1048576L) formatFloat(size / 1048576f, 1) + " MB" else formatFloat(size / 1024f, 0) + " KB"
    }

    private fun selectable(): Int {
        val tv = TypedValue()
        context.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return tv.resourceId
    }

    private fun row(icon: Icon, text: String, sub: String?, accentIcon: Boolean, onClick: () -> Unit, onLong: (() -> Unit)?): View {
        val r = context.hbox()
        r.setPadding(context.dp(12), context.dp(6), context.dp(8), context.dp(6))
        r.minimumHeight = context.dp(52)
        val iv = IconView(context, icon)
        iv.tint = if (accentIcon) Ui.ACCENT else Ui.TEXT_DIM
        r.addView(iv, LinearLayout.LayoutParams(context.dp(24), context.dp(24)))
        val col = context.vbox()
        col.setPadding(context.dp(12), 0, 0, 0)
        val name = col.add(context.label(text, 14f))
        name.setSingleLine(true)
        name.ellipsize = TextUtils.TruncateAt.MIDDLE
        if (sub != null) {
            col.add(context.label(sub, 11f, Ui.TEXT_DIM))
        }
        r.add(col, 0, WRAP, 1f)
        r.isClickable = true
        r.setBackgroundResource(selectable())
        r.setOnClickListener { onClick() }
        if (onLong != null) {
            r.setOnLongClickListener {
                onLong()
                true
            }
        }
        return r
    }

    private fun saveLast() {
        val r = root
        if (r == null) {
            prefs.putString("last_root", "")
            prefs.putString("last_stack", "[]")
            return
        }
        val array = JSONArray()
        for (s in stack) {
            val pair = JSONArray()
            pair.put(s[0])
            pair.put(s[1])
            array.put(pair)
        }
        prefs.putString("last_root", r.uri)
        prefs.putString("last_stack", array.toString())
    }

    private fun restoreLast() {
        val uri = prefs.getString("last_root", "")
        val found = prefs.roots().firstOrNull { it.uri == uri }
        if (found == null) {
            showRoots()
            return
        }
        root = found
        stack.clear()
        try {
            val array = JSONArray(prefs.getString("last_stack", "[]"))
            for (i in 0 until array.length()) {
                val pair = array.getJSONArray(i)
                stack.add(arrayOf(pair.getString(0), pair.getString(1)))
            }
        } catch (e: Exception) {
            stack.clear()
        }
        load()
    }

    companion object {
        val CATEGORIES: List<String> = listOf("Half-Life", "Xash3D", "Counter-Strike", "Custom")
        private const val KIND_DIR = 0
        private const val KIND_MODEL = 1
        private const val KIND_IMAGE = 2
        private const val KIND_OTHER = 3
    }
}
