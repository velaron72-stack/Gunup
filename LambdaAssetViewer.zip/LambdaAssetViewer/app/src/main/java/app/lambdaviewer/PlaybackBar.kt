package app.lambdaviewer

import android.content.Context
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/**
 * Панель воспроизведения под окном просмотра (аналог Timeline оригинала). Минимальный набор: предыдущий кадр,
 * Play/Pause, следующий кадр, цикл, ползунок кадра, счётчик кадров и скорость воспроизведения (по умолчанию 1x).
 * Все изменения применяются сразу, без подтверждения.
 */
class PlaybackBar(context: Context) : LinearLayout(context) {
    private val prev = IconButton(context, Icon.PREV, null, false) { NativeBridge.command(Ids.CMD_STEP_FRAME, -1) }
    private val playPause = IconButton(context, Icon.PLAY, null, false) { NativeBridge.command(Ids.CMD_PLAY_PAUSE, -1) }
    private val next = IconButton(context, Icon.NEXT, null, false) { NativeBridge.command(Ids.CMD_STEP_FRAME, 1) }
    private val loop = IconButton(context, Icon.LOOP, null, true) { button ->
        NativeBridge.command(Ids.CMD_SET_LOOP_MODE, if (button.checked) LOOP_ALWAYS else LOOP_NEVER)
    }
    private val slider = SeekBar(context)
    private val frameText: TextView = context.label("0 / 0", 12f, Ui.TEXT_DIM)
    private var speedIndex = DEFAULT_SPEED_INDEX
    private var frames = 0
    private var dragging = false
    private var playingShown = false
    private val speedButton: TextView

    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(Ui.BAR)
        setPadding(context.dp(6), 0, context.dp(6), 0)

        slider.max = 1000
        slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser && frames > 1) {
                    // Как Timeline::OnFrameSliderChanged: смена кадра ползунком ставит воспроизведение на паузу.
                    NativeBridge.command(Ids.CMD_SET_FRAME, 0, 1, progress / 1000f * (frames - 1))
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
            }
        })

        speedButton = context.dropdownButton({ SPEED_LABELS }, { speedIndex }, { idx ->
            NativeBridge.command(Ids.CMD_SET_SPEED, 0, 0, SPEED_VALUES[idx])
        })
        speedButton.gravity = Gravity.CENTER
        speedButton.text = SPEED_LABELS[DEFAULT_SPEED_INDEX]

        add(prev)
        add(playPause)
        add(next)
        add(loop)
        add(slider, 0, context.dp(40), 1f)
        add(frameText).setPadding(context.dp(8), 0, context.dp(8), 0)
        add(speedButton, context.dp(64), context.dp(40))
    }

    /** Обновление из вектора состояния (вызывается ~10 раз в секунду). */
    fun update(state: FloatArray) {
        val hasModel = state[Ids.S_HAS_MODEL] > 0.5f
        for (i in 0 until childCount) {
            getChildAt(i).isEnabled = hasModel
        }
        val playing = state[Ids.S_PLAYING] > 0.5f
        if (playing != playingShown) {
            playingShown = playing
            playPause.setIcon(if (playing) Icon.PAUSE else Icon.PLAY)
        }
        frames = state[Ids.S_NUM_FRAMES].toInt()
        val frame = state[Ids.S_FRAME]
        if (!dragging) {
            slider.progress = if (frames > 1) ((frame / (frames - 1)) * 1000f).toInt().coerceIn(0, 1000) else 0
        }
        frameText.setTextIfChanged("" + frame.toInt() + " / " + frames)
        loop.checked = state[Ids.S_LOOP_MODE].toInt() == LOOP_ALWAYS

        val speed = state[Ids.S_SPEED]
        var nearest = 0
        for (i in SPEED_VALUES.indices) {
            if (Math.abs(SPEED_VALUES[i] - speed) < Math.abs(SPEED_VALUES[nearest] - speed)) {
                nearest = i
            }
        }
        speedIndex = nearest
        val exact = Math.abs(SPEED_VALUES[nearest] - speed) < 0.001f
        speedButton.setTextIfChanged(if (exact) SPEED_LABELS[nearest] else formatFloat(speed, 2) + "x")
    }

    companion object {
        const val LOOP_ALWAYS = 0
        const val LOOP_NEVER = 1
        private const val DEFAULT_SPEED_INDEX = 4
        private val SPEED_VALUES: FloatArray = floatArrayOf(0.1f, 0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        private val SPEED_LABELS: List<String> = listOf("0.1x", "0.25x", "0.5x", "0.75x", "1x", "1.5x", "2x", "3x", "4x")
    }
}
