package app.lambdaviewer

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout

/**
 * Выдвижная боковая панель поверх окна просмотра. Открывается свайпом от края или кнопкой, закрывается касанием по окну
 * просмотра, кнопкой «Закрыть» и автоматически после паузы в работе с панелью (освобождая место для модели).
 */
class SlidePanel(context: Context, content: View, private val fromLeft: Boolean, private val widthPx: Int) : FrameLayout(context) {
    var isOpen: Boolean = false
        private set
    var onClosed: (() -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { autoHide() }

    init {
        addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        elevation = context.dpf(12f)
        visibility = View.GONE
    }

    fun open() {
        if (isOpen) {
            return
        }
        isOpen = true
        visibility = View.VISIBLE
        translationX = hiddenX()
        animate().translationX(0f).setDuration(180).start()
        scheduleHide()
    }

    fun close() {
        if (!isOpen) {
            return
        }
        isOpen = false
        handler.removeCallbacks(hideRunnable)
        animate().translationX(hiddenX()).setDuration(160).withEndAction {
            if (!isOpen) {
                visibility = View.GONE
            }
            onClosed?.invoke()
        }.start()
    }

    fun toggle() {
        if (isOpen) close() else open()
    }

    fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, AUTO_HIDE_MS)
    }

    private fun autoHide() {
        if (!isOpen) {
            return
        }
        // Пока в панели идёт ввод текста, закрытие откладывается.
        if (findFocus() is EditText) {
            scheduleHide()
        } else {
            close()
        }
    }

    private fun hiddenX(): Float = if (fromLeft) -widthPx.toFloat() else widthPx.toFloat()

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (isOpen) {
            scheduleHide()
        }
        return super.dispatchTouchEvent(ev)
    }

    companion object {
        private const val AUTO_HIDE_MS = 15000L
    }
}
