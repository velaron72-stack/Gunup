package app.lambdaviewer

/**
 * Единственная точка входа в нативную библиотеку liblambdaviewer.so.
 * Связь с HLAM: Kotlin отвечает только за интерфейс и систему Android, а вся логика (загрузка MDL, анимация, рендер, текстуры)
 * остаётся в перенесённом C++-ядре Half-Life Asset Manager; JNI — только транспорт (см. cpp/bridge/ViewerJni.cpp).
 */
object NativeBridge {
    init {
        System.loadLibrary("lambdaviewer")
    }

    @JvmStatic external fun nativeSurfaceCreated()
    @JvmStatic external fun nativeSurfaceChanged(width: Int, height: Int)
    @JvmStatic external fun nativeDrawFrame()
    @JvmStatic external fun nativeLoadModel(name: String, data: ByteArray, host: SiblingProvider?): String
    @JvmStatic external fun nativeCloseModel()
    @JvmStatic external fun nativeHasModel(): Boolean
    @JvmStatic external fun nativeCommand(cmd: Int, a: Int, b: Int, f: Float, s: String?): Int
    @JvmStatic external fun nativeQuery(query: Int, a: Int, b: Int): String
    @JvmStatic external fun nativeState(out: FloatArray)
    @JvmStatic external fun nativeTouch(kind: Int, x: Float, y: Float, extra: Float)
    @JvmStatic external fun nativeTextureInfo(index: Int, out: IntArray): Boolean
    @JvmStatic external fun nativeTextureArgb(index: Int): IntArray?
    @JvmStatic external fun nativeTextureBmp(index: Int): ByteArray?
    @JvmStatic external fun nativeImportBmp(index: Int, data: ByteArray): String
    @JvmStatic external fun nativeImportArgb(index: Int, width: Int, height: Int, pixels: IntArray): String
    @JvmStatic external fun nativeSetSceneImage(kind: Int, name: String, width: Int, height: Int, pixels: IntArray): Boolean
    @JvmStatic external fun nativeDecodeImage(data: ByteArray): IntArray?
    @JvmStatic external fun nativeSerialize(fileName: String): Array<ByteArray?>?
    @JvmStatic external fun nativeSetSoundCallback(callback: SoundCallback?)

    /** Отправляет команду нативному ядру (идентификаторы команд — в файле идентификаторов моста). */
    fun command(cmd: Int, a: Int = 0, b: Int = 0, f: Float = 0f, s: String? = null): Int = nativeCommand(cmd, a, b, f, s)

    /** Запрашивает данные панели в виде JSON/текста (идентификаторы запросов — в файле идентификаторов моста). */
    fun query(q: Int, a: Int = 0, b: Int = 0): String = nativeQuery(q, a, b)
}

/** Поставщик соседних файлов модели (NNT.mdl с текстурами, NN01.mdl с анимациями); вызывается из C++ при загрузке. */
interface SiblingProvider {
    fun readSibling(name: String): ByteArray?
}

/** Колбэк звуковых событий анимации (аналог ISoundSystem оригинала). */
interface SoundCallback {
    fun play(name: String, volume: Float, pitch: Int)
}
