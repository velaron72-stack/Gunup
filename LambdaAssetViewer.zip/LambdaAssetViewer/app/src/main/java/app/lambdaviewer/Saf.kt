package app.lambdaviewer

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract

/**
 * Работа с Storage Access Framework через DocumentsContract (без AndroidX).
 * Связь с HLAM: заменяет QFileDialog/QFileSystemModel/файловый браузер оригинала.
 */
object Saf {
    class Entry(val docId: String, val uri: Uri, val name: String, val isDir: Boolean, val size: Long)

    fun treeRootDocId(treeUri: Uri): String = DocumentsContract.getTreeDocumentId(treeUri)

    fun listChildren(ctx: Context, treeUri: Uri, parentDocId: String): List<Entry> {
        val result = ArrayList<Entry>()
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        try {
            ctx.contentResolver.query(childrenUri, columns, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: id
                    val mime = c.getString(2) ?: ""
                    val size = c.getLong(3)
                    result.add(
                        Entry(id, DocumentsContract.buildDocumentUriUsingTree(treeUri, id), name,
                            mime == DocumentsContract.Document.MIME_TYPE_DIR, size)
                    )
                }
            }
        } catch (e: Exception) {
            // каталог недоступен: возвращаем то, что успели прочитать
        }
        return result
    }

    fun findChild(ctx: Context, treeUri: Uri, parentDocId: String, name: String): Entry? {
        for (e in listChildren(ctx, treeUri, parentDocId)) {
            if (e.name.equals(name, ignoreCase = true)) {
                return e
            }
        }
        return null
    }

    fun readBytes(ctx: Context, uri: Uri): ByteArray? {
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
    }

    fun writeBytes(ctx: Context, uri: Uri, data: ByteArray): Boolean {
        return try {
            val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: return false
            out.use { it.write(data) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val name = c.getString(0)
                    if (name != null) {
                        return name
                    }
                }
            }
        } catch (e: Exception) {
            // имя определяется по пути
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "file"
    }

    fun createFile(ctx: Context, treeUri: Uri, parentDocId: String, mime: String, name: String): Uri? {
        return try {
            val parent = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocId)
            DocumentsContract.createDocument(ctx.contentResolver, parent, mime, name)
        } catch (e: Exception) {
            null
        }
    }
}

/** Находит соседние файлы модели по имени: сначала среди явно выбранных, затем в каталоге SAF. */
class SiblingResolver(
    private val ctx: Context,
    private val tree: Uri?,
    private val parentDocId: String?,
    private val extra: Map<String, Uri>
) : SiblingProvider {
    override fun readSibling(name: String): ByteArray? {
        val picked = extra[name.lowercase()]
        if (picked != null) {
            return Saf.readBytes(ctx, picked)
        }
        if (tree != null && parentDocId != null) {
            val entry = Saf.findChild(ctx, tree, parentDocId, name) ?: return null
            return Saf.readBytes(ctx, entry.uri)
        }
        return null
    }
}
