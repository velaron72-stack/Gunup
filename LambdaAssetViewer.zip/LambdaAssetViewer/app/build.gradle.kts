plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val ndkVersionOverride: String? = providers.gradleProperty("lambda.ndkVersion").orNull
val cmakeVersionValue: String = providers.gradleProperty("lambda.cmakeVersion").getOrElse("3.22.1")
val abiList: List<String> = providers.gradleProperty("lambda.abis").getOrElse("arm64-v8a,armeabi-v7a")
    .split(",").map { it.trim() }.filter { it.isNotEmpty() }

android {
    namespace = "app.lambdaviewer"
    compileSdk = 34

    if (ndkVersionOverride != null) {
        ndkVersion = ndkVersionOverride
    }

    defaultConfig {
        applicationId = "app.lambdaviewer"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            abiFilters += abiList
        }

        externalNativeBuild {
            cmake {
                arguments += listOf("-DANDROID_STL=c++_static", "-DANDROID_ARM_NEON=TRUE")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = cmakeVersionValue
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Релиз подписывается отладочным ключом, чтобы APK можно было сразу установить.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
    }
}
